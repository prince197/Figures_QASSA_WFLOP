# Conley-Morse parameter atlas

## Scientific task

This benchmark asks for one end-to-end analysis of a deterministic synthetic two-parameter family of finite multivalued cubical maps derived from a Hénon-family sweep. The output combines recurrent Morse graphs, parameter-space continuation events and regions, pathwise zigzag persistence, two-dimensional continuation ranks, multiparameter-persistence invariants of one globally continued recurrent family, and rational Conley index maps of the Morse sets of finer enclosures of the same map.

The public phase grid is 42 x 36 and the parameter grid is 17 x 17. A second, finer 128 x 96 enclosure of the same phase rectangle is supplied at the 5 x 5 parameter sublattice `i,j in {0,4,8,12,16}` for the Conley index stage. Every graded object is derived from the same parameterized dynamical system; no unrelated algebraic complexes are appended to increase difficulty. The hardening layer adds a second, geometric scale direction by dilating the same continued recurrent sets and coupling those nested exit pairs to the existing continuation zigzags.

## Data construction

`environment/data/atlas.json` contains finite multivalued cubical enclosures of

`(x,y) -> (1 - a x^2 + y, b x)`

on a fixed phase rectangle. The generator evaluates interval image bounds box by box and stores each map in CSR form with escape flags. The parameter graph is the four-neighbor graph of the 17 x 17 lattice. Public sweeps, a global continuation seed, rectangular continuation queries, and connected order-convex interval queries are deterministic functions of this same atlas.

The finer `conley_frames` are produced by exactly the same interval-hull construction on the 128 x 96 grid. `authoring/evidence/independent_conley_check.py` verifies in exact rational arithmetic, reading `a`, `b`, and the phase rectangle as exact decimals, that every non-escaping box `B` satisfies `f(|B|) ⊆ |F(B)|` (227,830 boxes, zero violations, minimum slack 6.5e-6), so the rigorous-enclosure statement in the instruction is literally true.

The data are synthetic but realistic: they are deterministic cubical enclosures generated from a standard nonlinear Hénon-family model and preserve the graph, exit-set, continuation, and persistence structures encountered in computational dynamics workflows.

## Difficulty

The hard part is not the number of records. It is that each later object is defined through earlier topological choices, so a locally plausible mistake propagates into many downstream invariants. A solver must first identify recurrent components in a multivalued map, then build relative cubical chain complexes for their exit pairs, then transport those homology classes through inclusions induced by parameter changes. Those maps must agree simultaneously around cycles in the parameter grid; computing pairwise ranks independently is insufficient.

The two-parameter stage is harder than ordinary one-parameter persistence because there is no single barcode that summarizes the module. The same commuting module must support consistent Betti tables, comparable-pair ranks, signed rectangle coefficients, and generalized `lim -> colim` ranks on branching order-convex subposets. These quantities depend on kernels, images, quotients, and compatibility equations over `F_2`. An error in a cell boundary, quotient basis, induced map, or continuation relation can leave nearby dimensions looking reasonable while changing a later syzygy or generalized rank exactly.

The computation also crosses several mathematical representations: directed-graph recurrence, cubical relative homology, canonical annotated graph comparison, continuation correspondences, zigzag diagrams, and finitely presented two-parameter persistence modules. Correctness requires preserving the same recurrent family while moving between those representations, rather than solving each output field independently.

The Conley index stage is the part of computational Conley theory that the exit-pair Betti annotations do not capture: the index map. For each Morse set of a finer enclosure, the solver must build the prescribed index pair `(P1,P0)`, recognize that the continuous Hénon map only lands in the excised pair `(P1 ∪ F(P0), P0 ∪ F(P0))`, and compute the induced endomorphism `incl_*^{-1} f_*` of rational relative homology from a multivalued enclosure, which requires the homology-of-maps machinery (an acyclic-valued chain selector, or the graph-projection construction `q_* p_*^{-1}`) rather than any inclusion map already used in the task. The reported invariants, Leray-reduction dimension and rational invariant factors, are the complete similarity invariant of the Leray reduction and are sign- and orientation-sensitive: flip saddles give `t+1`, ordinary saddles and attractor components `t-1`, and period-two attractors `t^2-1`. An `F_2` computation, a characteristic polynomial of the unreduced map, or an unoriented chain map cannot reproduce them.

The scale-time stage is qualitatively different from another rank table. Each selected path becomes a commutative ladder with alternating horizontal arrows and increasing-scale vertical arrows. The solver must construct all induced maps, verify square commutativity, then form a cochain complex whose coefficients are vertex endomorphism spaces, arrow Hom spaces, and square Hom spaces. Its first cohomology measures infinitesimal representation deformations modulo changes of basis. Ordinary persistent barcodes or corner-to-corner ranks do not determine this quantity.

In real-world research, this work is performed by computational dynamicists, applied topologists, and topological-data-analysis researchers who build rigorous parameter atlases, Conley-index computations, and multiparameter persistence summaries of dynamical systems.

The reference implementation is CPU-only and finishes comfortably inside the task timeout; difficulty comes from the dependent mathematical reasoning and exact implementation, not from resource exhaustion, numerical tolerances, hidden web facts, or output volume.

## Reference solution

The reference pipeline analyzes every frame to obtain recurrent SCCs, the recurrent reachability Hasse graph, attractors, block homology, and exit-pair relative homology. It canonicalizes annotated Morse graphs, partitions the parameter graph into equal-signature regions, and computes continuation relations from SCCs of union maps on adjacent parameters.

It then propagates the public path seeds and global seed. Path exit pairs produce alternating relative-homology zigzags whose generalized interval ranks determine the reported barcodes. The global family supplies the node and edge-union objects used in the cyclic two-dimensional continuation diagrams.

For the same global family, prefix unions over the parameter lattice define a commuting `Z^2` persistence module. The reference implementation computes its module dimensions, bigraded Betti tables, full comparable-pair rank invariant, signed rectangle Möbius decomposition, and generalized ranks on the public non-rectangular intervals. Independently of that parameter bifiltration, public phase-space dilation radii turn selected continuation zigzags into scale-time commutative ladders; the reference computes rectangular generalized ranks and deformation cohomology of those ladder representations.

For every Morse set of each of the 25 finer Conley frames, the reference builds the local index pair, a lower-semicontinuous rectangle-valued chain selector of the enclosure over `Z`, the rational relative homology and the index map after excision, then the Leray reduction and the Smith form of `tI-L` over `Q[t]`.

The committed instance contains 289 parameter maps, 544 parameter edges, 36 public zigzag sweeps, 14,641 rectangular continuation diagrams, 12,000 branching interval restrictions, eight scale-time ladder deformation analyses with 192 public ladder subdiagram queries, and 25 finer Conley frames with 65 Morse sets and their rational index maps. These counts describe coverage; they are not the source of the benchmark's difficulty.

## Verification

The verifier reads only `/app/result.json`. It rejects symlinks, duplicate JSON keys, non-finite JSON tokens, wrong schemas, wrong ordering, and inconsistent public identities. It checks region partitions, reconstructs path ranks from submitted barcode multiplicities, verifies the Hilbert-series identity for the bigraded Betti tables, checks signed-rectangle reconstruction of singleton ranks, and checks generalized-rank dimension bounds, verifies rank and Euler identities for the scale-time deformation complexes, and checks that Conley invariant factors are monic, integral, ordered, divisibility-chained, and of total degree equal to the Leray dimension, and that attractors are exactly the Morse sets without outgoing Hasse edges. Grid headers must be two-integer lists, as the instruction states. It then exact-matches the complete result against the sealed oracle.

The sealed oracle is generated by the committed reference pipeline, so oracle generation alone is not independent evidence. To reduce shared-bug risk in a graded stage, `authoring/evidence/independent_homology_check.py` independently recomputes all recurrent SCC identities plus every `block_betti_F2` and `exit_pair_betti_F2` directly from the public atlas. It imports neither `solution/solve.py` nor `authoring/provenance/generate.py`, uses Kosaraju SCC decomposition instead of the reference Tarjan routine, and computes cubical relative Betti numbers by direct bit-packed boundary-matrix elimination instead of the reference solver's GF(2) basis machinery. The committed report checks all 289 frames and 535 recurrent Morse sets, covering 3,210 graded Betti values with zero mismatches.

A second independent program, `authoring/evidence/independent_conley_check.py`, recomputes every Conley stage value without importing the reference: Kosaraju Morse graphs, the index pairs, and each index map by the graph-projection construction `q_* p_*^{-1}` of the upper-semicontinuous enclosure over the prime field `F_(2^31-1)` (a different mathematical route from the reference chain selector, with relative 4-dimensional graph complexes of up to 253,339 cells), plus three randomized rational chain selectors per Morse set with invariant factors from determinantal divisors instead of a Smith reduction. All 65 Morse sets agree with the oracle, which also confirms that the index maps do not depend on the selector.

These independent checks do not make the entire downstream oracle an independent implementation; it specifically corroborates the core graded topological data from which the continuation and persistence stages are built. `authoring/provenance/GROUND_TRUTH.md` documents the remaining provenance limitation explicitly.

## Research basis

The workflow follows research on global Conley-Morse databases and persistence of changing combinatorial dynamics, including Arai et al. (2009), Dey-Mrozek-Slechta (2020, 2022), Dey-Lipinski-Soriano-Trigueros (2026), and Dey-Haas-Lipinski (2026).

The multiparameter layer is motivated by work on bigraded Betti numbers, rank decompositions, generalized ranks, and persistence modules as bound-quiver representations, including Kim and Moore (2024), Botnan, Oppermann, and Oudot (2025), Guidolin and Landi (2025), Morozov and Scoccola (SoCG 2025), Dey, Kim, and Mémoli (2024), Kim, Kim, and Lee (SoCG 2025), and the commutative-ladder literature of Escolar and Hiraoka. The Conley index stage follows the discrete Conley index for maps and its computation from cubical enclosures: Mrozek (1990), Szymczak (1995), Franks and Richeson (2000), Kaczynski, Mischaikow, and Mrozek (2004), Pilarczyk and Stolot (2008), and Bush et al. (2012). Full citations and scope notes are in `authoring/provenance/SOURCES.md`. The papers motivate the mathematics; they do not provide benchmark answers.

## Authoring files

`authoring/provenance/generate.py` deterministically builds the public atlas and sealed oracle. `authoring/provenance/GROUND_TRUTH.md` records oracle provenance. `authoring/evidence/independent_homology_check.py`, `authoring/evidence/independent_conley_check.py` and their JSON reports provide independent graded cross-checks. `authoring/evidence/structural_check.py` and `validate_local.py` record packaging and verifier checks. Nothing under `authoring/` is copied into the agent environment.
