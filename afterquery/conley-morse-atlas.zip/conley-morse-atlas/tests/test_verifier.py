from pathlib import Path
from verifier_core import validate

def test_result():
    ok,msg=validate(Path('/app/result.json'))
    assert ok,msg
