#!/usr/bin/env python3
"""Deterministically generate the synthetic Hénon-parameter atlas and oracle.

The public data are finite multivalued cubical enclosures of a two-parameter
Hénon family. The oracle is intentionally oracle-derived: after the public
instance is written, this script loads the committed reference solver and
runs it on that instance. No claim of independent ground-truth computation is
made; see GROUND_TRUTH.md.
"""
from pathlib import Path
import importlib.util, json, math, os, shutil, sys, random

ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'environment'/'data'/'atlas.json'
ORACLE=ROOT/'tests'/'oracle.json'
HIDDEN=ROOT/'tests'/'atlas_hidden.json'

NX,NY=42,36
XMIN,XMAX=-2.0,2.0
YMIN,YMAX=-0.8,0.8
NA=NB=17
# Finer enclosures used for rational Conley index maps.
CNX,CNY=128,96
CONLEY_LATTICE=(0,4,8,12,16)
A_VALUES=[round(1.10+0.03*i,12) for i in range(NA)]
B_VALUES=[round(0.17+0.015*j,12) for j in range(NB)]

def build_frame(a,b,NX=NX,NY=NY):
    dx=(XMAX-XMIN)/NX; dy=(YMAX-YMIN)/NY
    offsets=[0]; targets=[]; escapes=[]; eps=1e-12
    for j in range(NY):
        y0=YMIN+j*dy; y1=y0+dy
        for i in range(NX):
            x0=XMIN+i*dx; x1=x0+dx
            sqmin=0.0 if x0<=0<=x1 else min(x0*x0,x1*x1)
            sqmax=max(x0*x0,x1*x1)
            lo=1.0-a*sqmax+y0; hi=1.0-a*sqmin+y1
            vlo=min(b*x0,b*x1); vhi=max(b*x0,b*x1)
            escapes.append(bool(lo<XMIN-eps or hi>XMAX+eps or vlo<YMIN-eps or vhi>YMAX+eps))
            if hi<XMIN-eps or lo>XMAX+eps or vhi<YMIN-eps or vlo>YMAX+eps:
                offsets.append(len(targets)); continue
            i0=max(0,int(math.ceil((lo-XMIN)/dx-1-1e-12)))
            i1=min(NX-1,int(math.floor((hi-XMIN)/dx+1e-12)))
            j0=max(0,int(math.ceil((vlo-YMIN)/dy-1-1e-12)))
            j1=min(NY-1,int(math.floor((vhi-YMIN)/dy+1e-12)))
            for jj in range(j0,j1+1):
                for ii in range(i0,i1+1): targets.append(ii+NX*jj)
            offsets.append(len(targets))
    return {'a':a,'b':b,'offsets':offsets,'targets':targets,'escapes':escapes}

def load_solver():
    path=ROOT/'solution'/'solve.py'
    spec=importlib.util.spec_from_file_location('reference_solver',path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def main():
    frames=[]
    for b in B_VALUES:
        for a in A_VALUES: frames.append(build_frame(a,b))
    edges=[]
    for j in range(NB):
        for i in range(NA):
            p=i+NA*j
            if i+1<NA: edges.append([p,p+1])
            if j+1<NB: edges.append([p,p+NA])
    # First write a temporary atlas without paths, analyze it, then choose a terminal seed
    # at the start of each scientifically prescribed coordinate/diagonal sweep.
    base={'model':{'family':'Henon','formula':['1-a*x^2+y','b*x'],'phase_bounds':[XMIN,XMAX,YMIN,YMAX]},
          'phase_grid':{'nx':NX,'ny':NY},
          'parameter_grid':{'na':NA,'nb':NB,'a_values':A_VALUES,'b_values':B_VALUES},
          'frames':frames,'parameter_edges':edges,'paths':[]}
    solver=load_solver()
    analyses=[solver.analyze_frame(f,NX,NY) for f in frames]
    raw_paths=[]
    # all horizontal sweeps left->right
    for j in range(NB): raw_paths.append([i+NA*j for i in range(NA)])
    # all vertical sweeps bottom->top
    for i in range(NA): raw_paths.append([i+NA*j for j in range(NB)])
    # staircase main diagonal and anti-diagonal
    p=[0]; i=j=0
    while i<NA-1 or j<NB-1:
        if i<NA-1: i+=1; p.append(i+NA*j)
        if j<NB-1: j+=1; p.append(i+NA*j)
    raw_paths.append(p)
    p=[NA-1]; i=NA-1; j=0
    while i>0 or j<NB-1:
        if i>0: i-=1; p.append(i+NA*j)
        if j<NB-1: j+=1; p.append(i+NA*j)
    raw_paths.append(p)
    paths=[]
    for k,ids in enumerate(raw_paths):
        ana=analyses[ids[0]]
        terms=ana['terminals'] or list(range(len(ana['recurrent'])))
        mid=max(terms,key=lambda m:(len(ana['recurrent'][m]),-ana['recurrent'][m][0]))
        seed=ana['recurrent'][mid][0]
        paths.append({'path_id':k,'parameter_ids':ids,'seed_box_id':seed})
    base['paths']=paths
    # A global continuation family is seeded by the largest recurrent set at parameter 0.
    # Its component is propagated over the full parameter graph by the same union-map relation.
    a0=analyses[0]
    gmid=max(range(len(a0['recurrent'])),key=lambda m:(len(a0['recurrent'][m]),-a0['recurrent'][m][0]))
    base['global_continuation_seed']={'parameter_id':0,'seed_box_id':a0['recurrent'][gmid][0]}
    # Multiscale 2D continuation windows: every axis-aligned rectangle with width/height 2..12.
    queries=[]; qid=0
    for h in range(2,13):
        for w in range(2,13):
            for j0 in range(NB-h+1):
                for i0 in range(NA-w+1):
                    queries.append({'window_id':qid,'bounds':[i0,j0,i0+w-1,j0+h-1]}); qid+=1
    base['window_queries']=queries

    # Structured family of genuinely multiparameter intervals.  A query is the
    # induced parameter-grid subposet inside a rectangle and a positive weighted
    # band lo <= alpha*(i-i0)+beta*(j-j0) <= hi.  Positive weights make the band
    # order-convex.  We retain only connected bands with at least two minimal and
    # two maximal elements, so generalized rank cannot collapse to one endpoint map.
    # A fixed PRNG seed makes the public query family exactly reproducible.
    weights=[(1,1),(1,2),(2,1),(2,3),(3,2)]
    sizes=(5,7,9,11,13)
    rng=random.Random(2026092201)
    iq=[]; seen=set(); target_queries=12000
    attempts=0
    while len(iq)<target_queries:
        attempts+=1
        if attempts>500000: raise RuntimeError('could not generate generalized interval query family')
        w=rng.choice(sizes); h=rng.choice(sizes)
        i0=rng.randrange(0,NA-w+1); j0=rng.randrange(0,NB-h+1)
        alpha,beta=rng.choice(weights)
        smax=alpha*(w-1)+beta*(h-1)
        lo=rng.randrange(1,smax)
        widths=(max(alpha,beta)+1,max(alpha,beta)+3,(smax+2)//3,(smax+1)//2)
        hi=min(smax-1,lo+rng.choice(widths))
        if hi<=lo: continue
        key=(i0,j0,i0+w-1,j0+h-1,alpha,beta,lo,hi)
        if key in seen: continue
        seen.add(key)
        pts={(i,j) for j in range(j0,j0+h) for i in range(i0,i0+w)
             if lo <= alpha*(i-i0)+beta*(j-j0) <= hi}
        if len(pts)<8 or len(pts)>60: continue
        start=next(iter(pts)); vis={start}; st=[start]
        while st:
            i,j=st.pop()
            for q in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
                if q in pts and q not in vis:
                    vis.add(q); st.append(q)
        if len(vis)!=len(pts): continue
        minima=sum(1 for i,j in pts if (i-1,j) not in pts and (i,j-1) not in pts)
        maxima=sum(1 for i,j in pts if (i+1,j) not in pts and (i,j+1) not in pts)
        if minima<2 or maxima<2: continue
        iid=len(iq)
        iq.append({'interval_id':iid,'bounds':[i0,j0,i0+w-1,j0+h-1],
                   'weight':[alpha,beta],'level_bounds':[lo,hi]})
    base['generalized_interval_queries']=iq

    # Extended zigzag modules couple continuation time with a nested phase-space
    # dilation scale.  A small set of diverse horizontal, vertical and staircase
    # sweeps is used for full commutativity-deformation analysis; deterministic
    # rectangular restrictions provide generalized-rank probes of the same modules.
    radii=[1,2,3,4,5]
    st_paths=[4,8,16,17,21,29,34,35]
    base['spatiotemporal_scale_radii']=radii
    base['spatiotemporal_deformation_path_ids']=st_paths
    rng2=random.Random(2026092202)
    stq=[]; qid2=0
    for pid in st_paths:
        z=2*len(paths[pid]['parameter_ids'])-1
        seen2=set()
        while len([q for q in stq if q['path_id']==pid])<24:
            r0=rng2.choice((1,2,3)); r1=rng2.randint(r0+1,5)
            width=rng2.choice((7,9,11,13,15,17,21,25))
            width=min(width,z)
            t0=rng2.randrange(0,z-width+1); t1=t0+width-1
            key=(r0,r1,t0,t1)
            if key in seen2: continue
            seen2.add(key)
            stq.append({'query_id':qid2,'path_id':pid,'scale_bounds':[r0,r1],'time_bounds':[t0,t1]})
            qid2+=1
    base['spatiotemporal_queries']=stq

    # Conley-Morse graphs with rational index maps need a finer enclosure than the
    # atlas grid.  The same interval-hull construction is re-run on a 128 x 96 grid
    # of the same phase rectangle at a 5 x 5 sublattice of the parameter grid.
    base['conley_phase_grid']={'nx':CNX,'ny':CNY}
    cframes=[]
    for j in CONLEY_LATTICE:
        for i in CONLEY_LATTICE:
            fr=build_frame(A_VALUES[i],B_VALUES[j],CNX,CNY)
            cframes.append({'conley_frame_id':len(cframes),'parameter_id':i+NA*j,**fr})
    base['conley_frames']=cframes
    DATA.parent.mkdir(parents=True,exist_ok=True)
    DATA.write_text(json.dumps(base,separators=(',',':'))+'\n')
    HIDDEN.write_text(DATA.read_text())
    # Replace the generator process with a fresh reference-solver image; this
    # drops the large temporary frame/analysis heap before exact algebra begins.
    env=dict(os.environ)
    env['ATLAS_INPUT']=str(DATA); env['RESULT_PATH']=str(ORACLE)
    os.execve(sys.executable,[sys.executable,str(ROOT/'solution'/'solve.py')],env)

if __name__=='__main__': main()
