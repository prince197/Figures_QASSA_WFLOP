#!/usr/bin/env python3
"""Independent cross-check of all graded frame homology values.

This program intentionally imports neither solution/solve.py nor authoring/provenance/generate.py.
It uses Kosaraju SCC decomposition and direct bit-packed boundary-matrix elimination,
which are different implementations from the reference solver's Tarjan/GF2-basis code.
"""
from pathlib import Path
import json, hashlib

ROOT = Path(__file__).resolve().parents[2]
ATLAS = json.loads((ROOT / 'environment/data/atlas.json').read_text())
ORACLE = json.loads((ROOT / 'tests/oracle.json').read_text())
nx = ATLAS['phase_grid']['nx']; ny = ATLAS['phase_grid']['ny']; n = nx * ny


def scc_kosaraju(offsets, targets):
    adj=[targets[offsets[v]:offsets[v+1]] for v in range(n)]
    radj=[[] for _ in range(n)]
    for v, outs in enumerate(adj):
        for w in outs: radj[w].append(v)
    seen=[False]*n; order=[]
    for s in range(n):
        if seen[s]: continue
        seen[s]=True; stack=[(s,0)]
        while stack:
            v,k=stack[-1]
            if k < len(adj[v]):
                w=adj[v][k]; stack[-1]=(v,k+1)
                if not seen[w]: seen[w]=True; stack.append((w,0))
            else:
                order.append(v); stack.pop()
    comp=[-1]*n; comps=[]
    for s in reversed(order):
        if comp[s] >= 0: continue
        cid=len(comps); comp[s]=cid; st=[s]; vs=[]
        while st:
            v=st.pop(); vs.append(v)
            for w in radj[v]:
                if comp[w] < 0: comp[w]=cid; st.append(w)
        comps.append(vs)
    return comps, adj


def recurrent_sets(offsets, targets):
    comps, adj=scc_kosaraju(offsets, targets)
    out=[]
    for vs in comps:
        if len(vs)>1 or (len(vs)==1 and vs[0] in adj[vs[0]]):
            out.append(sorted(vs))
    out.sort(key=lambda x:min(x))
    return out


def cheb_neighborhood(boxes):
    out=set()
    for q in boxes:
        i=q%nx; j=q//nx
        for dj in (-1,0,1):
            y=j+dj
            if 0<=y<ny:
                for di in (-1,0,1):
                    x=i+di
                    if 0<=x<nx: out.add(x+nx*y)
    return out


def pair_cells(boxes):
    c0=set(); c1=set(); c2=set()
    for q in boxes:
        x=q%nx; y=q//nx
        c2.add((x,y))
        c1.add((0,x,y)); c1.add((0,x,y+1))      # horizontal
        c1.add((1,x,y)); c1.add((1,x+1,y))      # vertical
        c0.add((x,y)); c0.add((x+1,y)); c0.add((x,y+1)); c0.add((x+1,y+1))
    return c0,c1,c2


def gf2_rank(columns):
    piv={}; r=0
    for x in columns:
        y=x
        while y:
            p=y.bit_length()-1
            if p in piv: y ^= piv[p]
            else:
                piv[p]=y; r+=1; break
    return r


def betti_pair(N, L):
    n0,n1,n2=pair_cells(N); l0,l1,l2=pair_cells(L)
    b0=sorted(n0-l0); b1=sorted(n1-l1); b2=sorted(n2-l2)
    i0={c:k for k,c in enumerate(b0)}; i1={c:k for k,c in enumerate(b1)}
    d1=[]
    for ori,x,y in b1:
        ends=((x,y),(x+1,y)) if ori==0 else ((x,y),(x,y+1))
        col=0
        for e in ends:
            k=i0.get(e)
            if k is not None: col ^= 1<<k
        d1.append(col)
    d2=[]
    for x,y in b2:
        edges=((0,x,y),(0,x,y+1),(1,x,y),(1,x+1,y))
        col=0
        for e in edges:
            k=i1.get(e)
            if k is not None: col ^= 1<<k
        d2.append(col)
    r1=gf2_rank(d1); r2=gf2_rank(d2)
    return [len(b0)-r1, len(b1)-r1-r2, len(b2)-r2]


def exit_pair(M, frame):
    N=cheb_neighborhood(M); L=set()
    offsets=frame['offsets']; targets=frame['targets']; escapes=frame['escapes']
    for q in N:
        if escapes[q] or any(r not in N for r in targets[offsets[q]:offsets[q+1]]):
            L.add(q)
    return N,L

mismatches=[]; checked=0
for pid,frame in enumerate(ATLAS['frames']):
    rec=recurrent_sets(frame['offsets'],frame['targets'])
    expected=ORACLE['frames'][pid]['morse_sets']
    if len(rec)!=len(expected):
        mismatches.append({'parameter_id':pid,'kind':'recurrent_count','got':len(rec),'expected':len(expected)})
        continue
    for mid,(M,e) in enumerate(zip(rec,expected)):
        got_block=betti_pair(set(M),set())
        N,L=exit_pair(M,frame); got_exit=betti_pair(N,L)
        checked+=1
        if min(M)!=e['min_box_id'] or len(M)!=e['size']:
            mismatches.append({'parameter_id':pid,'morse_id':mid,'kind':'scc_identity'})
        if got_block!=e['block_betti_F2']:
            mismatches.append({'parameter_id':pid,'morse_id':mid,'kind':'block_betti','got':got_block,'expected':e['block_betti_F2']})
        if got_exit!=e['exit_pair_betti_F2']:
            mismatches.append({'parameter_id':pid,'morse_id':mid,'kind':'exit_pair_betti','got':got_exit,'expected':e['exit_pair_betti_F2']})

report={
    'pass': not mismatches,
    'method': 'independent Kosaraju SCC + direct bit-packed relative cubical boundary ranks over F2',
    'imports_reference_solver': False,
    'frames_checked': len(ATLAS['frames']),
    'morse_sets_checked': checked,
    'graded_values_checked': checked*6,
    'mismatch_count': len(mismatches),
    'mismatches': mismatches[:20],
    'atlas_sha256': hashlib.sha256((ROOT/'environment/data/atlas.json').read_bytes()).hexdigest(),
    'oracle_sha256': hashlib.sha256((ROOT/'tests/oracle.json').read_bytes()).hexdigest(),
}
(ROOT/'authoring/evidence/independent_homology_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['pass'] else 1)
