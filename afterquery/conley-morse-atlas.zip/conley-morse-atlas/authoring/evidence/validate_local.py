#!/usr/bin/env python3
from pathlib import Path
import importlib.util,json,math,tempfile,os,copy
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('verifier',ROOT/'tests/verifier_core.py')
V=importlib.util.module_from_spec(spec); spec.loader.exec_module(V)
oracle=json.loads((ROOT/'tests/oracle.json').read_text())

def check(obj):
    fd,path=tempfile.mkstemp(suffix='.json');os.close(fd);p=Path(path)
    p.write_text(json.dumps(obj,separators=(',',':')))
    ok,msg=V.validate(p);p.unlink();return ok,msg
def nilpotent_record(x):
    return next(r for g in x['conley_morse_graphs'] for m in g['morse_sets'] if m['conley_index'] for r in m['conley_index'] if r['homology_dimension_Q']>=2 and r['leray_dimension_Q']==0)
cases={}
cases['reference']=check(oracle)[0]
# no-op / incomplete
cases['empty']=check({})[0]
# targeted mutations
for name,mut in [
 ('morse_betti',lambda x:x['frames'][0]['morse_sets'][0]['block_betti_F2'].__setitem__(0,x['frames'][0]['morse_sets'][0]['block_betti_F2'][0]+1)),
 ('event_type',lambda x:x['parameter_edge_events'][0].__setitem__('event_type','birth' if x['parameter_edge_events'][0]['event_type']!='birth' else 'death')),
 ('region_member',lambda x:x['regions'][0]['parameter_ids'].__setitem__(0,999999)),
 ('zigzag_rank',lambda x:x['continuation_barcodes'][0]['dimensions'][1]['rank_rows_F2'][0].__setitem__(0,x['continuation_barcodes'][0]['dimensions'][1]['rank_rows_F2'][0][0]+1)),
 ('barcode',lambda x:x['continuation_barcodes'][0]['dimensions'][1]['interval_multiplicities_F2'][0].__setitem__('multiplicity',x['continuation_barcodes'][0]['dimensions'][1]['interval_multiplicities_F2'][0]['multiplicity']+1)),
 ('surface_selection',lambda x:x['continuation_surface']['selected_morse_ids_by_parameter'][0].append(999999)),
 ('surface_rank',lambda x:x['continuation_surface']['window_ranks_F2'][0]['rank_F2'].__setitem__(1,x['continuation_surface']['window_ranks_F2'][0]['rank_F2'][1]+1)),
 ('mp_betti',lambda x:x['multiparameter_persistence']['dimensions'][1]['betti_tables_F2'][0]['nonzero_grades'][0].__setitem__(2,x['multiparameter_persistence']['dimensions'][1]['betti_tables_F2'][0]['nonzero_grades'][0][2]+1)),
 ('mp_rectangle',lambda x:x['multiparameter_persistence']['dimensions'][1]['signed_rectangle_rank_decomposition'][0].__setitem__('multiplicity',x['multiparameter_persistence']['dimensions'][1]['signed_rectangle_rank_decomposition'][0]['multiplicity']+1)),
 ('generalized_interval_rank',lambda x:x['multiparameter_persistence']['generalized_interval_ranks_F2'][0]['dimensions'][1].__setitem__('generalized_rank_F2',x['multiparameter_persistence']['generalized_interval_ranks_F2'][0]['dimensions'][1]['generalized_rank_F2']+1)),
 ('generalized_interval_limit',lambda x:x['multiparameter_persistence']['generalized_interval_ranks_F2'][0]['dimensions'][1].__setitem__('limit_dimension_F2',x['multiparameter_persistence']['generalized_interval_ranks_F2'][0]['dimensions'][1]['limit_dimension_F2']+1)),
 ('spatiotemporal_rank',lambda x:x['spatiotemporal_persistence']['query_ranks_F2'][0]['dimensions'][1].__setitem__('generalized_rank_F2',x['spatiotemporal_persistence']['query_ranks_F2'][0]['dimensions'][1]['generalized_rank_F2']+1)),
 ('conley_factor_sign',lambda x:next(r for g in x['conley_morse_graphs'] for m in g['morse_sets'] if m['conley_index'] for r in m['conley_index'] if r['invariant_factors_Q'] and r['invariant_factors_Q'][0]==[1,1])['invariant_factors_Q'].__setitem__(0,[-1,1])),
 ('conley_mod2_factor',lambda x:next(r for g in x['conley_morse_graphs'] for m in g['morse_sets'] if m['conley_index'] for r in m['conley_index'] if r['invariant_factors_Q']==[[-1,0,1]])['invariant_factors_Q'].__setitem__(0,[1,0,1])),
 ('conley_nilpotent_as_leray',lambda x:nilpotent_record(x).update({'leray_dimension_Q':nilpotent_record(x)['homology_dimension_Q'],'invariant_factors_Q':[[0]*nilpotent_record(x)['homology_dimension_Q']+[1]]})),
 ('conley_homology_dim',lambda x:next(r for g in x['conley_morse_graphs'] for m in g['morse_sets'] if m['conley_index'] for r in m['conley_index'] if r['homology_dimension_Q']>=3).__setitem__('homology_dimension_Q',2)),
 ('conley_null',lambda x:next(m for g in x['conley_morse_graphs'] for m in g['morse_sets'] if m['conley_index']).__setitem__('conley_index',None)),
 ('conley_attractor',lambda x:x['conley_morse_graphs'][0]['morse_sets'][0].__setitem__('attractor',not x['conley_morse_graphs'][0]['morse_sets'][0]['attractor'])),
 ('grid_object_encoding',lambda x:x.update({'phase_grid':{'nx':x['phase_grid'][0],'ny':x['phase_grid'][1]},'parameter_grid':{'na':x['parameter_grid'][0],'nb':x['parameter_grid'][1]}})),
 ('deformation_h1',lambda x:x['spatiotemporal_persistence']['deformation_cohomology_F2'][0]['dimensions'][1].__setitem__('h1_F2',x['spatiotemporal_persistence']['deformation_cohomology_F2'][0]['dimensions'][1]['h1_F2']+1)),
]:
    y=copy.deepcopy(oracle)
    try: mut(y); cases[name]=check(y)[0]
    except Exception: cases[name]=False
# duplicate-key and nonfinite lexical attacks
for name,text in [('duplicate','{"phase_grid":[1,1],"phase_grid":[1,1]}'),('nonfinite','{"x":NaN}')]:
    fd,path=tempfile.mkstemp();os.close(fd);p=Path(path);p.write_text(text);cases[name]=V.validate(p)[0];p.unlink()
pretty=Path(tempfile.mkstemp(suffix='.json')[1]); pretty.write_text(json.dumps(oracle,indent=4)); pretty_bytes=pretty.stat().st_size; pretty_ok=V.validate(pretty)[0]; pretty.unlink()
report={'reference_reward':1 if cases['reference'] else 0,'pretty_print_indent4_reward':1 if pretty_ok else 0,'pretty_print_indent4_bytes':pretty_bytes,'adversarial_rewards':{k:1 if v else 0 for k,v in cases.items() if k!='reference'},'all_adversarial_zero':all(not v for k,v in cases.items() if k!='reference')}
(ROOT/'authoring/evidence/validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['reference_reward']==1 and report['pretty_print_indent4_reward']==1 and report['all_adversarial_zero'] else 1)
