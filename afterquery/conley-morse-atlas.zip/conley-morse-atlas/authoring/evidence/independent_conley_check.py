#!/usr/bin/env python3
"""Independent cross-check of the rational Conley index stage.

This program imports neither solution/solve.py nor authoring/provenance/generate.py.
It checks, from the public atlas and sealed oracle only:

1. exact rational enclosure: f(|B|) is contained in |F(B)| for every non-escaping box
   of every conley frame, with a, b and the phase rectangle read as exact decimals;
2. the Morse sets (Kosaraju SCCs), attractors and recurrent Hasse edges;
3. the index maps by a different method from the reference chain selector: the
   graph Gamma = union_{B in P1} B x |F(B)| of the upper-semicontinuous enclosure,
   Gamma0 = union_{B in P0} B x |F(B)|, and f_P = q_* p_*^{-1} over the prime field
   F_p (p = 2^31-1), with homology, Leray dimension, and invariant factors over F_p[t]
   compared with the oracle's rational invariant factors reduced mod p;
4. selector independence over Q: every index map is recomputed exactly with several
   randomized chain selectors (random vertex choices, random lattice-path shapes)
   and invariant factors from determinantal divisors instead of a Smith reduction.
"""
from pathlib import Path
from fractions import Fraction as Fr
import json, hashlib, random, sys, time

ROOT = Path(__file__).resolve().parents[2]
ATLAS_TEXT = (ROOT / 'environment/data/atlas.json').read_text()
ATLAS = json.loads(ATLAS_TEXT)
ORACLE_TEXT = (ROOT / 'tests/oracle.json').read_text()
ORACLE = json.loads(ORACLE_TEXT)
NX = ATLAS['conley_phase_grid']['nx']; NY = ATLAS['conley_phase_grid']['ny']; N = NX * NY
P = 2**31 - 1
GRAPH_SIZE_LIMIT = int(sys.argv[1]) if len(sys.argv) > 1 else 260

# ----------------------------------------------------------------- 1. exact enclosure
def enclosure_check():
    xmin, xmax, ymin, ymax = [Fr(repr(v)) for v in ATLAS['model']['phase_bounds']]
    dx = (xmax - xmin) / NX; dy = (ymax - ymin) / NY
    checked = viol = 0; minslack = None
    for fr in ATLAS['conley_frames']:
        a = Fr(repr(fr['a'])); b = Fr(repr(fr['b']))
        o, t, e = fr['offsets'], fr['targets'], fr['escapes']
        for q in range(N):
            if e[q]: continue
            i, j = q % NX, q // NX
            x0 = xmin + i*dx; x1 = x0 + dx; y0 = ymin + j*dy; y1 = y0 + dy
            s0 = Fr(0) if x0 <= 0 <= x1 else min(x0*x0, x1*x1); s1 = max(x0*x0, x1*x1)
            lo, hi = 1 - a*s1 + y0, 1 - a*s0 + y1
            vlo, vhi = min(b*x0, b*x1), max(b*x0, b*x1)
            T = t[o[q]:o[q+1]]
            L = xmin + (T[0] % NX)*dx; R = xmin + (T[-1] % NX + 1)*dx
            B = ymin + (T[0] // NX)*dy; U = ymin + (T[-1] // NX + 1)*dy
            rect = [c + NX*r for r in range(T[0]//NX, T[-1]//NX + 1) for c in range(T[0] % NX, T[-1] % NX + 1)]
            slack = min(lo - L, R - hi, vlo - B, U - vhi)
            checked += 1
            if rect != T or slack < 0 or lo < xmin or hi > xmax or vlo < ymin or vhi > ymax: viol += 1
            minslack = slack if minslack is None else min(minslack, slack)
    return {'nonescaping_boxes_checked': checked, 'violations': viol,
            'min_slack_in_phase_units': float(minslack)}

# ----------------------------------------------------------------- 2. Morse graphs
def kosaraju(o, t):
    adj = [t[o[v]:o[v+1]] for v in range(N)]
    radj = [[] for _ in range(N)]
    for v, outs in enumerate(adj):
        for w in outs: radj[w].append(v)
    seen = [False]*N; order = []
    for s in range(N):
        if seen[s]: continue
        seen[s] = True; st = [(s, 0)]
        while st:
            v, k = st[-1]
            if k < len(adj[v]):
                st[-1] = (v, k+1); w = adj[v][k]
                if not seen[w]: seen[w] = True; st.append((w, 0))
            else:
                order.append(v); st.pop()
    comp = [-1]*N; comps = []
    for s in reversed(order):
        if comp[s] >= 0: continue
        c = len(comps); comp[s] = c; st = [s]; vs = []
        while st:
            v = st.pop(); vs.append(v)
            for w in radj[v]:
                if comp[w] < 0: comp[w] = c; st.append(w)
        comps.append(vs)
    return comps, comp, adj

def morse_graph(fr):
    comps, comp, adj = kosaraju(fr['offsets'], fr['targets'])
    rec = sorted((sorted(c) for c in comps if len(c) > 1 or c[0] in adj[c[0]]), key=lambda c: c[0])
    rid = {comp[c[0]]: k for k, c in enumerate(rec)}
    reach = []
    for c in rec:
        seen = set(c); st = list(c)
        while st:
            v = st.pop()
            for w in adj[v]:
                if w not in seen: seen.add(w); st.append(w)
        reach.append({rid[comp[v]] for v in seen if comp[v] in rid} - {rid[comp[c[0]]]})
    edges = sorted([i, j] for i in range(len(rec)) for j in reach[i]
                   if not any(j in reach[k] for k in reach[i] if k != j))
    return rec, edges, [not r for r in reach]

def index_pair(M, fr):
    o, t = fr['offsets'], fr['targets']
    nb = set()
    for q in M:
        i, j = q % NX, q // NX
        for jj in range(max(0, j-1), min(NY, j+2)):
            for ii in range(max(0, i-1), min(NX, i+2)): nb.add(ii + NX*jj)
        nb.update(t[o[q]:o[q+1]])
    P1 = set(M); st = list(M)
    while st:
        v = st.pop()
        for w in t[o[v]:o[v+1]]:
            if w in nb and w not in P1: P1.add(w); st.append(w)
    return P1, P1 - set(M)

# ----------------------------------------------------------------- cubical helpers
# A cell of the plane is (i, j, ei, ej): the product [i, i+ei] x [j, j+ej].
def faces_of_box(i, j):
    return [(i+a, j+b, ei, ej) for ei in (0, 1) for ej in (0, 1)
            for a in ((0, 1) if ei == 0 else (0,)) for b in ((0, 1) if ej == 0 else (0,))]

def cell_dim(c): return c[2] + c[3]

def cell_boundary(c):
    i, j, ei, ej = c
    out = []
    if ei: out += [((i+1, j, 0, ej), 1), ((i, j, 0, ej), -1)]
    if ej:
        s = -1 if ei else 1
        out += [((i, j+1, ei, 0), s), ((i, j, ei, 0), -s)]
    return out

def rect_cells(I0, I1, J0, J1):
    return [(i, j, ei, ej) for ei in (0, 1) for ej in (0, 1)
            for i in range(I0, I1 + 1 - ei) for j in range(J0, J1 + 1 - ej)]

def in_rect(c, r):
    i, j, ei, ej = c; I0, I1, J0, J1 = r
    return I0 <= i and i + ei <= I1 and J0 <= j and j + ej <= J1

def box_rect(fr, q):
    o, t = fr['offsets'], fr['targets']; lo, hi = t[o[q]], t[o[q+1]-1]
    return (lo % NX, hi % NX + 1, lo // NX, hi // NX + 1)

def rel_cells(M, P0):
    K = set()
    for q in M: K.update(faces_of_box(q % NX, q // NX))
    K0 = set()
    for q in P0: K0.update(faces_of_box(q % NX, q // NX))
    return sorted(K - K0)

# ----------------------------------------------------------------- F_p linear algebra
class FpBasis:
    def __init__(self): self.piv = {}
    def reduce(self, v, lab):
        v = dict(v); lab = dict(lab)
        while v:
            p = max(v)
            if p not in self.piv: return v, lab, p
            bv, bl = self.piv[p]; c = v[p]
            for k, x in bv.items():
                y = (v.get(k, 0) - c*x) % P
                if y: v[k] = y
                else: v.pop(k, None)
            for k, x in bl.items():
                y = (lab.get(k, 0) - c*x) % P
                if y: lab[k] = y
                else: lab.pop(k, None)
        return v, lab, None
    def add(self, v, lab):
        v, lab, p = self.reduce(v, lab)
        if p is None: return False, lab
        inv = pow(v[p], P-2, P)
        self.piv[p] = ({k: x*inv % P for k, x in v.items()}, {k: x*inv % P for k, x in lab.items()})
        return True, lab

def homology_fp(cells_by_dim, bmat, dmax=2):
    """cells_by_dim[d] list; bmat[d][k] = boundary vector of cell k of dim d.  Returns reps and coord basis."""
    out = []
    for d in range(dmax + 1):
        if d == 0: Z = [{k: 1} for k in range(len(cells_by_dim[0]))]
        else:
            b = FpBasis(); Z = []
            for j, col in enumerate(bmat[d]):
                ok, lab = b.add(col, {j: 1})
                if not ok: Z.append(lab)
        coord = FpBasis(); H = []
        for k, col in enumerate(bmat[d+1] if d + 1 < len(bmat) else []): coord.add(col, {('b', k): 1})
        for z in Z:
            ok, _ = coord.add(z, {('h', len(H)): 1})
            if ok: H.append(z)
        out.append((H, coord))
    return out

def express(coord, v, n):
    rem, lab, _ = coord.reduce(v, {})
    if rem: raise RuntimeError('not a relative cycle')
    return [(-lab.get(('h', r), 0)) % P for r in range(n)]

def mat_inv_fp(A):
    n = len(A); M = [row[:] + [1 if i == j else 0 for j in range(n)] for i, row in enumerate(A)]
    for c in range(n):
        r = next(r for r in range(c, n) if M[r][c])
        M[c], M[r] = M[r], M[c]; inv = pow(M[c][c], P-2, P)
        M[c] = [x*inv % P for x in M[c]]
        for r in range(n):
            if r != c and M[r][c]:
                f = M[r][c]; M[r] = [(x - f*y) % P for x, y in zip(M[r], M[c])]
    return [row[n:] for row in M]

def mat_mul_fp(A, B):
    return [[sum(A[i][k]*B[k][j] for k in range(len(B))) % P for j in range(len(B[0]))] for i in range(len(A))]

def rank_fp(A):
    b = FpBasis(); r = 0
    for j in range(len(A[0]) if A else 0):
        if b.add({i: A[i][j] for i in range(len(A)) if A[i][j]}, {})[0]: r += 1
    return r

def leray_fp(A):
    n = len(A)
    if n == 0: return []
    Pw = A
    for _ in range(n - 1): Pw = mat_mul_fp(Pw, A)
    b = FpBasis(); basis = []
    for j in range(n):
        v = {i: Pw[i][j] for i in range(n) if Pw[i][j]}
        if b.add(v, {})[0]: basis.append(v)
    coord = FpBasis()
    for k, v in enumerate(basis): coord.add(v, {k: 1})
    L = [[0]*len(basis) for _ in basis]
    for c, v in enumerate(basis):
        w = {i: s for i in range(n) for s in [sum(A[i][k]*x for k, x in v.items()) % P] if s}
        rem, lab, _ = coord.reduce(w, {})
        assert not rem
        for r in range(len(basis)): L[r][c] = (-lab.get(r, 0)) % P
    return L

# polynomials over F_p, low -> high
def ptrim(p):
    p = [x % P for x in p]
    while p and p[-1] == 0: p.pop()
    return p
def psub(p, q): return ptrim([(p[i] if i < len(p) else 0) - (q[i] if i < len(q) else 0) for i in range(max(len(p), len(q)))])
def pmul(p, q):
    if not p or not q: return []
    out = [0]*(len(p)+len(q)-1)
    for i, a in enumerate(p):
        for j, b in enumerate(q): out[i+j] = (out[i+j] + a*b) % P
    return ptrim(out)
def pdivmod(p, q):
    p = ptrim(p); quo = [0]*max(1, len(p)-len(q)+1); inv = pow(q[-1], P-2, P)
    while p and len(p) >= len(q):
        c = p[-1]*inv % P; s = len(p)-len(q); quo[s] = c
        p = psub(p, [0]*s + [c*x for x in q])
    return ptrim(quo), p
def pgcd(a, b):
    a, b = ptrim(a), ptrim(b)
    while b: a, b = b, pdivmod(a, b)[1]
    return [x*pow(a[-1], P-2, P) % P for x in a] if a else a

def invariant_factors_fp(L):
    """Invariant factors of tI-L over F_p[t] from determinantal divisors (L is tiny)."""
    from itertools import combinations
    m = len(L)
    X = [[ptrim(([-L[i][j], 1] if i == j else [-L[i][j]])) for j in range(m)] for i in range(m)]
    def det(rows, cols):
        if len(rows) == 1: return X[rows[0]][cols[0]]
        out = []
        for k, c in enumerate(cols):
            sub = det(rows[1:], cols[:k] + cols[k+1:])
            term = pmul(X[rows[0]][c], sub)
            out = psub(out, term) if k % 2 else psub(out, [(-x) % P for x in term])
        return out
    D = [[1]]
    for k in range(1, m+1):
        g = []
        for rows in combinations(range(m), k):
            for cols in combinations(range(m), k):
                g = pgcd(g, det(list(rows), list(cols)))
        D.append(g)
    facs = [pdivmod(D[k], D[k-1])[0] for k in range(1, m+1)]
    return [f for f in facs if len(f) > 1]

# ----------------------------------------------------------------- 3. graph method
def graph_index_maps(M, fr):
    P1, P0 = index_pair(M, fr)
    rects = {q: box_rect(fr, q) for q in P1}
    rel = rel_cells(M, P0)
    rel_idx = {c: k for k, c in enumerate(rel)}
    base_cells = [[c for c in rel if cell_dim(c) == d] for d in range(3)]
    base_idx = [{c: k for k, c in enumerate(base_cells[d])} for d in range(3)]
    bmat_base = [[]]
    for d in (1, 2):
        cols = []
        for c in base_cells[d]:
            v = {}
            for f, s in cell_boundary(c):
                k = base_idx[d-1].get(f)
                if k is not None: v[k] = (v.get(k, 0) + s) % P
            cols.append({k: x for k, x in v.items() if x})
        bmat_base.append(cols)
    base_h = homology_fp(base_cells, bmat_base + [[]])
    # graph cells sigma x tau not in Gamma0
    boxes_by_face = {}
    for q in P1:
        for c in faces_of_box(q % NX, q // NX): boxes_by_face.setdefault(c, []).append(q)
    def in_gamma(s, t):
        return any(in_rect(t, rects[q]) for q in boxes_by_face.get(s, ()))
    def in_gamma0(s, t):
        return any(q in P0 and in_rect(t, rects[q]) for q in boxes_by_face.get(s, ()))
    gcells = set()
    for q in M:
        for s in faces_of_box(q % NX, q // NX):
            if s not in rel_idx and all(b in P0 for b in boxes_by_face[s]):
                continue
            for b in boxes_by_face[s]:
                for t in rect_cells(*rects[b]):
                    if cell_dim(s) + cell_dim(t) <= 3 and not in_gamma0(s, t): gcells.add((s, t))
    gd = [[] for _ in range(4)]
    for s, t in gcells: gd[cell_dim(s) + cell_dim(t)].append((s, t))
    for d in range(4): gd[d].sort()
    gidx = [{c: k for k, c in enumerate(gd[d])} for d in range(4)]
    gb = [[]]
    for d in range(1, 4):
        cols = []
        for s, t in gd[d]:
            v = {}
            sign = -1 if cell_dim(s) % 2 else 1
            for f, e in cell_boundary(s):
                k = gidx[d-1].get((f, t))
                if k is not None: v[k] = (v.get(k, 0) + e) % P
                elif in_gamma(f, t) and not in_gamma0(f, t): raise RuntimeError('missing graph face')
            for f, e in cell_boundary(t):
                k = gidx[d-1].get((s, f))
                if k is not None: v[k] = (v.get(k, 0) + sign*e) % P
                elif in_gamma(s, f) and not in_gamma0(s, f): raise RuntimeError('missing graph face')
            cols.append({k: x for k, x in v.items() if x})
        gb.append(cols)
    gh = homology_fp(gd, gb)
    maps = []
    for d in range(3):
        H, _ = gh[d]; bH, bcoord = base_h[d]
        n = len(bH)
        if len(H) != n: raise RuntimeError('Vietoris-Begle dimension mismatch')
        Pm = []; Qm = []
        for h in H:
            pv = {}; qv = {}
            for k, c in h.items():
                s, t = gd[d][k]
                if cell_dim(t) == 0:
                    j = base_idx[d].get(s)
                    if j is not None: pv[j] = (pv.get(j, 0) + c) % P
                if cell_dim(s) == 0:
                    j = base_idx[d].get(t)
                    if j is not None: qv[j] = (qv.get(j, 0) + c) % P
            Pm.append(express(bcoord, {k: x for k, x in pv.items() if x}, n))
            Qm.append(express(bcoord, {k: x for k, x in qv.items() if x}, n))
        if n == 0: maps.append([]); continue
        Pm = [[Pm[c][r] for c in range(n)] for r in range(n)]
        Qm = [[Qm[c][r] for c in range(n)] for r in range(n)]
        if rank_fp(Pm) != n: raise RuntimeError('projection is not an isomorphism')
        maps.append(mat_mul_fp(Qm, mat_inv_fp(Pm)))
    return maps, sum(len(x) for x in gd)

# ----------------------------------------------------------------- 4. randomized selectors over Q
class QBasis(FpBasis):
    def reduce(self, v, lab):
        v = dict(v); lab = dict(lab)
        while v:
            p = max(v)
            if p not in self.piv: return v, lab, p
            bv, bl = self.piv[p]; c = v[p]
            for k, x in bv.items():
                y = v.get(k, 0) - c*x
                if y: v[k] = y
                else: v.pop(k, None)
            for k, x in bl.items():
                y = lab.get(k, 0) - c*x
                if y: lab[k] = y
                else: lab.pop(k, None)
        return v, lab, None
    def add(self, v, lab):
        v, lab, p = self.reduce(v, lab)
        if p is None: return False, lab
        c = v[p]
        self.piv[p] = ({k: Fr(x)/c for k, x in v.items()}, {k: Fr(x)/c for k, x in lab.items()})
        return True, lab

def random_selector_maps(M, fr, rng):
    P1, P0 = index_pair(M, fr)
    rects = {q: box_rect(fr, q) for q in P1}
    boxes_by_face = {}
    for q in P1:
        for c in faces_of_box(q % NX, q // NX): boxes_by_face.setdefault(c, []).append(q)
    def value(c):
        rs = [rects[q] for q in boxes_by_face[c]]
        r = (max(x[0] for x in rs), min(x[1] for x in rs), max(x[2] for x in rs), min(x[3] for x in rs))
        if r[0] > r[1] or r[2] > r[3]: raise RuntimeError('empty value')
        return r
    memo = {}
    def phi(c):
        if c in memo: return memo[c]
        I0, I1, J0, J1 = value(c); d = cell_dim(c); out = {}
        def acc(e, s):
            y = out.get(e, 0) + s
            if y: out[e] = y
            else: out.pop(e, None)
        if d == 0:
            out = {(rng.randint(I0, I1), rng.randint(J0, J1), 0, 0): 1}
        elif d == 1:
            ends = [f for f, s in sorted(cell_boundary(c), key=lambda z: z[1])]
            (a,), (b,) = phi(ends[0]).keys(), phi(ends[1]).keys()
            way = (rng.randint(I0, I1), rng.randint(J0, J1))
            x, y = a[0], a[1]
            for tx, ty in (way, (b[0], b[1])):
                steps = ['h']*abs(tx-x) + ['v']*abs(ty-y); rng.shuffle(steps)
                for st in steps:
                    if st == 'h':
                        if tx > x: acc((x, y, 1, 0), 1); x += 1
                        else: acc((x-1, y, 1, 0), -1); x -= 1
                    else:
                        if ty > y: acc((x, y, 0, 1), 1); y += 1
                        else: acc((x, y-1, 0, 1), -1); y -= 1
        else:
            z = {}
            for f, s in cell_boundary(c):
                for e, x in phi(f).items():
                    y = z.get(e, 0) + s*x
                    if y: z[e] = y
                    else: z.pop(e, None)
            # fill by rows: boundary of square (i,j,1,1) has -1 on vertical edge (i,j,0,1)
            for (i, j, ei, ej), x in z.items():
                if ej == 1 and ei == 0:
                    for ii in range(I0, i): acc((ii, j, 1, 1), x)
            chk = {}
            for sq, x in out.items():
                for f, s in cell_boundary(sq):
                    y = chk.get(f, 0) + s*x
                    if y: chk[f] = y
                    else: chk.pop(f, None)
            if chk != z: raise RuntimeError('fill failed')
        memo[c] = out
        return out
    rel = rel_cells(M, P0)
    cells = [[c for c in rel if cell_dim(c) == d] for d in range(3)]
    idx = [{c: k for k, c in enumerate(cells[d])} for d in range(3)]
    def vec(ch, d):
        v = {}
        for c, s in ch.items():
            k = idx[d].get(c)
            if k is not None: v[k] = v.get(k, 0) + s
        return {k: Fr(x) for k, x in v.items() if x}
    bmat = [[], [vec(dict(cell_boundary(c)), 0) for c in cells[1]], [vec(dict(cell_boundary(c)), 1) for c in cells[2]], []]
    maps = []
    for d in range(3):
        if d == 0: Z = [{k: Fr(1)} for k in range(len(cells[0]))]
        else:
            b = QBasis(); Z = []
            for j, col in enumerate(bmat[d]):
                ok, lab = b.add(col, {j: Fr(1)})
                if not ok: Z.append(lab)
        coord = QBasis(); H = []
        for k, col in enumerate(bmat[d+1]): coord.add(col, {('b', k): 1})
        for z in Z:
            ok, _ = coord.add(z, {('h', len(H)): 1})
            if ok: H.append(z)
        cols = []
        for h in H:
            ch = {}
            for k, x in h.items():
                for e, s in phi(cells[d][k]).items(): ch[e] = ch.get(e, 0) + x*s
            rem, lab, _ = coord.reduce(vec(ch, d), {})
            if rem: raise RuntimeError('selector image not a relative cycle')
            cols.append([-Fr(lab.get(('h', r), 0)) for r in range(len(H))])
        maps.append([[cols[c][r] for c in range(len(H))] for r in range(len(H))])
    return maps

def q_invariants(A):
    """(dim, Leray dim, invariant factors over Q) with factors from determinantal divisors."""
    from itertools import combinations
    n = len(A)
    if n == 0: return (0, 0, [])
    Pw = A
    for _ in range(n - 1):
        Pw = [[sum(Pw[i][k]*A[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
    b = QBasis(); basis = []
    for j in range(n):
        v = {i: Pw[i][j] for i in range(n) if Pw[i][j]}
        if b.add(v, {})[0]: basis.append(v)
    coord = QBasis()
    for k, v in enumerate(basis): coord.add(v, {k: 1})
    m = len(basis); L = [[Fr(0)]*m for _ in range(m)]
    for c, v in enumerate(basis):
        w = {i: s for i in range(n) for s in [sum(A[i][k]*x for k, x in v.items())] if s}
        rem, lab, _ = coord.reduce(w, {})
        for r in range(m): L[r][c] = -Fr(lab.get(r, 0))
    def tr(p):
        p = list(p)
        while p and p[-1] == 0: p.pop()
        return p
    def sub(p, q): return tr([(p[i] if i < len(p) else 0) - (q[i] if i < len(q) else 0) for i in range(max(len(p), len(q)))])
    def mul(p, q):
        if not p or not q: return []
        o = [Fr(0)]*(len(p)+len(q)-1)
        for i, a in enumerate(p):
            for j, bb in enumerate(q): o[i+j] += a*bb
        return tr(o)
    def dm(p, q):
        p = tr(p); quo = [Fr(0)]*max(1, len(p)-len(q)+1)
        while p and len(p) >= len(q):
            c = p[-1]/q[-1]; s = len(p)-len(q); quo[s] = c; p = sub(p, [Fr(0)]*s + [c*x for x in q])
        return tr(quo), p
    def gcd(a, bb):
        a, bb = tr(a), tr(bb)
        while bb: a, bb = bb, dm(a, bb)[1]
        return [x/a[-1] for x in a] if a else a
    X = [[tr([-L[i][j], Fr(1)] if i == j else [-L[i][j]]) for j in range(m)] for i in range(m)]
    def det(rows, cols):
        if len(rows) == 1: return X[rows[0]][cols[0]]
        out = []
        for k, c in enumerate(cols):
            term = mul(X[rows[0]][c], det(rows[1:], cols[:k] + cols[k+1:]))
            out = sub(out, term) if k % 2 else sub(out, [-x for x in term])
        return out
    D = [[Fr(1)]]
    for k in range(1, m+1):
        g = []
        for rows in combinations(range(m), k):
            for cols in combinations(range(m), k): g = gcd(g, det(list(rows), list(cols)))
        D.append(g)
    facs = [dm(D[k], D[k-1])[0] for k in range(1, m+1)]
    facs = [[int(x) for x in f] for f in facs if len(f) > 1 and all(Fr(x).denominator == 1 for x in f)]
    return (n, m, facs)

# ----------------------------------------------------------------- driver
def main():
    t0 = time.time()
    report = {'method': 'exact rational enclosure check; Kosaraju Morse graphs; graph-projection index maps '
                        'q_* p_*^{-1} over F_(2^31-1); randomized rational chain selectors with '
                        'determinantal-divisor invariant factors',
              'imports_reference_solver': False}
    report['enclosure'] = enclosure_check()
    graph_checked = graph_skipped = random_checked = morse_checked = 0; mismatches = []; max_graph_cells = 0
    by_id = {g['conley_frame_id']: g for g in ORACLE['conley_morse_graphs']}
    if len(by_id) != len(ATLAS['conley_frames']): mismatches.append('frame count')
    for fr in ATLAS['conley_frames']:
        og = by_id[fr['conley_frame_id']]
        rec, edges, attr = morse_graph(fr)
        if og['parameter_id'] != fr['parameter_id'] or og['morse_edges'] != edges or len(og['morse_sets']) != len(rec):
            mismatches.append(('morse graph', fr['conley_frame_id'])); continue
        for mid, M in enumerate(rec):
            om = og['morse_sets'][mid]; morse_checked += 1
            if (om['min_box_id'], om['size'], om['attractor']) != (M[0], len(M), attr[mid]):
                mismatches.append(('morse set', fr['conley_frame_id'], mid)); continue
            P1, P0 = index_pair(M, fr)
            if any(fr['escapes'][q] for q in P1):
                if om['conley_index'] is not None: mismatches.append(('null', fr['conley_frame_id'], mid))
                continue
            if om['conley_index'] is None:
                mismatches.append(('unexpected null', fr['conley_frame_id'], mid)); continue
            expect = [(x['homology_dimension_Q'], x['leray_dimension_Q'], x['invariant_factors_Q']) for x in om['conley_index']]
            rng = random.Random(1000003*fr['conley_frame_id'] + mid)
            for trial in range(3):
                got = [q_invariants(A) for A in random_selector_maps(M, fr, rng)]
                if got != expect: mismatches.append(('random selector', fr['conley_frame_id'], mid, trial, got, expect))
            random_checked += 1
            if len(M) <= GRAPH_SIZE_LIMIT:
                maps, ncells = graph_index_maps(M, fr); max_graph_cells = max(max_graph_cells, ncells)
                for d, A in enumerate(maps):
                    n, m, facs = expect[d]
                    L = leray_fp(A)
                    fp = invariant_factors_fp(L)
                    ex = [[x % P for x in f] for f in facs]
                    if len(A) != n or len(L) != m or fp != ex:
                        mismatches.append(('graph', fr['conley_frame_id'], mid, d, len(A), len(L), fp, expect[d]))
                graph_checked += 1
            else:
                graph_skipped += 1
        print(fr['conley_frame_id'], 'done', round(time.time() - t0, 1), flush=True)
    report.update({'conley_frames_checked': len(ATLAS['conley_frames']), 'morse_sets_checked': morse_checked,
                   'index_maps_random_selector_checked': random_checked,
                   'index_maps_graph_projection_checked': graph_checked,
                   'graph_projection_size_limit_boxes': GRAPH_SIZE_LIMIT,
                   'graph_projection_skipped_larger_sets': graph_skipped,
                   'largest_graph_relative_complex_cells': max_graph_cells,
                   'mismatch_count': len(mismatches), 'mismatches': [repr(m) for m in mismatches[:20]],
                   'atlas_sha256': hashlib.sha256(ATLAS_TEXT.encode()).hexdigest(),
                   'oracle_sha256': hashlib.sha256(ORACLE_TEXT.encode()).hexdigest()})
    report['pass'] = report['enclosure']['violations'] == 0 and not mismatches
    (ROOT / 'authoring/evidence/independent_conley_report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report['pass'] else 1)

if __name__ == '__main__':
    main()
