# Input and output

Read `/app/data/atlas.json` and write regular, non-symlink JSON to `/app/result.json`. All numbers are integers; do not emit floats. For phase grid `[nx,ny]`, box `(i,j)` has ID `i+nx*j`. Frame CSR arrays `offsets,targets` define the multivalued map `F`, and `escapes[q]` marks enclosure escape.

# 1. Frame Morse data

A recurrent SCC has size >1 or is a singleton with a self-loop. Condense the full directed graph. For recurrent SCCs `A,B`, write `A>B` when the condensation DAG reaches `B` from `A`; `[a,b]` is a recurrent Hasse edge iff `A_a>A_b` and no recurrent `A_c` satisfies `A_a>A_c>A_b`. A recurrent SCC is an attractor iff it has no recurrent descendant.

For boxes `S`, let `K(S)` be the union of their closed unit-grid squares and faces. Use `F_2` homology. For recurrent set `M`, report `block_betti_F2` of `K(M)`. Let `N` be the clipped Chebyshev one-box neighborhood of `M`; put `q in L` iff `q in N` and `escapes[q]` is true or some target of `q` lies outside `N`. Report `exit_pair_betti_F2` for `H_d(K(N),K(L))`, `d=0,1,2`, using quotient-chain basis cells in `K(N)\K(L)`.

A frame signature is the recurrent Hasse graph with node annotations `(block_betti_F2,exit_pair_betti_F2,attractor)`. Canonicalize by the lexicographically smallest `(annotation_sequence,edge_list)` over node permutations preserving annotations. Regions are maximal connected components of the public parameter graph with equal canonical signature.

# 2. Parameter-edge continuation

For each oriented public edge `[p,q]`, SCC-decompose the union graph `F_p union F_q`. Relate source Morse set `A_i` to target set `B_j` iff boxes from both occur in one union SCC. Classify by first applicable rule: `split-merge` if a source and a target both have relation degree >1; otherwise `split`; `merge`; `birth-death` if unmatched sets occur on both sides; `birth`; `death`; otherwise `continuation` when matched annotations and mapped Hasse edges agree, else `rewiring`.

# 3. Pathwise zigzag persistence

For each public path, select in its first frame the recurrent set containing `seed_box_id`; then propagate to every target set related to a selected source. Let `S_i` be the selected-box union and `(N_i,L_i)` its exit pair from Section 1. Define

`Z_(2i)=(K(N_i),K(L_i))`, `Z_(2i+1)=(K(N_i union N_(i+1)),K(L_i union L_(i+1)))`,

with arrows `Z_0 -> Z_1 <- Z_2 -> ...`. Pair inclusions induce homology maps by sending each relative basis cell to the identical surviving target cell, else zero. For every interval `[a,b]`, let `rho(a,b)` be the rank of the canonical map `lim -> colim` of the restricted diagram, represented at component `a`. Report triangular `rank_rows_F2`, `node_dimensions_F2[j]=rho(j,j)`, and positive barcode multiplicities

`m(a,b)=rho(a,b)-rho(a-1,b)-rho(a,b+1)+rho(a-1,b+1)`,

with out-of-range `rho=0`.

# 4. Global continuation surface

For `global_continuation_seed`, find its recurrent set and its connected component in the undirected graph on `(parameter_id,morse_id)` whose edges are all public continuation pairs. At parameter `p`, union component Morse sets and form `(N_p,L_p)`. For each public rectangle in `window_queries`, node objects are `H_d(K(N_p),K(L_p))`; every internal public edge `[p,q]` has edge object `H_d(K(N_p union N_q),K(L_p union L_q))` and the two inclusion maps. For `d=0,1,2`, report the rank of the canonical simultaneous-limit to arrow-relation-colimit map, represented at the lower-left node.

# 5. Dynamics-derived bifiltration

For parameter ID `p=i+na*j`, define

`P_(i,j)=(K(union_{u<=i,v<=j} N_(u+na*v)), K(union_{u<=i,v<=j} L_(u+na*v)))`, `M_d(i,j)=H_d(P_(i,j);F_2)`.

Pair inclusions give the `x,y` maps. Extend the module constantly beyond the top/right boundaries and by zero at negative coordinates. For each `d=0,1,2`, report `module_dimensions_F2` and nonzero bigraded Betti entries `beta_h^d(i,j)=dim Tor_h^{F_2[x,y]}(M_d,F_2)_(i,j)`, `h=0,1,2`, as `[i,j,multiplicity]`.

For every coordinatewise comparable `u<=v` in the public grid, let `r_d(u,v)` be the module-map rank. Report nonzero signed rectangle coefficients

`mu_d(b,e)=sum_{eps,eta in {0,1}^2} (-1)^(|eps|+|eta|) r_d(b-eps,e+eta)`,

with zero for out-of-grid or noncomparable arguments.

# 6. Generalized interval ranks

For public query `bounds=[i0,j0,i1,j1]`, `weight=[alpha,beta]`, `level_bounds=[lo,hi]`, retain exactly grades in the rectangle satisfying `lo <= alpha(i-i0)+beta(j-j0) <= hi`, together with internal `x/y` cover edges. For `d=0,1,2`, report the compatible-tuple limit dimension, arrow-relation colimit dimension, and canonical `lim -> colim` rank represented by the smallest-parameter-ID component.

# 7. Scale-time commutative ladders and deformation cohomology

On each path in `spatiotemporal_queries` or `spatiotemporal_deformation_path_ids`, propagate selected Morse sets as in Section 3. For radius `r` in `spatiotemporal_scale_radii`, let `N_i^r` be the clipped Chebyshev radius-`r` neighborhood of the selected-box union, `E_i^r` its boxes that escape or have a target outside `N_i^r`, and `L_i^r=union_{s<=r} E_i^s`. The scale-time ladder is

`X_(r,2i)=(K(N_i^r),K(L_i^r))`, `X_(r,2i+1)=(K(N_i^r union N_(i+1)^r),K(L_i^r union L_(i+1)^r))`,

with Section 3 horizontal orientation and increasing-radius vertical inclusions, and induced maps on `V_v=H_d(X_v;F_2)`. Every elementary square commutes.

For each query rectangle in `(scale,time)` vertex coordinates, restrict the ladder to its vertices and internal arrows and report, for `d=0,1,2`, limit and colimit dimensions and canonical `lim -> colim` rank.

For each deformation path and `d`, let

`C0=direct_sum_v End(V_v)`, `C1=direct_sum_(a:u->v) Hom(V_u,V_v)`, `C2=direct_sum_s Hom(V_source(s),V_target(s))`

over elementary squares `s`. If square arrows are `A:u->v`, `B:v->w`, `C:u->x`, `D:x->w` with `BA=DC`, use over `F_2`

`(delta0 phi)_A = phi_v A + A phi_u`,
`(delta1 psi)_s = B psi_A + psi_B A + D psi_C + psi_D C`.

Report `c0_dimension,c1_dimension,c2_dimension`, ranks of `delta0,delta1`, and `h0=c0-rank(delta0)`, `h1=c1-rank(delta0)-rank(delta1)`, `h2=c2-rank(delta1)`.

# 8. Conley index maps

`conley_frames` are finer enclosures (grid `conley_phase_grid`, same phase rectangle and box IDs) of `f(x,y)=(1-a x^2+y,b x)` with the record's `a,b`: each non-escaping box `B` has `f(K({B})) subset K(F(B))`. Compute recurrent sets, Hasse edges, and attractors as in Section 1. For recurrent `M`, let `W` be `F(M)` plus the clipped Chebyshev one-box neighborhood of `M`, `P0` the boxes of `W\M` reachable from `M` by paths inside `W`, `P1=M union P0`, and `Z=F(P0)`. If a box of `P1` escapes, `conley_index` is `null`. Otherwise `f` maps `(K(P1),K(P0))` into `(K(P1 union Z),K(P0 union Z))`, and the inclusion between these pairs is an excision isomorphism. For `d=0,1,2`, let `f_d=incl_*^(-1) f_*` on `H_d(K(P1),K(P0);Q)` and `V_d=cap_k im f_d^k`. Report `homology_dimension_Q`, `leray_dimension_Q=dim V_d`, and `invariant_factors_Q`: the nonconstant invariant factors of `f_d` restricted to `V_d` over `Q[t]`, each as integer coefficients from constant term to leading `1`.

# 9. Required JSON schema and ordering

Use exactly these keys:
```text
result: phase_grid, parameter_grid, frames, signatures, regions, parameter_edge_events, continuation_barcodes, continuation_surface, multiparameter_persistence, spatiotemporal_persistence, conley_morse_graphs
frame: parameter_id, morse_sets, morse_edges, terminal_morse_ids, signature_id
morse: morse_id, min_box_id, size, block_betti_F2, exit_pair_betti_F2, attractor
signature: signature_id, node_annotations, morse_edges
annotation: block_betti_F2, exit_pair_betti_F2, attractor
region: region_id, signature_id, representative_parameter_id, parameter_ids
edge_event: source_parameter_id, target_parameter_id, event_type, continuation_relation
path_barcode: path_id, parameter_ids, seed_box_id, selected_morse_ids_by_frame, dimensions
zdim: dimension, node_dimensions_F2, rank_rows_F2, interval_multiplicities_F2
bar: start, end, multiplicity
surface: seed_parameter_id, seed_box_id, selected_morse_ids_by_parameter, window_ranks_F2
window_rank: window_id, bounds, rank_F2
mp: parameter_grid, dimensions, generalized_interval_ranks_F2
mpdim: dimension, module_dimensions_F2, betti_tables_F2, signed_rectangle_rank_decomposition
betti: homological_degree, nonzero_grades
rect: birth, death, multiplicity
ginterval: interval_id, bounds, weight, level_bounds, dimensions
gidim, stdim: dimension, limit_dimension_F2, colimit_dimension_F2, generalized_rank_F2
st: scale_radii, query_ranks_F2, deformation_cohomology_F2
stquery: query_id, path_id, scale_bounds, time_bounds, dimensions
stdef: path_id, dimensions
stcoh: dimension, c0_dimension, c1_dimension, c2_dimension, delta0_rank_F2, delta1_rank_F2, h0_F2, h1_F2, h2_F2
cmg: conley_frame_id, parameter_id, morse_sets, morse_edges
cmorse: morse_id, min_box_id, size, attractor, conley_index
cidx: dimension, homology_dimension_Q, leray_dimension_Q, invariant_factors_Q
```

`phase_grid` is the list `[nx,ny]`; both `parameter_grid` fields are the list `[na,nb]`. Betti/rank vectors have length three; rectangle endpoints are `[i,j]`. Booleans occur only in `attractor`.

Order frames by parameter ID; Morse sets by minimum box ID; edge/relation lists and signatures lexicographically; regions by discovery from increasing parameter ID; records mirroring public lists in public order; dimensions `0,1,2`; bars by `(start,end)`; Betti grades by parameter ID; signed rectangles by `(birth_parameter_id,death_parameter_id)`; invariant factors by increasing degree. IDs are consecutive where their schema defines an ID. Repeat every public identity field exactly.

You have 7200 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
