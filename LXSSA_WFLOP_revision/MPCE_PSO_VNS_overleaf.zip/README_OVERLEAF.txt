MPCE manuscript: Overleaf project
=================================

Upload: Overleaf > New Project > Upload Project > select this zip. Compiler: pdfLaTeX (default).

Three documents, all in the project root:
  MPCE_PSO_VNS.tex             main manuscript (set as Main document, the default)
  MPCE_PSO_VNS_supplement.tex  supplementary material
  Cover_letter_PSO_VNS.tex     cover letter
To compile the supplement or the cover letter: Menu > Main document > choose the file > Recompile.

File layout:
  optA/        the manuscript sections (01_front ... 11_back); edit the text here
  analysis/    generated tables and number macros (mpce_numbers.tex); produced by the Python pipeline in
               the GitHub repository; do not edit by hand, rerun the pipeline instead
  figures_mpce/, figures_final/  figures
  xref/        frozen .aux files for the cross-references between manuscript and supplement
               (Table S1, Fig. S3, ... in the main text; Table I, Section VII, ... in the supplement)

Cross-references between the two documents (package xr) are read from xref/. They match the current
version. If you change the numbering of sections, tables, figures or equations in one document, refresh
xref/: compile that document on Overleaf, download its .aux file (Logs and output files > Other logs and
files > .aux) and replace the file of the same name in xref/, then recompile the other document.

Red [TBD: ...] text marks author information still to be filled in: funding statement, corresponding author,
acknowledgment, biographies, Zenodo DOI, volume/pages of Solanki & Deep 2023, and in the cover letter
the manuscript ID and decision of the earlier submission. The \TBD macro is defined in both main files;
once everything is filled in, no red text remains.
