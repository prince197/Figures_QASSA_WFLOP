LX-SSA-VNS WFLOP revised manuscript -- Overleaf project
=======================================================

Upload this ZIP to Overleaf (New Project -> Upload Project) and compile main.tex with
pdfLaTeX (default). The bibliography is inline, so no BibTeX run is needed.

  main.tex          revised manuscript proposing the hybrid LX-SSA-VNS (23 pages; 8 methods incl. original VNS)
  figures/          all figures used by main.tex (model diagrams + result figures as PDF)
  supplementary/    cover letter, conflict-of-interest statement, reviewer status table and
                    analysis/ (hybrid algorithm, experiment and figure scripts, per-run results
                    incl. coordinates and convergence curves, statistics). Not needed to
                    compile main.tex.

To compile the cover letter or COI statement, open it and use Menu -> Main document.
