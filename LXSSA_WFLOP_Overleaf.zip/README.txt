LX-SSA WFLOP revised manuscript -- Overleaf project
===================================================

Upload this ZIP to Overleaf (New Project -> Upload Project). Compile main.tex with
pdfLaTeX (the Overleaf default). IEEEtran and all used packages are available in
Overleaf's TeX Live, so nothing extra has to be installed. Bibliography is inline
(thebibliography), so no BibTeX run is needed.

  main.tex          revised manuscript (the only file Overleaf should compile)
  figures/          all figures used by main.tex (renamed without spaces)
  supplementary/    cover letter, conflict-of-interest statement, reviewer status table,
                    follow-up run data (CSV) and analysis/ scripts + outputs.
                    These are not needed to compile main.tex.

The cover letter and COI statement are separate documents; to compile one in Overleaf,
open it and use Menu -> Main document.
