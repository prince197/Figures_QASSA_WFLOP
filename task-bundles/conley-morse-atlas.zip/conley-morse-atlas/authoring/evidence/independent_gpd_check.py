#!/usr/bin/env python3
"""Independent certificate for the generalized persistence diagrams.

This program imports neither solution/solve.py nor authoring/provenance/generate.py.
It rebuilds the Section 5 bifiltration from the public atlas with its own code
(Kosaraju SCCs, union-map continuation relations, the global continued family,
one-box exit pairs, prefix unions, F_2 relative homology and inclusion maps), then,
for every public window, enumerates every interval of the window by a different
method from the reference (intersections of down-sets and up-sets, filtered by
connectivity), computes every generalized rank with its own limit/colimit code, and
checks the defining identity

    rk(I) = sum over reported J containing I of dgm(J)      for every interval I.

Because the Moebius inversion is unique, this identity over all intervals certifies
the reported diagram exactly.  It also checks the module dimensions against the oracle.
"""
from pathlib import Path
import json, hashlib, time, sys

ROOT = Path(__file__).resolve().parents[2]
ATLAS_TEXT = (ROOT / 'environment/data/atlas.json').read_text(); A = json.loads(ATLAS_TEXT)
ORACLE_TEXT = (ROOT / 'tests/oracle.json').read_text(); O = json.loads(ORACLE_TEXT)
NX, NY = A['phase_grid']['nx'], A['phase_grid']['ny']; NB = NX * NY
NA, NBP = A['parameter_grid']['na'], A['parameter_grid']['nb']

def kosaraju(adj):
    n = len(adj); radj = [[] for _ in range(n)]
    for v, outs in enumerate(adj):
        for w in outs: radj[w].append(v)
    seen = [False]*n; order = []
    for s in range(n):
        if seen[s]: continue
        seen[s] = True; st = [(s, 0)]
        while st:
            v, k = st[-1]
            if k < len(adj[v]):
                st[-1] = (v, k+1); w = adj[v][k]
                if not seen[w]: seen[w] = True; st.append((w, 0))
            else: order.append(v); st.pop()
    comp = [-1]*n; c = 0
    for s in reversed(order):
        if comp[s] >= 0: continue
        comp[s] = c; st = [s]
        while st:
            v = st.pop()
            for w in radj[v]:
                if comp[w] < 0: comp[w] = c; st.append(w)
        c += 1
    return comp

def frame_adj(fr):
    o, t = fr['offsets'], fr['targets']
    return [t[o[v]:o[v+1]] for v in range(NB)]

def recurrent(adj):
    comp = kosaraju(adj); groups = {}
    for v, c in enumerate(comp): groups.setdefault(c, []).append(v)
    rec = [sorted(g) for g in groups.values() if len(g) > 1 or g[0] in adj[g[0]]]
    return sorted(rec, key=lambda g: g[0])

def exit_pair(boxes, fr):
    o, t, e = fr['offsets'], fr['targets'], fr['escapes']
    N = set()
    for q in boxes:
        i, j = q % NX, q // NX
        for jj in range(max(0, j-1), min(NY, j+2)):
            for ii in range(max(0, i-1), min(NX, i+2)): N.add(ii + NX*jj)
    L = {q for q in N if e[q] or any(w not in N for w in t[o[q]:o[q+1]])}
    return N, L

# ------------------------------------------------------------- F_2 relative homology
def cells(boxes):
    out = set()
    for q in boxes:
        i, j = q % NX, q // NX
        out.update({('v', i, j), ('v', i+1, j), ('v', i, j+1), ('v', i+1, j+1),
                    ('h', i, j), ('h', i, j+1), ('u', i, j), ('u', i+1, j), ('s', i, j)})
    return out

def faces(c):
    k, i, j = c
    if k == 'h': return [('v', i, j), ('v', i+1, j)]
    if k == 'u': return [('v', i, j), ('v', i, j+1)]
    if k == 's': return [('h', i, j), ('h', i, j+1), ('u', i, j), ('u', i+1, j)]
    return []

DIM = {'v': 0, 'h': 1, 'u': 1, 's': 2}

class Hom:
    """Relative F_2 homology of (K(N), K(L)) with a coordinate map on relative cycles."""
    def __init__(self, N, L):
        rel = cells(N) - cells(L)
        self.cells = [sorted(c for c in rel if DIM[c[0]] == d) for d in range(3)]
        self.idx = [{c: k for k, c in enumerate(self.cells[d])} for d in range(3)]
        bd = [None] + [[self.vec(faces(c), d-1) for c in self.cells[d]] for d in (1, 2)]
        self.basis = []; self.H = []
        for d in range(3):
            # kernel of boundary: row-reduce columns keeping combination masks
            if d == 0: Z = [1 << k for k in range(len(self.cells[0]))]
            else:
                piv = {}; Z = []
                for k, col in enumerate(bd[d]):
                    v, m = col, 1 << k
                    while v:
                        p = v.bit_length() - 1
                        if p not in piv: piv[p] = (v, m); break
                        v ^= piv[p][0]; m ^= piv[p][1]
                    if not v: Z.append(m)
            B = bd[d+1] if d < 2 else []
            ech = {}; nb = 0
            def add(v, lab):
                while v:
                    p = v.bit_length() - 1
                    if p not in ech: ech[p] = (v, lab); return True
                    v ^= ech[p][0]; lab ^= ech[p][1]
                return False
            for b in B: add(b, 0)
            H = []
            for z in Z:
                if add(z, 1 << len(H)): H.append(z)
            self.basis.append((ech, len(H))); self.H.append(H)
    def vec(self, cs, d):
        v = 0
        for c in cs:
            k = self.idx[d].get(c)
            if k is not None: v ^= 1 << k
        return v
    def dim(self, d): return self.basis[d][1]
    def coords(self, v, d):
        ech, _ = self.basis[d]; lab = 0
        while v:
            p = v.bit_length() - 1
            if p not in ech: raise RuntimeError('not a relative cycle')
            v ^= ech[p][0]; lab ^= ech[p][1]
        return lab
    def rep(self, d, r):
        return self.H[d][r]

def inclusion(src, tgt, d):
    cols = []
    for r in range(src.dim(d)):
        z = src.rep(d, r)
        v = 0; x = z
        while x:
            b = x & -x; k = b.bit_length() - 1; x ^= b
            kk = tgt.idx[d].get(src.cells[d][k])
            if kk is not None: v ^= 1 << kk
        cols.append(tgt.coords(v, d))
    return cols

# ------------------------------------------------------------- generalized rank
def gen_rank(dims, arrows):
    """Rank of lim -> colim over F_2 (component 0); arrows (s, t, columns)."""
    off = [0]
    for x in dims: off.append(off[-1] + x)
    tot = off[-1]
    # lim: kernel of x -> (A x_s - x_t)_arrows
    rows = []                                   # constraint columns per variable
    cons_off = 0; colsvar = [0]*tot
    for s, t, cols in arrows:
        for j, c in enumerate(cols):
            x = c
            while x:
                b = x & -x; r = b.bit_length() - 1; x ^= b
                colsvar[off[s]+j] ^= 1 << (cons_off + r)
        for r in range(dims[t]): colsvar[off[t]+r] ^= 1 << (cons_off + r)
        cons_off += dims[t]
    piv = {}; lim = []
    for k, col in enumerate(colsvar):
        v, m = col, 1 << k
        while v:
            p = v.bit_length() - 1
            if p not in piv: piv[p] = (v, m); break
            v ^= piv[p][0]; m ^= piv[p][1]
        if not v: lim.append(m)
    # colim: quotient of the direct sum by x_s - A x_s for every arrow
    ech = {}
    def add(v):
        while v:
            p = v.bit_length() - 1
            if p not in ech: ech[p] = v; return True
            v ^= ech[p]
        return False
    for s, t, cols in arrows:
        for j, c in enumerate(cols):
            v = 1 << (off[s]+j); x = c
            while x:
                b = x & -x; r = b.bit_length() - 1; x ^= b; v ^= 1 << (off[t]+r)
            add(v)
    mask = (1 << dims[0]) - 1
    return sum(1 for x in lim if add(x & mask))

def window_intervals(w, h):
    pts = [(i, j) for j in range(h) for i in range(w)]; idx = {p: k for k, p in enumerate(pts)}
    stair = []
    def rec(i, cap, cur):
        if i == w: stair.append(list(cur)); return
        for hh in range(cap, -1, -1): cur.append(hh); rec(i+1, hh, cur); cur.pop()
    rec(0, h, [])
    downs = []
    for st in stair:
        m = 0
        for i, hh in enumerate(st):
            for j in range(hh): m |= 1 << idx[(i, j)]
        downs.append(m)
    full = (1 << len(pts)) - 1
    ups = [full ^ d for d in downs]
    out = set()
    for d in downs:
        for u in ups:
            s = d & u
            if not s or s in out: continue
            k0 = (s & -s).bit_length() - 1; vis = 1 << k0; st = [k0]
            while st:
                i, j = pts[st.pop()]
                for q in ((i+1, j), (i-1, j), (i, j+1), (i, j-1)):
                    k = idx.get(q)
                    if k is not None and s >> k & 1 and not vis >> k & 1: vis |= 1 << k; st.append(k)
            if vis == s: out.add(s)
    return pts, idx, out

def main():
    t0 = time.time(); frames = A['frames']
    adjs = [frame_adj(f) for f in frames]
    recs = [recurrent(a) for a in adjs]
    rel = {}
    for p, q in A['parameter_edges']:
        comp = kosaraju([sorted(set(adjs[p][v]) | set(adjs[q][v])) for v in range(NB)])
        rel[(p, q)] = [(i, j) for i, Ma in enumerate(recs[p]) for j, Mb in enumerate(recs[q])
                       if {comp[v] for v in Ma} & {comp[v] for v in Mb}]
    seed = A['global_continuation_seed']
    s0 = next(k for k, M in enumerate(recs[seed['parameter_id']]) if seed['seed_box_id'] in M)
    graph = {}
    for (p, q), pairs in rel.items():
        for i, j in pairs:
            graph.setdefault((p, i), []).append((q, j)); graph.setdefault((q, j), []).append((p, i))
    comp = {(seed['parameter_id'], s0)}; st = list(comp)
    while st:
        for y in graph.get(st.pop(), ()):
            if y not in comp: comp.add(y); st.append(y)
    pairs = []
    for p in range(len(frames)):
        boxes = set()
        for (pp, m) in comp:
            if pp == p: boxes.update(recs[p][m])
        pairs.append(exit_pair(boxes, frames[p]) if boxes else (set(), set()))
    print('module pairs built', round(time.time() - t0, 1), flush=True)
    grid = {}; Hs = {}
    for j in range(NBP):
        for i in range(NA):
            N, L = set(), set()
            for a, b in ((i-1, j), (i, j-1)):
                if (a, b) in grid: N |= grid[(a, b)][0]; L |= grid[(a, b)][1]
            N |= pairs[i + NA*j][0]; L |= pairs[i + NA*j][1]
            grid[(i, j)] = (N, L); Hs[(i, j)] = Hom(N, L)
    mismatches = []
    for d in range(3):
        md = [Hs[(p % NA, p // NA)].dim(d) for p in range(NA*NBP)]
        if md != O['multiparameter_persistence']['dimensions'][d]['module_dimensions_F2']:
            mismatches.append(('module dimensions', d))
    print('homology built', round(time.time() - t0, 1), flush=True)
    report = {'method': 'independent bifiltration rebuild; interval enumeration by down-set/up-set intersections; '
                        'own F_2 limit/colimit ranks; defining Moebius identity checked on every interval',
              'imports_reference_solver': False, 'windows': []}
    maps = {}
    def arrow(d, a, b):
        key = (d, a, b)
        if key not in maps: maps[key] = inclusion(Hs[a], Hs[b], d)
        return maps[key]
    for g, pub in zip(O['multiparameter_persistence']['generalized_persistence_diagrams_F2'], A['gpd_windows']):
        i0, j0, i1, j1 = pub['bounds']; d = pub['dimension']; w, h = i1-i0+1, j1-j0+1
        pts, idx, ints = window_intervals(w, h)
        dg = []
        for e in g['diagram']:
            m = 0
            for p in e['parameter_ids']: m |= 1 << idx[(p % NA - i0, p // NA - j0)]
            if m not in ints: mismatches.append(('reported support is not an interval', pub['window_id']))
            dg.append((m, e['multiplicity']))
        bad = 0
        for s in ints:
            ks = [k for k in range(len(pts)) if s >> k & 1]
            dims = [Hs[(pts[k][0]+i0, pts[k][1]+j0)].dim(d) for k in ks]
            if min(dims) == 0: r = 0
            else:
                loc = {k: n for n, k in enumerate(ks)}; arrows = []
                for k in ks:
                    i, j = pts[k]
                    for q in ((i+1, j), (i, j+1)):
                        kk = idx.get(q)
                        if kk is not None and s >> kk & 1:
                            arrows.append((loc[k], loc[kk], arrow(d, (i+i0, j+j0), (q[0]+i0, q[1]+j0))))
                r = gen_rank(dims, arrows)
            if r != sum(mu for m, mu in dg if m & s == s): bad += 1
        report['windows'].append({'window_id': pub['window_id'], 'intervals_checked': len(ints), 'identity_failures': bad})
        if bad: mismatches.append(('Moebius identity', pub['window_id'], bad))
        print('window', pub['window_id'], len(ints), 'failures', bad, round(time.time() - t0, 1), flush=True)
    report.update({'mismatch_count': len(mismatches), 'mismatches': [repr(m) for m in mismatches],
                   'atlas_sha256': hashlib.sha256(ATLAS_TEXT.encode()).hexdigest(),
                   'oracle_sha256': hashlib.sha256(ORACLE_TEXT.encode()).hexdigest(), 'pass': not mismatches})
    (ROOT / 'authoring/evidence/independent_gpd_report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report['pass'] else 1)

if __name__ == '__main__':
    main()
