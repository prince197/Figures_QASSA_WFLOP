#!/usr/bin/env python3
"""Independent certificate for the scale-time generalized persistence diagrams.

This program imports neither solution/solve.py nor authoring/provenance/generate.py.
It rebuilds the scale-time ladders from the public atlas with its own code (Kosaraju
SCCs, union-map continuation relations, pathwise propagation, dilated exit pairs with
cumulative exit sets, F_2 relative homology and inclusion maps).  For every public
window it enumerates every interval top-down from the full window by one-point
removals (the reference enumerates bottom-up from singletons), validates that
enumeration against exhaustive subset search on small windows, computes every
generalized rank with its own limit/colimit code, and checks the defining identity

    rk(I) = sum over reported J containing I of dgm(J)      for every interval I.

Because the Moebius inversion is unique, this identity over all intervals certifies
the reported diagram exactly.
"""
from pathlib import Path
import json, hashlib, time, sys

ROOT = Path(__file__).resolve().parents[2]
ATLAS_TEXT = (ROOT / 'environment/data/atlas.json').read_text(); A = json.loads(ATLAS_TEXT)
ORACLE_TEXT = (ROOT / 'tests/oracle.json').read_text(); O = json.loads(ORACLE_TEXT)
NX, NY = A['phase_grid']['nx'], A['phase_grid']['ny']; NB = NX * NY
NA, NBP = A['parameter_grid']['na'], A['parameter_grid']['nb']

def kosaraju(adj):
    n = len(adj); radj = [[] for _ in range(n)]
    for v, outs in enumerate(adj):
        for w in outs: radj[w].append(v)
    seen = [False]*n; order = []
    for s in range(n):
        if seen[s]: continue
        seen[s] = True; st = [(s, 0)]
        while st:
            v, k = st[-1]
            if k < len(adj[v]):
                st[-1] = (v, k+1); w = adj[v][k]
                if not seen[w]: seen[w] = True; st.append((w, 0))
            else: order.append(v); st.pop()
    comp = [-1]*n; c = 0
    for s in reversed(order):
        if comp[s] >= 0: continue
        comp[s] = c; st = [s]
        while st:
            v = st.pop()
            for w in radj[v]:
                if comp[w] < 0: comp[w] = c; st.append(w)
        c += 1
    return comp

def frame_adj(fr):
    o, t = fr['offsets'], fr['targets']
    return [t[o[v]:o[v+1]] for v in range(NB)]

def recurrent(adj):
    comp = kosaraju(adj); groups = {}
    for v, c in enumerate(comp): groups.setdefault(c, []).append(v)
    rec = [sorted(g) for g in groups.values() if len(g) > 1 or g[0] in adj[g[0]]]
    return sorted(rec, key=lambda g: g[0])

def exit_pair(boxes, fr):
    o, t, e = fr['offsets'], fr['targets'], fr['escapes']
    N = set()
    for q in boxes:
        i, j = q % NX, q // NX
        for jj in range(max(0, j-1), min(NY, j+2)):
            for ii in range(max(0, i-1), min(NX, i+2)): N.add(ii + NX*jj)
    L = {q for q in N if e[q] or any(w not in N for w in t[o[q]:o[q+1]])}
    return N, L

# ------------------------------------------------------------- F_2 relative homology
def cells(boxes):
    out = set()
    for q in boxes:
        i, j = q % NX, q // NX
        out.update({('v', i, j), ('v', i+1, j), ('v', i, j+1), ('v', i+1, j+1),
                    ('h', i, j), ('h', i, j+1), ('u', i, j), ('u', i+1, j), ('s', i, j)})
    return out

def faces(c):
    k, i, j = c
    if k == 'h': return [('v', i, j), ('v', i+1, j)]
    if k == 'u': return [('v', i, j), ('v', i, j+1)]
    if k == 's': return [('h', i, j), ('h', i, j+1), ('u', i, j), ('u', i+1, j)]
    return []

DIM = {'v': 0, 'h': 1, 'u': 1, 's': 2}

class Hom:
    """Relative F_2 homology of (K(N), K(L)) with a coordinate map on relative cycles."""
    def __init__(self, N, L):
        rel = cells(N) - cells(L)
        self.cells = [sorted(c for c in rel if DIM[c[0]] == d) for d in range(3)]
        self.idx = [{c: k for k, c in enumerate(self.cells[d])} for d in range(3)]
        bd = [None] + [[self.vec(faces(c), d-1) for c in self.cells[d]] for d in (1, 2)]
        self.basis = []; self.H = []
        for d in range(3):
            # kernel of boundary: row-reduce columns keeping combination masks
            if d == 0: Z = [1 << k for k in range(len(self.cells[0]))]
            else:
                piv = {}; Z = []
                for k, col in enumerate(bd[d]):
                    v, m = col, 1 << k
                    while v:
                        p = v.bit_length() - 1
                        if p not in piv: piv[p] = (v, m); break
                        v ^= piv[p][0]; m ^= piv[p][1]
                    if not v: Z.append(m)
            B = bd[d+1] if d < 2 else []
            ech = {}; nb = 0
            def add(v, lab):
                while v:
                    p = v.bit_length() - 1
                    if p not in ech: ech[p] = (v, lab); return True
                    v ^= ech[p][0]; lab ^= ech[p][1]
                return False
            for b in B: add(b, 0)
            H = []
            for z in Z:
                if add(z, 1 << len(H)): H.append(z)
            self.basis.append((ech, len(H))); self.H.append(H)
    def vec(self, cs, d):
        v = 0
        for c in cs:
            k = self.idx[d].get(c)
            if k is not None: v ^= 1 << k
        return v
    def dim(self, d): return self.basis[d][1]
    def coords(self, v, d):
        ech, _ = self.basis[d]; lab = 0
        while v:
            p = v.bit_length() - 1
            if p not in ech: raise RuntimeError('not a relative cycle')
            v ^= ech[p][0]; lab ^= ech[p][1]
        return lab
    def rep(self, d, r):
        return self.H[d][r]

def inclusion(src, tgt, d):
    cols = []
    for r in range(src.dim(d)):
        z = src.rep(d, r)
        v = 0; x = z
        while x:
            b = x & -x; k = b.bit_length() - 1; x ^= b
            kk = tgt.idx[d].get(src.cells[d][k])
            if kk is not None: v ^= 1 << kk
        cols.append(tgt.coords(v, d))
    return cols

# ------------------------------------------------------------- generalized rank
def gen_rank(dims, arrows):
    """Rank of lim -> colim over F_2 (component 0); arrows (s, t, columns)."""
    off = [0]
    for x in dims: off.append(off[-1] + x)
    tot = off[-1]
    # lim: kernel of x -> (A x_s - x_t)_arrows
    rows = []                                   # constraint columns per variable
    cons_off = 0; colsvar = [0]*tot
    for s, t, cols in arrows:
        for j, c in enumerate(cols):
            x = c
            while x:
                b = x & -x; r = b.bit_length() - 1; x ^= b
                colsvar[off[s]+j] ^= 1 << (cons_off + r)
        for r in range(dims[t]): colsvar[off[t]+r] ^= 1 << (cons_off + r)
        cons_off += dims[t]
    piv = {}; lim = []
    for k, col in enumerate(colsvar):
        v, m = col, 1 << k
        while v:
            p = v.bit_length() - 1
            if p not in piv: piv[p] = (v, m); break
            v ^= piv[p][0]; m ^= piv[p][1]
        if not v: lim.append(m)
    # colim: quotient of the direct sum by x_s - A x_s for every arrow
    ech = {}
    def add(v):
        while v:
            p = v.bit_length() - 1
            if p not in ech: ech[p] = v; return True
            v ^= ech[p]
        return False
    for s, t, cols in arrows:
        for j, c in enumerate(cols):
            v = 1 << (off[s]+j); x = c
            while x:
                b = x & -x; r = b.bit_length() - 1; x ^= b; v ^= 1 << (off[t]+r)
            add(v)
    mask = (1 << dims[0]) - 1
    return sum(1 for x in lim if add(x & mask))

def order_masks(n, arrows):
    succ = [[] for _ in range(n)]; pred = [[] for _ in range(n)]
    for a, b in arrows: succ[a].append(b); pred[b].append(a)
    def closure(v, adj):
        m = 1 << v; st = [v]
        while st:
            for y in adj[st.pop()]:
                if not m >> y & 1: m |= 1 << y; st.append(y)
        return m
    return [closure(v, succ) for v in range(n)], [closure(v, pred) for v in range(n)]

def is_interval(s, n, und, ups, downs):
    if not s: return False
    k0 = (s & -s).bit_length() - 1; vis = 1 << k0; st = [k0]
    while st:
        x = und[st.pop()] & s & ~vis
        while x:
            b = x & -x; vis |= b; st.append(b.bit_length() - 1); x ^= b
    if vis != s: return False
    x = s; hull_up = 0; hull_dn = 0
    while x:
        b = x & -x; k = b.bit_length() - 1; x ^= b; hull_up |= ups[k]; hull_dn |= downs[k]
    return hull_up & hull_dn == s

def intervals_top_down(n, arrows):
    ups, downs = order_masks(n, arrows)
    und = [0]*n
    for a, b in arrows: und[a] |= 1 << b; und[b] |= 1 << a
    full = (1 << n) - 1
    seen = {full}; frontier = [full]
    while frontier:
        nxt = []
        for s in frontier:
            x = s
            while x:
                b = x & -x; x ^= b; t = s ^ b
                if t and t not in seen and is_interval(t, n, und, ups, downs): seen.add(t); nxt.append(t)
        frontier = nxt
    return seen

def intervals_exhaustive(n, arrows):
    ups, downs = order_masks(n, arrows)
    und = [0]*n
    for a, b in arrows: und[a] |= 1 << b; und[b] |= 1 << a
    return {s for s in range(1, 1 << n) if is_interval(s, n, und, ups, downs)}

def ladder_window(radii, r0, r1, t0, t1):
    verts = [(r, t) for r in radii if r0 <= r <= r1 for t in range(t0, t1+1)]
    pos = {v: k for k, v in enumerate(verts)}; rows = [r for r in radii if r0 <= r <= r1]
    arrows = []
    for (r, t) in verts:
        if t % 2 == 0:
            for u in (t-1, t+1):
                if (r, u) in pos: arrows.append((pos[(r, t)], pos[(r, u)]))
        k = rows.index(r)
        if k+1 < len(rows): arrows.append((pos[(r, t)], pos[(rows[k+1], t)]))
    return verts, pos, arrows

def dilate(boxes, r):
    out = set()
    for q in boxes:
        i, j = q % NX, q // NX
        for jj in range(max(0, j-r), min(NY, j+r+1)):
            for ii in range(max(0, i-r), min(NX, i+r+1)): out.add(ii + NX*jj)
    return out

def main():
    t0 = time.time(); frames = A['frames']
    adjs = [frame_adj(f) for f in frames]
    recs = [recurrent(a) for a in adjs]
    rel = {}
    def relation(p, q):
        if (p, q) in rel: return rel[(p, q)]
        if (q, p) in rel: return [(j, i) for i, j in rel[(q, p)]]
        comp = kosaraju([sorted(set(adjs[p][v]) | set(adjs[q][v])) for v in range(NB)])
        rel[(p, q)] = [(i, j) for i, Ma in enumerate(recs[p]) for j, Mb in enumerate(recs[q])
                       if {comp[v] for v in Ma} & {comp[v] for v in Mb}]
        return rel[(p, q)]
    radii = A['spatiotemporal_scale_radii']; paths = {p['path_id']: p for p in A['paths']}
    report = {'method': 'independent ladder rebuild; top-down interval enumeration validated by exhaustive subset '
                        'search; own F_2 limit/colimit ranks; defining Moebius identity checked on every interval',
              'imports_reference_solver': False, 'enumeration_validation': [], 'windows': []}
    mismatches = []
    # enumeration completeness: top-down one-point removal equals exhaustive search on small ladder windows
    for (rr0, rr1, tt0, tt1) in ((1, 3, 0, 4), (2, 4, 3, 7), (1, 2, 1, 7), (1, 4, 0, 3)):
        verts, pos, arrows = ladder_window(radii, rr0, rr1, tt0, tt1)
        a_ = intervals_top_down(len(verts), arrows); b_ = intervals_exhaustive(len(verts), arrows)
        report['enumeration_validation'].append({'window': [rr0, rr1, tt0, tt1], 'vertices': len(verts), 'intervals': len(b_), 'top_down_equals_exhaustive': a_ == b_})
        if a_ != b_: mismatches.append(('enumeration', rr0, rr1, tt0, tt1))
    ladders = {}
    for g, pub in zip(O['spatiotemporal_persistence']['generalized_persistence_diagrams_F2'], A['spatiotemporal_gpd_windows']):
        pid = pub['path_id']
        if pid not in ladders:
            ids = paths[pid]['parameter_ids']; seed = paths[pid]['seed_box_id']
            sel = [{next(k for k, M in enumerate(recs[ids[0]]) if seed in M)}]
            for p, q in zip(ids, ids[1:]):
                sel.append({j for i, j in relation(p, q) if i in sel[-1]})
            unions = [set().union(*[recs[p][m] for m in s_]) if s_ else set() for p, s_ in zip(ids, sel)]
            H = {}; cumL = [set() for _ in ids]
            for r in radii:
                even = []
                for k, p in enumerate(ids):
                    fr = frames[p]; o, t, e = fr['offsets'], fr['targets'], fr['escapes']
                    N = dilate(unions[k], r)
                    cumL[k] |= {q for q in N if e[q] or any(w not in N for w in t[o[q]:o[q+1]])}
                    even.append((N, set(cumL[k])))
                for k in range(len(ids)):
                    H[(r, 2*k)] = Hom(*even[k])
                    if k+1 < len(ids): H[(r, 2*k+1)] = Hom(even[k][0] | even[k+1][0], even[k][1] | even[k+1][1])
            ladders[pid] = H
            print('ladder', pid, 'built', round(time.time() - t0, 1), flush=True)
        H = ladders[pid]; d = pub['dimension']
        verts, pos, arrows = ladder_window(radii, *pub['scale_bounds'], *pub['time_bounds'])
        maps = {(a, b): inclusion(H[verts[a]], H[verts[b]], d) for a, b in arrows}
        dims = [H[v].dim(d) for v in verts]
        ints = intervals_top_down(len(verts), arrows)
        dg = []
        for e in g['diagram']:
            m = 0
            for v in e['vertices']: m |= 1 << pos[tuple(v)]
            if m not in ints: mismatches.append(('reported support is not an interval', pub['window_id']))
            dg.append((m, e['multiplicity']))
        bad = 0
        for s_ in ints:
            ks = [k for k in range(len(verts)) if s_ >> k & 1]
            if min(dims[k] for k in ks) == 0: r_ = 0
            else:
                loc = {k: i for i, k in enumerate(ks)}
                r_ = gen_rank([dims[k] for k in ks], [(loc[a], loc[b], maps[(a, b)]) for a, b in arrows if s_ >> a & 1 and s_ >> b & 1])
            if r_ != sum(mu for m, mu in dg if m & s_ == s_): bad += 1
        report['windows'].append({'window_id': pub['window_id'], 'path_id': pid, 'intervals_checked': len(ints),
                                  'negative_multiplicities': sum(1 for _, mu in dg if mu < 0), 'identity_failures': bad})
        if bad: mismatches.append(('Moebius identity', pub['window_id'], bad))
        print('window', pub['window_id'], len(ints), 'failures', bad, round(time.time() - t0, 1), flush=True)
    report.update({'mismatch_count': len(mismatches), 'mismatches': [repr(m) for m in mismatches],
                   'atlas_sha256': hashlib.sha256(ATLAS_TEXT.encode()).hexdigest(),
                   'oracle_sha256': hashlib.sha256(ORACLE_TEXT.encode()).hexdigest(), 'pass': not mismatches})
    (ROOT / 'authoring/evidence/independent_gpd_report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report['pass'] else 1)

if __name__ == '__main__':
    main()
