#!/usr/bin/env python3
from pathlib import Path
import json, re, tomllib

ROOT=Path(__file__).resolve().parents[2]
issues=[]; warnings=[]
required=[
    'instruction.md','task.toml','README.md','environment/Dockerfile','environment/data/atlas.json',
    'solution/solve.sh','solution/solve.py','tests/Dockerfile','tests/test.sh','tests/test_verifier.py',
    'tests/verifier_core.py','tests/oracle.json','authoring/evidence/independent_homology_check.py',
    'authoring/evidence/independent_homology_report.json','authoring/evidence/independent_conley_check.py',
    'authoring/evidence/independent_conley_report.json'
]
for rel in required:
    if not (ROOT/rel).exists(): issues.append(f'missing {rel}')

text=(ROOT/'instruction.md').read_text()
if len(text)>10000: issues.append(f'instruction too long: {len(text)}')
suffix='You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.'
body=text[:-1] if text.endswith('\n') else text
if not body.endswith('\n\n'+suffix) or body.count(suffix)!=1: issues.append('instruction suffix mismatch')
if text.endswith('\n\n'): issues.append('more than one trailing newline')
if '**' in text: issues.append('decorative bold markup present')
if '\\[' in text or '\\]' in text: issues.append('display math must use $$')

T=tomllib.loads((ROOT/'task.toml').read_text())
if T['task']['name']!='conley-morse-atlas': issues.append('task name mismatch')
allowed_metadata={
    'author_name','author_email','author_organization','author_profile','research_advisor','referred_by',
    'conflicts_of_interest','domain','field','subfield','tags','expert_time_estimate_hours','relevant_experience',
    'category','subcategory','difficulty_explanation','solution_explanation','verification_explanation'
}
extra=set(T.get('metadata',{}))-allowed_metadata
if extra: issues.append(f'unexpected metadata keys: {sorted(extra)}')
for key in ['category','subcategory','difficulty_explanation','solution_explanation','verification_explanation','domain','field','subfield','tags','expert_time_estimate_hours']:
    if not T.get('metadata',{}).get(key): issues.append(f'metadata missing {key}')
if T.get('metadata',{}).get('category')!='Science': issues.append('metadata.category must be Science')
if T.get('metadata',{}).get('subcategory')!='Applied Mathematics & Scientific Computing': issues.append('metadata.subcategory must be Applied Mathematics & Scientific Computing')
placeholder_hits=[]
for key,val in T.get('metadata',{}).items():
    if isinstance(val,str) and 'REPLACE_WITH_' in val: placeholder_hits.append(f'metadata.{key}')
for idx,a in enumerate(T.get('task',{}).get('authors',[])):
    for key,val in a.items():
        if isinstance(val,str) and 'REPLACE_WITH_' in val: placeholder_hits.append(f'task.authors[{idx}].{key}')
if placeholder_hits: warnings.append('author facts still require submitter values: '+', '.join(placeholder_hits))

if T['environment'].get('gpus')!=0: issues.append('gpus must be 0')
if 'gpu_types' in T['environment']: issues.append('gpu_types must be absent')
if T['environment'].get('network_mode')!='public': issues.append('agent network_mode must be public')
if T['verifier']['environment'].get('network_mode')!='no-network': issues.append('verifier network_mode must be no-network')
if T['agent'].get('timeout_sec',0)<9000.0: issues.append('agent timeout must be at least 9000 (2.5h floor)')

ind=json.loads((ROOT/'authoring/evidence/independent_homology_report.json').read_text())
if not ind.get('pass'): issues.append('independent homology cross-check failed')
cind=json.loads((ROOT/'authoring/evidence/independent_conley_report.json').read_text())
if not cind.get('pass'): issues.append('independent Conley index cross-check failed')
import hashlib
for rep,name in ((ind,'homology'),(cind,'Conley')):
    if rep.get('oracle_sha256')!=hashlib.sha256((ROOT/'tests/oracle.json').read_bytes()).hexdigest(): issues.append(f'independent {name} report is stale for the current oracle')
    if rep.get('atlas_sha256')!=hashlib.sha256((ROOT/'environment/data/atlas.json').read_bytes()).hexdigest(): issues.append(f'independent {name} report is stale for the current atlas')

report={'pass':not issues,'instruction_chars':len(text),'issues':issues,'warnings':warnings}
(ROOT/'authoring/evidence/structural_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if not issues else 1)
