# Research sources and scope

This benchmark is synthetic. The references below motivate the workflow; no published numerical table, parameter atlas, Morse graph, barcode, Betti table, or rank decomposition is used as benchmark ground truth.

1. Arai, Z.; Kalies, W.; Kokubu, H.; Mischaikow, K.; Oka, H.; Pilarczyk, P. “A Database Schema for the Analysis of Global Dynamics of Multiparameter Systems.” SIAM J. Appl. Dyn. Syst. 8 (2009), 757-789. https://doi.org/10.1137/080734935
   Relevance: parameter-space decomposition, Morse decompositions, adjacent-parameter continuation, and Conley-index annotations in a global-dynamics database.

2. Dey, T. K.; Mrozek, M.; Slechta, R. “Persistence of the Conley Index in Combinatorial Dynamical Systems.” SoCG 2020. https://doi.org/10.4230/LIPIcs.SoCG.2020.37
   Relevance: zigzag persistence for Conley-index changes under evolving combinatorial dynamics.

3. Dey, T. K.; Mrozek, M.; Slechta, R. “Persistence of Conley-Morse Graphs in Combinatorial Dynamical Systems.” SIAM J. Appl. Dyn. Syst. 21 (2022), 817-839. https://doi.org/10.1137/21M143162X
   Relevance: jointly tracking Morse-decomposition structure and topology of recurrent sets.

4. Dey, T. K.; Lipinski, M.; Soriano-Trigueros, M. “Conley-Morse Persistence Barcode: A Homological Signature of Combinatorial Bifurcations.” Foundations of Computational Mathematics (2026). https://doi.org/10.1007/s10208-026-09766-6
   Relevance: persistence barcodes for combinatorial bifurcations through homological transition data.

5. Dey, T. K.; Haas, A.; Lipinski, M. “Computing Conley-Morse Persistence Barcode Efficiently by Updating Matrix Decompositions.” arXiv:2608.06507 (2026). https://arxiv.org/abs/2608.06507
   Relevance: efficient block-based computation for evolving Conley-Morse persistence.

6. Batko, B.; Kaczynski, T.; Mrozek, M.; Wanner, T. “Linking Combinatorial and Classical Dynamics: Conley Index and Morse Decompositions.” Found. Comput. Math. 20 (2020), 967-1012. https://doi.org/10.1007/s10208-020-09444-1
   Relevance: mathematical relationship between combinatorial dynamics, Morse decompositions, and Conley-type invariants.

7. Kim, W.; Moore, S. “Bigraded Betti numbers and generalized persistence diagrams.” J. Appl. Comput. Topol. 8 (2024), 727-760. https://doi.org/10.1007/s41468-024-00180-x
   Relevance: bigraded Betti numbers, generalized rank invariants, Möbius inversion, and signed multiparameter summaries.

8. Botnan, M. B.; Oppermann, S.; Oudot, S. “Signed Barcodes for Multi-parameter Persistence via Rank Decompositions and Rank-Exact Resolutions.” Found. Comput. Math. 25 (2025), 1815-1874. https://doi.org/10.1007/s10208-024-09672-9
   Relevance: signed decompositions of multiparameter rank invariants into indicator-module rank functions.

9. Guidolin, A.; Landi, C. “On the support of betti tables of multiparameter persistent homology modules.” Q. J. Math. 76 (2025), 609-642. https://doi.org/10.1093/qmath/haaf021
   Relevance: Betti tables of multiparameter persistent homology, Koszul complexes, and homological critical grades.

10. Morozov, D.; Scoccola, L. “Computing Betti Tables and Minimal Presentations of Zero-Dimensional Persistent Homology.” SoCG 2025. https://doi.org/10.4230/LIPIcs.SoCG.2025.69
    Relevance: algorithmic computation of multiparameter Betti tables and minimal presentations.

11. Dey, T. K.; Kim, W.; Mémoli, F. “Computing Generalized Rank Invariant for 2-Parameter Persistence Modules via Zigzag Persistence and Its Applications.” Discrete Comput. Geom. 71 (2024), 67-94. https://doi.org/10.1007/s00454-023-00584-z
    Relevance: the generalized rank of a finite interval restriction as the rank of the canonical inverse-limit-to-direct-limit map, together with a boundary-zigzag route for computing it.

12. Kim, D.; Kim, W.; Lee, W. “Super-Polynomial Growth of the Generalized Persistence Diagram.” SoCG 2025, LIPIcs 332, Article 64. https://doi.org/10.4230/LIPIcs.SoCG.2025.64
    Relevance: the super-polynomial growth of the interval poset over which the generalized persistence diagram is a Möbius inversion, which is why the benchmark's ladder windows (up to 671,072 intervals) cannot be handled by pairwise enumeration.

13. Frankland, M.; Stanley, D. “Multiparameter persistence modules in the large scale.” Q. J. Math. (2026). https://doi.org/10.1093/qmath/haag020
    Relevance: the multigraded-module and representation-theoretic viewpoint on multiparameter persistence.

14. Escolar, E. G.; Hiraoka, Y. “Persistence Modules on Commutative Ladders of Finite Type.” Discrete Comput. Geom. 55 (2016), 100-157. https://doi.org/10.1007/s00454-015-9746-2
    Relevance: persistence modules as representations of bound commutative-ladder quivers, providing the representation-theoretic setting for the benchmark's scale-time ladder stage.

15. Fersztand, J. “Harder–Narasimhan filtrations of persistence modules.” Trans. London Math. Soc. 11 (2024), e70003. https://doi.org/10.1112/tlm3.70003
    Relevance: modern use of quiver-representation invariants beyond ordinary rank data for persistence modules, motivating a representation-sensitive diagnostic rather than another barcode summary.

16. Mrozek, M. “Leray functor and cohomological Conley index for discrete dynamical systems.” Trans. Amer. Math. Soc. 318 (1990), 149-178.
    Relevance: the Conley index of a map as the Leray reduction of the index map of an index pair.

17. Szymczak, A. “The Conley index for discrete semidynamical systems.” Topology Appl. 66 (1995), 215-240.
    Relevance: index pairs for maps and the shift-equivalence form of the discrete Conley index.

18. Franks, J.; Richeson, D. “Shift equivalence and the Conley index.” Trans. Amer. Math. Soc. 352 (2000), 3305-3322.
    Relevance: the Conley index of a map is a shift-equivalence class; over a field it is determined by the similarity class of the invertible part of the index map (the reported rational invariant factors), and over `Z` the Bowen-Franks group `coker(I-f)` is a shift-equivalence invariant.

19. Kaczynski, T.; Mischaikow, K.; Mrozek, M. Computational Homology. Applied Mathematical Sciences 157, Springer (2004). https://doi.org/10.1007/b97315
    Relevance: cubical multivalued representations, chain selectors of acyclic-valued lower-semicontinuous maps, homology of maps, and the computation of index maps for the Hénon map.

20. Pilarczyk, P.; Stolot, K. “Excision-preserving cubical approach to the algorithmic computation of the discrete Conley index.” Topology Appl. 155 (2008), 1149-1162.
    Relevance: combinatorial index pairs whose image pair is an excision of the index pair, as in the reference's `(P1 ∪ F(P0), P0 ∪ F(P0))` construction.

21. Bush, J.; Gameiro, M.; Harker, S.; Kokubu, H.; Mischaikow, K.; Obayashi, I.; Pilarczyk, P. “Combinatorial-topological framework for the analysis of global dynamics.” Chaos 22 (2012), 047508. https://doi.org/10.1063/1.4767672
    Relevance: Conley-Morse graphs, i.e. Morse graphs annotated with Conley indices computed from outer box enclosures, as produced by global-dynamics databases.

22. Bowen, R.; Franks, J. “Homology for zero-dimensional nonwandering sets.” Ann. of Math. 106 (1977), 73-92.
    Relevance: the Bowen-Franks group `coker(I-A)` as an invariant of integer matrices under (strong) shift equivalence, reported for each integral index map.

23. Kim, W.; Mémoli, F. “Generalized persistence diagrams for persistence modules over posets.” J. Appl. Comput. Topol. 5 (2021), 533-581. https://doi.org/10.1007/s41468-021-00075-1
    Relevance: definition of the generalized persistence diagram as the Möbius inversion of the generalized rank invariant over intervals ordered by inclusion.

24. Rota, G.-C. “On the foundations of combinatorial theory I. Theory of Möbius functions.” Z. Wahrscheinlichkeitstheorie 2 (1964), 340-368.
    Relevance: the crosscut theorem used to evaluate the Möbius function of the interval lattice from joins of covers.

Benchmark-specific choices: the finer 128 x 96 Conley grid and its 5 x 5 parameter sublattice, the path-interval sets attached to Hasse edges, the `null` convention for box sets that contain an escaping box, the Leray/invariant-factor and Bowen-Franks output conventions, the Hénon parameter lattice, phase grid, interval enclosure, one-box exit-pair annotation, event-classification precedence, canonical signature convention, continuation paths and windows, prefix-union bifiltration, the scale-time generalized-persistence-diagram windows, the dilation radii, scale-time query family, deformation-complex output convention, and JSON schema are original benchmark definitions.
