#!/usr/bin/env python3
import json, math, os, sys, gc, ctypes, subprocess, tempfile
from fractions import Fraction
from collections import defaultdict, deque, Counter

sys.setrecursionlimit(200000)

class GF2Basis:
    def __init__(self):
        self.piv = {}
        self.rank = 0
    def add(self, vec, label=0):
        v, lab = int(vec), int(label)
        while v:
            p = v.bit_length() - 1
            if p in self.piv:
                vv, ll = self.piv[p]
                v ^= vv; lab ^= ll
            else:
                self.piv[p] = (v, lab)
                self.rank += 1
                return True, (v, lab)
        return False, (0, lab)
    def reduce(self, vec, label=0):
        v, lab = int(vec), int(label)
        while v:
            p = v.bit_length() - 1
            if p not in self.piv:
                break
            vv, ll = self.piv[p]
            v ^= vv; lab ^= ll
        return v, lab

def independent_vectors(vecs):
    b = GF2Basis(); out = []
    for v in vecs:
        ok, _ = b.add(v)
        if ok:
            out.append(v)
    return out

def column_rank(vecs):
    b = GF2Basis()
    for v in vecs: b.add(v)
    return b.rank

def kernel_basis_from_columns(cols):
    b = GF2Basis(); deps = []
    for j, col in enumerate(cols):
        v, coeff = int(col), 1 << j
        while v:
            p = v.bit_length() - 1
            if p in b.piv:
                vv, ll = b.piv[p]
                v ^= vv; coeff ^= ll
            else:
                b.piv[p] = (v, coeff); b.rank += 1
                break
        if v == 0:
            deps.append(coeff)
    return deps

def tarjan_scc(n, offsets, targets):
    index = 0; stack = []; on = [False] * n
    indices = [-1] * n; low = [0] * n; comps = []
    def dfs(v):
        nonlocal index
        indices[v] = low[v] = index; index += 1
        stack.append(v); on[v] = True
        for kk in range(offsets[v], offsets[v+1]):
            w = targets[kk]
            if indices[w] < 0:
                dfs(w); low[v] = min(low[v], low[w])
            elif on[w]:
                low[v] = min(low[v], indices[w])
        if low[v] == indices[v]:
            c = []
            while True:
                w = stack.pop(); on[w] = False; c.append(w)
                if w == v: break
            comps.append(c)
    for v in range(n):
        if indices[v] < 0:
            dfs(v)
    return comps

def cells_of_boxes(boxes, nx):
    verts, edges, squares = set(), set(), set()
    for q in boxes:
        i, j = q % nx, q // nx
        squares.add((i, j))
        verts.update(((i,j),(i+1,j),(i,j+1),(i+1,j+1)))
        edges.update(((0,i,j),(0,i,j+1),(1,i,j),(1,i+1,j)))
    return verts, edges, squares

def box_neighborhood(boxes, nx, ny):
    out = set()
    for q in boxes:
        i, j = q % nx, q // nx
        for dj in (-1,0,1):
            for di in (-1,0,1):
                ii, jj = i+di, j+dj
                if 0 <= ii < nx and 0 <= jj < ny:
                    out.add(ii + nx*jj)
    return out

def exit_pair(boxes, nx, ny, offsets, targets, escapes):
    if not boxes:
        return set(), set()
    N = box_neighborhood(boxes, nx, ny)
    L = set()
    for q in N:
        if escapes[q]:
            L.add(q); continue
        for kk in range(offsets[q], offsets[q+1]):
            if targets[kk] not in N:
                L.add(q); break
    return N, L

def homology_data(N, L, nx):
    KN = cells_of_boxes(N, nx); KL = cells_of_boxes(L, nx)
    bases = [sorted(KN[d] - KL[d]) for d in range(3)]
    idx = [{c:i for i,c in enumerate(bases[d])} for d in range(3)]
    cols1 = []
    for axis, i, j in bases[1]:
        faces = ((i,j),(i+1,j)) if axis == 0 else ((i,j),(i,j+1))
        v = 0
        for f in faces:
            k = idx[0].get(f)
            if k is not None: v ^= 1 << k
        cols1.append(v)
    cols2 = []
    for i, j in bases[2]:
        faces = ((0,i,j),(0,i,j+1),(1,i,j),(1,i+1,j))
        v = 0
        for f in faces:
            k = idx[1].get(f)
            if k is not None: v ^= 1 << k
        cols2.append(v)
    boundaries = [None, cols1, cols2]
    out = []
    for d in range(3):
        Z = [1 << j for j in range(len(bases[0]))] if d == 0 else kernel_basis_from_columns(boundaries[d])
        B = independent_vectors(boundaries[d+1] if d < 2 else [])
        span = GF2Basis(); Bind = []
        for v in B:
            ok, _ = span.add(v)
            if ok: Bind.append(v)
        H = []
        for z in Z:
            rem, _ = span.reduce(z)
            if rem:
                span.add(z); H.append(z)
        coord = GF2Basis()
        for i, v in enumerate(Bind): coord.add(v, 1 << i)
        for j, v in enumerate(H): coord.add(v, 1 << (len(Bind)+j))
        out.append({"basis":bases[d], "B":Bind, "H":H, "coord":coord})
    return out

def betti_of_pair(N, L, nx):
    H = homology_data(N, L, nx)
    return [len(x["H"]) for x in H], [len(x["basis"]) for x in H]

def apply_chain_map(vec, src_basis, tgt_index):
    out = 0; x = vec
    while x:
        bit = x & -x; j = bit.bit_length()-1; x ^= bit
        k = tgt_index.get(src_basis[j])
        if k is not None: out ^= 1 << k
    return out

def induced_map(srcH, tgtH, d):
    tgt_index = {c:i for i,c in enumerate(tgtH[d]["basis"])}
    bdim = len(tgtH[d]["B"]); cols = []
    for h in srcH[d]["H"]:
        y = apply_chain_map(h, srcH[d]["basis"], tgt_index)
        rem, lab = tgtH[d]["coord"].reduce(y)
        if rem:
            raise RuntimeError("inclusion did not map cycles to represented cycles")
        cols.append(lab >> bdim)
    return cols

def analyze_frame(frame, nx, ny):
    offsets, targets, escapes = frame["offsets"], frame["targets"], frame["escapes"]
    n = nx*ny
    comps = tarjan_scc(n, offsets, targets)
    recurrent = []
    for c in comps:
        if len(c) > 1:
            recurrent.append(sorted(c))
        else:
            v = c[0]
            if any(targets[k] == v for k in range(offsets[v], offsets[v+1])):
                recurrent.append([v])
    recurrent.sort(key=lambda c:c[0])
    cid = {v:i for i,c in enumerate(comps) for v in c}
    cadj = [set() for _ in comps]
    for v in range(n):
        cv = cid[v]
        for kk in range(offsets[v], offsets[v+1]):
            cw = cid[targets[kk]]
            if cw != cv: cadj[cv].add(cw)
    rcids = [cid[c[0]] for c in recurrent]
    desc = [set() for _ in recurrent]
    for i, rc in enumerate(rcids):
        seen = {rc}; st = [rc]
        while st:
            x = st.pop()
            for y in cadj[x]:
                if y not in seen: seen.add(y); st.append(y)
        for j, rr in enumerate(rcids):
            if i != j and rr in seen: desc[i].add(j)
    edges = []
    for i in range(len(recurrent)):
        for j in sorted(desc[i]):
            if not any(k != i and k != j and k in desc[i] and j in desc[k] for k in range(len(recurrent))):
                edges.append([i,j])
    terminals = [i for i,d in enumerate(desc) if not d]
    nodes = []
    for i, c in enumerate(recurrent):
        N, L = exit_pair(set(c), nx, ny, offsets, targets, escapes)
        rb, rd = betti_of_pair(N, L, nx)
        ab, ad = betti_of_pair(set(c), set(), nx)
        nodes.append({
            "morse_id": i,
            "min_box_id": c[0],
            "size": len(c),
            "block_betti_F2": ab,
            "exit_pair_betti_F2": rb,
            "attractor": i in terminals,
        })
    return {"recurrent":recurrent,"nodes":nodes,"edges":edges,"terminals":terminals}

def node_label(node):
    return (tuple(node["block_betti_F2"]), tuple(node["exit_pair_betti_F2"]), bool(node["attractor"]))

def canonical_signature(analysis):
    labels = [node_label(n) for n in analysis["nodes"]]
    groups = defaultdict(list)
    for i, lab in enumerate(labels): groups[lab].append(i)
    ordered = sorted(groups)
    choices = [list(__import__('itertools').permutations(groups[x])) for x in ordered]
    best = None
    import itertools
    for parts in itertools.product(*choices):
        order = [i for p in parts for i in p]
        inv = {old:new for new,old in enumerate(order)}
        ed = tuple(sorted((inv[a],inv[b]) for a,b in analysis["edges"]))
        sig = (tuple(labels[i] for i in order), ed)
        if best is None or sig < best: best = sig
    return best if best is not None else (tuple(), tuple())

def union_relation(frame_a, ana_a, frame_b, ana_b, n):
    oa, ta = frame_a["offsets"], frame_a["targets"]
    ob, tb = frame_b["offsets"], frame_b["targets"]
    offsets = [0]; targets = []
    for q in range(n):
        s = set(ta[oa[q]:oa[q+1]]); s.update(tb[ob[q]:ob[q+1]])
        targets.extend(sorted(s)); offsets.append(len(targets))
    comps = tarjan_scc(n, offsets, targets)
    cid = {v:i for i,c in enumerate(comps) for v in c}
    rel = []
    for i, A in enumerate(ana_a["recurrent"]):
        ca = {cid[v] for v in A}
        for j, B in enumerate(ana_b["recurrent"]):
            if ca.intersection(cid[v] for v in B): rel.append([i,j])
    return rel

def classify_event(ana_a, ana_b, rel):
    da = [0]*len(ana_a["nodes"]); db = [0]*len(ana_b["nodes"])
    for i,j in rel: da[i]+=1; db[j]+=1
    birth = any(x==0 for x in db); death = any(x==0 for x in da)
    split = any(x>1 for x in da); merge = any(x>1 for x in db)
    if split and merge: return "split-merge"
    if split: return "split"
    if merge: return "merge"
    if birth and death: return "birth-death"
    if birth: return "birth"
    if death: return "death"
    mapping = {i:j for i,j in rel}
    same_nodes = all(node_label(ana_a["nodes"][i]) == node_label(ana_b["nodes"][j]) for i,j in rel)
    mapped_edges = sorted((mapping[a],mapping[b]) for a,b in ana_a["edges"])
    return "continuation" if same_nodes and mapped_edges == sorted(map(tuple, ana_b["edges"])) else "rewiring"

def relation_for_oriented_edge(p, q, edge_rel):
    if (p,q) in edge_rel: return edge_rel[(p,q)]
    return [[j,i] for i,j in edge_rel[(q,p)]]

def build_pair_for_selection(frame, ana, selected, nx, ny):
    boxes = set()
    for mid in selected: boxes.update(ana["recurrent"][mid])
    return exit_pair(boxes, nx, ny, frame["offsets"], frame["targets"], frame["escapes"])

def relation_space(dims, maps, a, b):
    offs = [0]
    for i in range(a,b+1): offs.append(offs[-1]+dims[i])
    rels = []
    for k in range(a,b):
        direction, cols = maps[k]
        if direction == "forward": src, tgt = k, k+1
        else: src, tgt = k+1, k
        so, to = offs[src-a], offs[tgt-a]
        for j, col in enumerate(cols):
            v = 1 << (so+j); x = col
            while x:
                bit = x & -x; r = bit.bit_length()-1; x ^= bit
                v ^= 1 << (to+r)
            rels.append(v)
    return offs, independent_vectors(rels)

def limit_space(dims, maps, a, b):
    offs = [0]
    for i in range(a,b+1): offs.append(offs[-1]+dims[i])
    cbase = []; ncon = 0
    for k in range(a,b):
        direction, _ = maps[k]
        td = dims[k+1] if direction == "forward" else dims[k]
        cbase.append(ncon); ncon += td
    cols = [0]*offs[-1]
    for kk,k in enumerate(range(a,b)):
        direction, mcols = maps[k]; co = cbase[kk]
        if direction == "forward": src,tgt = k,k+1
        else: src,tgt = k+1,k
        so,to = offs[src-a],offs[tgt-a]
        for j,col in enumerate(mcols):
            x=col
            while x:
                bit=x&-x; r=bit.bit_length()-1; x^=bit
                cols[so+j] ^= 1 << (co+r)
        for r in range(dims[tgt]): cols[to+r] ^= 1 << (co+r)
    return offs, kernel_basis_from_columns(cols)

def interval_rank(dims, maps, a, b):
    if a == b: return dims[a]
    offs, rels = relation_space(dims, maps, a, b)
    _, lim = limit_space(dims, maps, a, b)
    basis = GF2Basis()
    for v in rels: basis.add(v)
    r0 = basis.rank; mask = (1 << dims[a]) - 1 if dims[a] else 0
    for x in lim: basis.add(x & mask)
    return basis.rank - r0

def barcode_for_zigzag(dims, maps):
    n = len(dims); rho = [[0]*(n-a) for a in range(n)]
    for a in range(n):
        for b in range(a,n): rho[a][b-a] = interval_rank(dims,maps,a,b)
    def R(a,b):
        if a < 0 or b >= n or a > b: return 0
        return rho[a][b-a]
    bars = []
    for a in range(n):
        for b in range(a,n):
            m = R(a,b)-R(a-1,b)-R(a,b+1)+R(a-1,b+1)
            if m: bars.append({"start":a,"end":b,"multiplicity":m})
    return rho, bars

def path_analysis(pathrec, frames, analyses, edge_rel, nx, ny):
    ids = pathrec["parameter_ids"]; seed = pathrec["seed_box_id"]
    a0 = analyses[ids[0]]; start = next(i for i,c in enumerate(a0["recurrent"]) if seed in c)
    selected = [[start]]
    for p,q in zip(ids, ids[1:]):
        rel = relation_for_oriented_edge(p,q,edge_rel)
        prev = set(selected[-1]); nxt = sorted({j for i,j in rel if i in prev})
        selected.append(nxt)
    pairs=[]; evenH=[]
    for pid,sel in zip(ids,selected):
        N,L=build_pair_for_selection(frames[pid], analyses[pid], sel, nx, ny)
        pairs.append((N,L)); evenH.append(homology_data(N,L,nx))
    Hnodes=[]
    for i in range(len(ids)):
        Hnodes.append(evenH[i])
        if i+1 < len(ids):
            N=pairs[i][0] | pairs[i+1][0]; L=pairs[i][1] | pairs[i+1][1]
            Hnodes.append(homology_data(N,L,nx))
    dimsout=[]
    for d in range(3):
        maps=[]
        for k in range(len(Hnodes)-1):
            if k%2==0: maps.append(("forward", induced_map(Hnodes[k],Hnodes[k+1],d)))
            else: maps.append(("backward", induced_map(Hnodes[k+1],Hnodes[k],d)))
        dims=[len(h[d]["H"]) for h in Hnodes]
        rho,bars=barcode_for_zigzag(dims,maps)
        dimsout.append({"dimension":d,"node_dimensions_F2":dims,"rank_rows_F2":rho,"interval_multiplicities_F2":bars})
    return {"path_id":pathrec["path_id"],"parameter_ids":ids,"seed_box_id":seed,"selected_morse_ids_by_frame":selected,"dimensions":dimsout}


def global_continuation_family(seedrec, analyses, edge_rel, parameter_edges):
    sp = seedrec["parameter_id"]; sb = seedrec["seed_box_id"]
    sm = next(i for i,c in enumerate(analyses[sp]["recurrent"]) if sb in c)
    adj = defaultdict(list)
    for p,q in parameter_edges:
        for i,j in edge_rel[(p,q)]:
            adj[(p,i)].append((q,j)); adj[(q,j)].append((p,i))
    seen={(sp,sm)}; dq=[(sp,sm)]
    while dq:
        x=dq.pop()
        for y in adj.get(x,()):
            if y not in seen:
                seen.add(y); dq.append(y)
    out=[[] for _ in analyses]
    for p,m in seen: out[p].append(m)
    for x in out: x.sort()
    return out

def diagram_limit_colimit_stats(objects, arrows, anchor, d):
    # objects are homology_data records; arrows are (source_index,target_index,columns).
    # Return dimensions of the inverse limit, direct colimit, and the image of the
    # canonical natural map lim -> colim.  The chosen anchor only represents that
    # natural map; on each connected query every object component has the same class.
    dims=[len(H[d]["H"]) for H in objects]
    offs=[0]
    for z in dims: offs.append(offs[-1]+z)
    rels=[]
    ncon=sum(dims[t] for s,t,cols in arrows)
    ccols=[0]*offs[-1]; co=0
    for s,t,mcols in arrows:
        so,to=offs[s],offs[t]; td=dims[t]
        for j,col in enumerate(mcols):
            x=col
            while x:
                bit=x&-x; r=bit.bit_length()-1; x^=bit
                ccols[so+j] ^= 1 << (co+r)
        for r in range(td): ccols[to+r] ^= 1 << (co+r)
        for j,col in enumerate(mcols):
            v=1 << (so+j); x=col
            while x:
                bit=x&-x; r=bit.bit_length()-1; x^=bit
                v ^= 1 << (to+r)
            rels.append(v)
        co += td
    lim=kernel_basis_from_columns(ccols)
    span=GF2Basis()
    for v in rels: span.add(v)
    r0=span.rank
    colim_dim=offs[-1]-r0
    if dims[anchor]:
        mask=((1 << dims[anchor])-1) << offs[anchor]
        for x in lim: span.add(x & mask)
    return len(lim), colim_dim, span.rank-r0

def diagram_generalized_rank(objects, arrows, anchor, d):
    return diagram_limit_colimit_stats(objects,arrows,anchor,d)[2]

def selected_exit_pairs(selected, frames, analyses, nx, ny):
    return [build_pair_for_selection(frames[p], analyses[p], mids, nx, ny)
            for p,mids in enumerate(selected)]

def continuation_surface(data, frames, analyses, edge_rel, nx, ny, selected=None, pairs=None):
    if selected is None:
        selected=global_continuation_family(data["global_continuation_seed"], analyses, edge_rel, data["parameter_edges"])
    if pairs is None:
        pairs=selected_exit_pairs(selected,frames,analyses,nx,ny)
    nodeH=[homology_data(N,L,nx) for N,L in pairs]
    edgeH={}; edgeMaps={}
    for p,q in data["parameter_edges"]:
        N=pairs[p][0] | pairs[q][0]; L=pairs[p][1] | pairs[q][1]
        H=homology_data(N,L,nx); edgeH[(p,q)]=H
        edgeMaps[(p,q,p)]=[induced_map(nodeH[p],H,d) for d in range(3)]
        edgeMaps[(p,q,q)]=[induced_map(nodeH[q],H,d) for d in range(3)]
    na=data["parameter_grid"]["na"]
    ranks=[]
    for qrec in data["window_queries"]:
        i0,j0,i1,j1=qrec["bounds"]
        ps=[i+na*j for j in range(j0,j1+1) for i in range(i0,i1+1)]
        pset=set(ps)
        es=[tuple(e) for e in data["parameter_edges"] if e[0] in pset and e[1] in pset]
        objects=[nodeH[p] for p in ps] + [edgeH[e] for e in es]
        node_index={p:k for k,p in enumerate(ps)}
        edge_index={e:len(ps)+k for k,e in enumerate(es)}
        out=[]
        for d in range(3):
            arrows=[]
            for e in es:
                p,q=e; t=edge_index[e]
                arrows.append((node_index[p],t,edgeMaps[(p,q,p)][d]))
                arrows.append((node_index[q],t,edgeMaps[(p,q,q)][d]))
            out.append(diagram_generalized_rank(objects,arrows,0,d))
        ranks.append({"window_id":qrec["window_id"],"bounds":qrec["bounds"],"rank_F2":out})
    seed=data["global_continuation_seed"]
    return {"seed_parameter_id":seed["parameter_id"],"seed_box_id":seed["seed_box_id"],"selected_morse_ids_by_parameter":selected,"window_ranks_F2":ranks}

def multiparameter_persistence(data, frames, analyses, edge_rel, nx, ny, selected=None, pairs=None):
    """Betti tables and signed rectangle rank decomposition of one dynamics-derived bifiltration."""
    if selected is None:
        selected=global_continuation_family(data["global_continuation_seed"], analyses, edge_rel, data["parameter_edges"])
    if pairs is None:
        pairs=selected_exit_pairs(selected,frames,analyses,nx,ny)
    na,nb=data["parameter_grid"]["na"],data["parameter_grid"]["nb"]

    # Prefix-union relative pairs.  This is a genuine bifiltration: both N and L
    # only grow when either parameter-grid coordinate is increased.
    ppairs=[[None]*na for _ in range(nb)]
    H=[[None]*na for _ in range(nb)]
    for j in range(nb):
        for i in range(na):
            N=set(); L=set()
            if i:
                N.update(ppairs[j][i-1][0]); L.update(ppairs[j][i-1][1])
            if j:
                N.update(ppairs[j-1][i][0]); L.update(ppairs[j-1][i][1])
            p=i+na*j
            N.update(pairs[p][0]); L.update(pairs[p][1])
            ppairs[j][i]=(N,L)
            H[j][i]=homology_data(N,L,nx)

    # Cover maps of the Z^2 persistence module.
    xmap={}; ymap={}
    for d in range(3):
        for j in range(nb):
            for i in range(1,na): xmap[(d,i,j)]=induced_map(H[j][i-1],H[j][i],d)
        for j in range(1,nb):
            for i in range(na): ymap[(d,i,j)]=induced_map(H[j-1][i],H[j][i],d)

    dimsout=[]
    for d in range(3):
        module_dims=[len(H[j][i][d]["H"]) for j in range(nb) for i in range(na)]
        betti=[[] for _ in range(3)]
        for j in range(nb):
            for i in range(na):
                C=len(H[j][i][d]["H"])
                A=len(H[j][i-1][d]["H"]) if i else 0
                B=len(H[j-1][i][d]["H"]) if j else 0
                D=len(H[j-1][i-1][d]["H"]) if i and j else 0
                # Koszul differential d1: M_(i-1,j) + M_(i,j-1) -> M_(i,j).
                d1=(xmap[(d,i,j)] if i else []) + (ymap[(d,i,j)] if j else [])
                r1=column_rank(d1)
                # d2: M_(i-1,j-1) -> M_(i-1,j) + M_(i,j-1).
                d2=[]
                if D:
                    ya=ymap[(d,i-1,j)]
                    xb=xmap[(d,i,j-1)]
                    d2=[ya[k] ^ (xb[k] << A) for k in range(D)]
                    # Exact commutativity is part of the persistence-module contract.
                    for col in d2:
                        z=0; x=col
                        while x:
                            bit=x & -x; q=bit.bit_length()-1; x^=bit
                            z ^= d1[q]
                        if z: raise RuntimeError("noncommuting bifiltration square")
                r2=column_rank(d2)
                vals=(C-r1, A+B-r1-r2, D-r2)
                if any(v<0 for v in vals): raise RuntimeError("invalid Koszul Betti number")
                for h,v in enumerate(vals):
                    if v: betti[h].append([i,j,v])

        # Standard rank invariant r(u,v) for every comparable pair u<=v.
        ranks={}
        for j0 in range(nb):
            for i0 in range(na):
                src=H[j0][i0]
                for j1 in range(j0,nb):
                    for i1 in range(i0,na):
                        if i0==i1 and j0==j1: r=len(src[d]["H"])
                        else: r=column_rank(induced_map(src,H[j1][i1],d))
                        ranks[(i0,j0,i1,j1)]=r
        def R(i0,j0,i1,j1):
            if i0<0 or j0<0 or i1>=na or j1>=nb or i0>i1 or j0>j1: return 0
            return ranks[(i0,j0,i1,j1)]

        # Four-dimensional Möbius inversion of the rank invariant.  Coefficients
        # are signed integers; rectangles are closed grid intervals [birth,death].
        rects=[]
        for j0 in range(nb):
            for i0 in range(na):
                for j1 in range(j0,nb):
                    for i1 in range(i0,na):
                        mu=0
                        for e0 in (0,1):
                            for e1 in (0,1):
                                for f0 in (0,1):
                                    for f1 in (0,1):
                                        term=R(i0-e0,j0-e1,i1+f0,j1+f1)
                                        mu += (-1 if (e0+e1+f0+f1)&1 else 1)*term
                        if mu:
                            rects.append({"birth":[i0,j0],"death":[i1,j1],"multiplicity":mu})
        dimsout.append({
            "dimension":d,
            "module_dimensions_F2":module_dims,
            "betti_tables_F2":[{"homological_degree":h,"nonzero_grades":betti[h]} for h in range(3)],
            "signed_rectangle_rank_decomposition":rects,
        })
    return {"parameter_grid":[na,nb],"dimensions":dimsout}



def dilate_boxes(boxes, radius, nx, ny):
    out=set()
    for q in boxes:
        i,j=q%nx,q//nx
        for dj in range(-radius,radius+1):
            jj=j+dj
            if not (0<=jj<ny): continue
            for di in range(-radius,radius+1):
                ii=i+di
                if 0<=ii<nx: out.add(ii+nx*jj)
    return out

def raw_exit_pair_at_radius(boxes, radius, frame, nx, ny):
    N=dilate_boxes(boxes,radius,nx,ny); L=set()
    offsets,targets,escapes=frame["offsets"],frame["targets"],frame["escapes"]
    for q in N:
        if escapes[q]: L.add(q); continue
        for kk in range(offsets[q],offsets[q+1]):
            if targets[kk] not in N:
                L.add(q); break
    return N,L

def path_selected_family(pathrec, frames, analyses, edge_rel):
    ids=pathrec["parameter_ids"]; seed=pathrec["seed_box_id"]
    a0=analyses[ids[0]]
    start=next(i for i,c in enumerate(a0["recurrent"]) if seed in c)
    selected=[[start]]
    for p,q in zip(ids,ids[1:]):
        rel=relation_for_oriented_edge(p,q,edge_rel); prev=set(selected[-1])
        selected.append(sorted({j for i,j in rel if i in prev}))
    return selected

def matrix_compose(B, A):
    # Column matrices: A: U->V, B: V->W.  Return B A.
    out=[]
    for col in A:
        y=0; x=col
        while x:
            bit=x&-x; k=bit.bit_length()-1; x^=bit
            y ^= B[k]
        out.append(y)
    return out

def extended_zigzag_module(pathrec, radii, frames, analyses, edge_rel, nx, ny):
    ids=pathrec["parameter_ids"]; selected=path_selected_family(pathrec,frames,analyses,edge_rel)
    cumulative_L=[set() for _ in ids]; Hgrid=[]
    for radius in radii:
        even_pairs=[]
        for k,(pid,mids) in enumerate(zip(ids,selected)):
            boxes=set()
            for mid in mids: boxes.update(analyses[pid]["recurrent"][mid])
            N,L0=raw_exit_pair_at_radius(boxes,radius,frames[pid],nx,ny)
            cumulative_L[k].update(L0)
            even_pairs.append((N,set(cumulative_L[k])))
        row=[]
        for k in range(len(ids)):
            row.append(homology_data(even_pairs[k][0],even_pairs[k][1],nx))
            if k+1<len(ids):
                N=even_pairs[k][0] | even_pairs[k+1][0]
                L=even_pairs[k][1] | even_pairs[k+1][1]
                row.append(homology_data(N,L,nx))
        Hgrid.append(row)
    return selected,Hgrid

def extended_zigzag_arrows(Hgrid, d):
    nr=len(Hgrid); z=len(Hgrid[0])
    def vid(r,t): return r*z+t
    arrows=[]; amap={}
    for r in range(nr):
        for t in range(z-1):
            if t%2==0: sr,st=(r,t),(r,t+1)
            else: sr,st=(r,t+1),(r,t)
            cols=induced_map(Hgrid[sr[0]][sr[1]],Hgrid[st[0]][st[1]],d)
            key=("h",r,t); amap[key]=len(arrows)
            arrows.append((vid(*sr),vid(*st),cols,key))
    for r in range(nr-1):
        for t in range(z):
            cols=induced_map(Hgrid[r][t],Hgrid[r+1][t],d)
            key=("v",r,t); amap[key]=len(arrows)
            arrows.append((vid(r,t),vid(r+1,t),cols,key))
    return arrows,amap

def deformation_cohomology(Hgrid, d):
    """Linearized commutativity cohomology of the scale x zigzag ladder."""
    nr=len(Hgrid); z=len(Hgrid[0])
    dims=[len(Hgrid[r][t][d]["H"]) for r in range(nr) for t in range(z)]
    def vid(r,t): return r*z+t
    arrows,amap=extended_zigzag_arrows(Hgrid,d)
    squares=[]
    for r in range(nr-1):
        for t in range(z-1):
            hs,ht=(t,t+1) if t%2==0 else (t+1,t)
            ia=amap[("h",r,t)]
            ib=amap[("v",r,ht)]
            ic=amap[("v",r,hs)]
            idd=amap[("h",r+1,t)]
            a,b,c,dd=[arrows[k] for k in (ia,ib,ic,idd)]
            if matrix_compose(b[2],a[2]) != matrix_compose(dd[2],c[2]):
                raise RuntimeError("noncommuting extended-zigzag square")
            squares.append((vid(r,hs),vid(r+1,ht),ia,ib,ic,idd))

    aoff=[]; c1=0
    for s,t,cols,key in arrows:
        aoff.append(c1); c1 += dims[s]*dims[t]
    soff=[]; c2=0
    for s,t,*rest in squares:
        soff.append(c2); c2 += dims[s]*dims[t]
    c0=sum(v*v for v in dims)

    outgoing=[[] for _ in dims]; incoming=[[] for _ in dims]
    for ei,(s,t,cols,key) in enumerate(arrows):
        outgoing[s].append(ei); incoming[t].append(ei)

    delta0=[]
    for v,dv in enumerate(dims):
        for row in range(dv):
            for col in range(dv):
                out=0
                for ei in outgoing[v]:
                    s,t,A,key=arrows[ei]; dt=dims[t]
                    x=A[row]
                    while x:
                        bit=x&-x; rr=bit.bit_length()-1; x^=bit
                        out ^= 1 << (aoff[ei] + col*dt + rr)
                for ei in incoming[v]:
                    s,t,A,key=arrows[ei]; dt=dims[t]
                    for j,ac in enumerate(A):
                        if (ac>>col)&1:
                            out ^= 1 << (aoff[ei] + j*dt + row)
                delta0.append(out)
    r0=column_rank(delta0)

    memberships=[[] for _ in arrows]
    for qi,(sv,tv,ia,ib,ic,idd) in enumerate(squares):
        memberships[ia].append((qi,"pre",ib))
        memberships[ib].append((qi,"post",ia))
        memberships[ic].append((qi,"pre",idd))
        memberships[idd].append((qi,"post",ic))
    delta1=[]
    for ei,(s,t,A,key) in enumerate(arrows):
        ds,dt=dims[s],dims[t]
        for row in range(dt):
            for col in range(ds):
                out=0
                for qi,role,other in memberships[ei]:
                    sv,tv,*rest=squares[qi]; dT=dims[tv]; O=arrows[other][2]
                    if role=="pre":
                        x=O[row]
                        while x:
                            bit=x&-x; rr=bit.bit_length()-1; x^=bit
                            out ^= 1 << (soff[qi] + col*dT + rr)
                    else:
                        for j,oc in enumerate(O):
                            if (oc>>col)&1:
                                out ^= 1 << (soff[qi] + j*dT + row)
                delta1.append(out)
    r1=column_rank(delta1)
    h0=c0-r0; h1=c1-r1-r0; h2=c2-r1
    if min(h0,h1,h2)<0: raise RuntimeError("invalid deformation cohomology")
    return {"dimension":d,"c0_dimension":c0,"c1_dimension":c1,"c2_dimension":c2,
            "delta0_rank_F2":r0,"delta1_rank_F2":r1,"h0_F2":h0,"h1_F2":h1,"h2_F2":h2}

def spatiotemporal_persistence(data, frames, analyses, edge_rel, nx, ny):
    radii=data["spatiotemporal_scale_radii"]
    query_paths={q["path_id"] for q in data.get("spatiotemporal_queries",[])}
    def_paths=set(data.get("spatiotemporal_deformation_path_ids",[]))
    need=sorted(query_paths|def_paths)
    by_pid={p["path_id"]:p for p in data["paths"]}
    modules={}
    for pid in need:
        _,H=extended_zigzag_module(by_pid[pid],radii,frames,analyses,edge_rel,nx,ny)
        modules[pid]=(H,[extended_zigzag_arrows(H,d)[0] for d in range(3)])

    qout=[]
    rindex={r:i for i,r in enumerate(radii)}
    for q in data.get("spatiotemporal_queries",[]):
        pid=q["path_id"]; H,arrows_by_d=modules[pid]; z=len(H[0])
        r0,r1=q["scale_bounds"]; t0,t1=q["time_bounds"]
        ris=list(range(rindex[r0],rindex[r1]+1)); ts=list(range(t0,t1+1))
        verts=[(r,t) for r in ris for t in ts]; local={v:k for k,v in enumerate(verts)}
        objects=[H[r][t] for r,t in verts]; dimsout=[]
        for d in range(3):
            arrows=[]
            Z=z
            for s,t,cols,key in arrows_by_d[d]:
                sv=(s//Z,s%Z); tv=(t//Z,t%Z)
                if sv in local and tv in local:
                    arrows.append((local[sv],local[tv],cols))
            ld,cd,gr=diagram_limit_colimit_stats(objects,arrows,0,d)
            dimsout.append({"dimension":d,"limit_dimension_F2":ld,"colimit_dimension_F2":cd,"generalized_rank_F2":gr})
        qout.append({"query_id":q["query_id"],"path_id":pid,"scale_bounds":q["scale_bounds"],"time_bounds":q["time_bounds"],"dimensions":dimsout})

    dout=[]
    for pid in data.get("spatiotemporal_deformation_path_ids",[]):
        H,_=modules[pid]
        dout.append({"path_id":pid,"dimensions":[deformation_cohomology(H,d) for d in range(3)]})
    return {"scale_radii":radii,"query_ranks_F2":qout,"deformation_cohomology_F2":dout}

# ---------------------------------------------------------------------------
# Rational Conley index maps on the finer enclosure frames.

class QBasis:
    """Echelon basis over Q with coefficient labels; vectors are {index: Fraction}.
    Invariant while reducing: current = input + sum(label[k] * generator_k)."""
    def __init__(self):
        self.piv = {}
    def _reduce(self, v, lab):
        v = dict(v); lab = dict(lab)
        while v:
            p = max(v)
            if p not in self.piv:
                return v, lab, p
            bv, bl = self.piv[p]; c = v[p]
            for k, x in bv.items():
                y = v.get(k, 0) - c*x
                if y: v[k] = y
                else: v.pop(k, None)
            for k, x in bl.items():
                y = lab.get(k, 0) - c*x
                if y: lab[k] = y
                else: lab.pop(k, None)
        return v, lab, None
    def add(self, v, lab=None):
        v, lab, p = self._reduce(v, lab or {})
        if p is None:
            return False, lab
        c = v[p]
        self.piv[p] = ({k: x/c for k, x in v.items()}, {k: x/c for k, x in lab.items()})
        return True, lab
    def reduce(self, v, lab=None):
        v, lab, _ = self._reduce(v, lab or {})
        return v, lab

def iterative_scc(n, offsets, targets):
    index = [-1]*n; low = [0]*n; on = [False]*n; stack = []; comps = []; counter = 0
    for root in range(n):
        if index[root] >= 0: continue
        work = [(root, offsets[root])]
        index[root] = low[root] = counter; counter += 1; stack.append(root); on[root] = True
        while work:
            v, k = work[-1]
            if k < offsets[v+1]:
                work[-1] = (v, k+1); w = targets[k]
                if index[w] < 0:
                    index[w] = low[w] = counter; counter += 1; stack.append(w); on[w] = True
                    work.append((w, offsets[w]))
                elif on[w]:
                    low[v] = min(low[v], index[w])
            else:
                work.pop()
                if work:
                    u = work[-1][0]; low[u] = min(low[u], low[v])
                if low[v] == index[v]:
                    c = []
                    while True:
                        w = stack.pop(); on[w] = False; c.append(w)
                        if w == v: break
                    comps.append(c)
    return comps

def morse_graph(frame, n):
    offsets, targets = frame["offsets"], frame["targets"]
    comps = iterative_scc(n, offsets, targets)
    recurrent = []
    for c in comps:
        if len(c) > 1 or any(targets[k] == c[0] for k in range(offsets[c[0]], offsets[c[0]+1])):
            recurrent.append(sorted(c))
    recurrent.sort(key=lambda c: c[0])
    cid = [0]*n
    for i, c in enumerate(comps):
        for v in c: cid[v] = i
    cadj = [set() for _ in comps]
    for v in range(n):
        for kk in range(offsets[v], offsets[v+1]):
            w = cid[targets[kk]]
            if w != cid[v]: cadj[cid[v]].add(w)
    rcids = [cid[c[0]] for c in recurrent]; rpos = {rc: i for i, rc in enumerate(rcids)}
    desc = []
    for rc in rcids:
        seen = {rc}; st = [rc]
        while st:
            x = st.pop()
            for y in cadj[x]:
                if y not in seen: seen.add(y); st.append(y)
        desc.append({rpos[y] for y in seen if y in rpos and y != rc})
    edges = []
    for i in range(len(recurrent)):
        for j in sorted(desc[i]):
            if not any(k in desc[i] and j in desc[k] for k in desc[i] if k != j):
                edges.append([i, j])
    return recurrent, edges, [i for i, d in enumerate(desc) if not d]

def oriented_boundary(cell, d):
    # vertex (i,j); edge (0,i,j):(i,j)->(i+1,j); edge (1,i,j):(i,j)->(i,j+1); square (i,j) counterclockwise.
    if d == 1:
        a, i, j = cell
        return {((i+1, j) if a == 0 else (i, j+1)): 1, (i, j): -1}
    if d == 2:
        i, j = cell
        return {(0, i, j): 1, (1, i+1, j): 1, (0, i, j+1): -1, (1, i, j): -1}
    return {}

def boxes_at_cell(cell, d):
    if d == 0:
        i, j = cell; return ((i-1, j-1), (i, j-1), (i-1, j), (i, j))
    if d == 1:
        a, i, j = cell; return ((i, j-1), (i, j)) if a == 0 else ((i-1, j), (i, j))
    return (cell,)

def add_chain(acc, chain, c):
    for e, s in chain.items():
        y = acc.get(e, 0) + c*s
        if y: acc[e] = y
        else: acc.pop(e, None)

class LscChainSelector:
    """Chain selector of x -> intersection of |F(B)| over boxes B of P1 containing x.
    Values are vertex-coordinate rectangles, so vertices, lattice paths and
    column-sum fillings give an integral chain map carried by the values."""
    def __init__(self, P1, offsets, targets, nx):
        self.P1 = P1; self.o = offsets; self.t = targets; self.nx = nx; self.memo = [{}, {}, {}]
    def value(self, cell, d):
        I0 = J0 = -1; I1 = J1 = 1 << 30; found = False
        for i, j in boxes_at_cell(cell, d):
            q = i + self.nx*j
            if i < 0 or i >= self.nx or q not in self.P1: continue
            lo, hi = self.t[self.o[q]], self.t[self.o[q+1]-1]
            I0 = max(I0, lo % self.nx); I1 = min(I1, hi % self.nx + 1)
            J0 = max(J0, lo // self.nx); J1 = min(J1, hi // self.nx + 1); found = True
        if not found or I0 > I1 or J0 > J1:
            raise RuntimeError("empty enclosure value")
        return I0, I1, J0, J1
    def phi(self, cell, d):
        out = self.memo[d].get(cell)
        if out is not None: return out
        I0, I1, J0, J1 = self.value(cell, d)
        if d == 0:
            out = {(I0, J0): 1}
        elif d == 1:
            a, i, j = cell
            (x, y), = self.phi((i, j), 0); (tx, ty), = self.phi((i+1, j) if a == 0 else (i, j+1), 0)
            out = {}
            while x < tx: add_chain(out, {(0, x, y): 1}, 1); x += 1
            while x > tx: add_chain(out, {(0, x-1, y): 1}, -1); x -= 1
            while y < ty: add_chain(out, {(1, x, y): 1}, 1); y += 1
            while y > ty: add_chain(out, {(1, x, y-1): 1}, -1); y -= 1
        else:
            z = {}
            for f, s in oriented_boundary(cell, 2).items(): add_chain(z, self.phi(f, 1), s)
            cols = defaultdict(dict)
            for e, s in z.items():
                if e[0] == 0: cols[e[1]][e[2]] = s
            out = {}
            for i, hs in cols.items():
                run = 0
                for j in range(J0, J1):
                    run += hs.get(j, 0)
                    if run: out[(i, j)] = run
            check = {}
            for sq, c in out.items(): add_chain(check, oriented_boundary(sq, 2), c)
            if check != z: raise RuntimeError("chain selector filling failed")
        self.memo[d][cell] = out
        return out

def conley_index_pair(A, frame, nx, ny):
    """Index pair of Inv(K(A)): W = F(A) plus the one-box collar, P0 = boxes of W\\A reachable from A inside W."""
    offsets, targets = frame["offsets"], frame["targets"]
    Aset = set(A)
    W = box_neighborhood(Aset, nx, ny)
    for q in A: W.update(targets[offsets[q]:offsets[q+1]])
    P1 = set(Aset); st = list(A)
    while st:
        v = st.pop()
        for kk in range(offsets[v], offsets[v+1]):
            w = targets[kk]
            if w in W and w not in P1: P1.add(w); st.append(w)
    return P1, P1 - Aset

def z_reduce(cells, bnd):
    """Unit-pivot algebraic Morse reduction of a based chain complex over Z.
    cells: [(key, dim)]; bnd: {key: {face_key: coeff}}.  Returns the critical cells by
    dimension (whose reduced boundaries must vanish) and the chain equivalences
    pi: C -> C_crit and iota: C_crit -> C."""
    bd = {c: dict(bnd[c]) for c, _ in cells}
    dim = {c: d for c, d in cells}
    cob = {c: {} for c, _ in cells}
    for c, fs in bd.items():
        for f, v in fs.items(): cob[f][c] = v
    alive = set(bd); steps = []
    def reduce_pair(a, b):
        u = bd[a][b]; da = dict(bd[a])
        cobb = {c: v for c, v in cob[b].items() if c != a}
        for c, w in cobb.items():
            for f, v in da.items():
                y = bd[c].get(f, 0) - w*u*v
                if y: bd[c][f] = y; cob[f][c] = y
                else: bd[c].pop(f, None); cob[f].pop(c, None)
        for g in list(cob[a]): bd[g].pop(a, None)
        for f in list(bd[a]): cob[f].pop(a, None)
        for f in list(bd[b]): cob[f].pop(b, None)
        for g in list(cob[b]): bd[g].pop(b, None)
        touched = list(da) + list(cobb) + list(bd[b])
        alive.discard(a); alive.discard(b); del bd[a], bd[b]
        steps.append((a, b, u, da, cobb))
        return touched
    order = sorted(bd, key=lambda c: (dim[c], c))
    while True:
        work = [f for f in order if f in alive]
        while work:
            f = work.pop()
            if f not in alive or len(cob[f]) != 1: continue
            (a, v), = cob[f].items()
            if v in (1, -1): work.extend(x for x in reduce_pair(a, f) if x in alive)
        pick = None
        for a in order:
            if a in alive:
                b = next((f for f, v in sorted(bd[a].items()) if v in (1, -1)), None)
                if b is not None: pick = (a, b); break
        if pick is None: break
        reduce_pair(*pick)
    if any(bd[c] for c in alive): raise RuntimeError("integral reduction left a nonunit boundary")
    crit = [sorted(c for c in alive if dim[c] == d) for d in range(3)]
    def pi(y):
        y = dict(y)
        for a, b, u, da, cobb in steps:
            yb = y.pop(b, 0); y.pop(a, None)
            if yb:
                for f, v in da.items():
                    if f == b: continue
                    z = y.get(f, 0) - yb*u*v
                    if z: y[f] = z
                    else: y.pop(f, None)
        return y
    def iota(x):
        x = dict(x)
        for a, b, u, da, cobb in reversed(steps):
            s_ = sum(x.get(c, 0)*w for c, w in cobb.items())
            if s_:
                x[a] = x.get(a, 0) - u*s_
                if not x[a]: del x[a]
        return x
    return crit, pi, iota

def integral_index_maps(A, frame, nx, ny):
    """Integer matrices of the index map on H_d(K(P1),K(P0);Z) in a Z-basis, d=0,1,2."""
    P1, P0 = conley_index_pair(A, frame, nx, ny)
    KA = cells_of_boxes(set(A), nx); K0 = cells_of_boxes(P0, nx)
    rel = [sorted(KA[d] - K0[d]) for d in range(3)]
    relset = [set(x) for x in rel]
    # vertices and squares share (i,j) coordinates, so keys carry the dimension
    cells = [((d, c), d) for d in range(3) for c in rel[d]]
    bnd = {(d, c): ({(d-1, f): v for f, v in oriented_boundary(c, d).items() if f in relset[d-1]} if d else {})
           for d in range(3) for c in rel[d]}
    crit, pi, iota = z_reduce(cells, bnd)
    sel = LscChainSelector(P1, frame["offsets"], frame["targets"], nx)
    mats = []
    for d in range(3):
        H = crit[d]; pos = {c: k for k, c in enumerate(H)}; cols = []
        for h in H:
            img = {}
            for (dd, c), v in iota({h: 1}).items():
                if dd == d: add_chain(img, sel.phi(c, d), v)
            # image cells outside K(A)\\K(P0) lie in K(P0 union F(P0)) and vanish after excision
            y = pi({(d, c): v for c, v in img.items() if c in relset[d]})
            col = [0]*len(H)
            for c, v in y.items(): col[pos[c]] = v
            cols.append(col)
        mats.append([[cols[c][r] for c in range(len(H))] for r in range(len(H))])
    return mats

def smith_diagonal(M):
    A = [row[:] for row in M]; m = len(A); n = len(A[0]) if m else 0; diag = []
    for k in range(min(m, n)):
        while True:
            piv = min(((abs(A[i][j]), i, j) for i in range(k, m) for j in range(k, n) if A[i][j]), default=None)
            if piv is None: return diag + [0]*(min(m, n) - k)
            _, i, j = piv
            A[k], A[i] = A[i], A[k]
            for row in A: row[k], row[j] = row[j], row[k]
            p = A[k][k]; done = True
            for i in range(k+1, m):
                q = A[i][k] // p
                if q: A[i] = [x - q*y for x, y in zip(A[i], A[k])]
                done = done and not A[i][k]
            for j in range(k+1, n):
                q = A[k][j] // p
                if q:
                    for r in range(m): A[r][j] -= q*A[r][k]
                done = done and not A[k][j]
            if not done: continue
            bad = next((i for i in range(k+1, m) for j in range(k+1, n) if A[i][j] % p), None)
            if bad is not None:
                A[k] = [x + y for x, y in zip(A[k], A[bad])]; continue
            diag.append(abs(p)); break
    return diag

def bowen_franks(A):
    n = len(A)
    d = [x for x in smith_diagonal([[(i == j) - A[i][j] for j in range(n)] for i in range(n)]) if x != 1] if n else []
    return sorted(x for x in d if x) + [0]*d.count(0)

def path_interval(Ma, Mb, frame):
    o, t = frame["offsets"], frame["targets"]
    fw = set(Ma); st = list(Ma)
    while st:
        v = st.pop()
        for kk in range(o[v], o[v+1]):
            if t[kk] not in fw: fw.add(t[kk]); st.append(t[kk])
    radj = defaultdict(list)
    for v in fw:
        for kk in range(o[v], o[v+1]): radj[t[kk]].append(v)
    bw = set(Mb); st = list(Mb)
    while st:
        v = st.pop()
        for u in radj[v]:
            if u not in bw: bw.add(u); st.append(u)
    return sorted(fw & bw)

def conley_record(A, frame, nx, ny):
    if any(frame["escapes"][q] for q in A): return None
    out = []
    for d, Z in enumerate(integral_index_maps(A, frame, nx, ny)):
        L = leray_reduction([[Fraction(x) for x in row] for row in Z])
        out.append({"dimension": d, "leray_dimension_Q": len(L), "invariant_factors_Q": invariant_factors(L),
                    "bowen_franks_Z": bowen_franks(Z)})
    return out

def leray_reduction(A):
    n = len(A)
    if n == 0: return []
    def apply(v):
        return {i: s for i in range(n) for s in [sum(A[i][k]*x for k, x in v.items())] if s}
    vecs = [{i: Fraction(1)}for i in range(n)]
    for _ in range(n): vecs = [apply(v) for v in vecs]
    b = QBasis(); basis = []
    for v in vecs:
        if b.add(v)[0]: basis.append(v)
    coord = QBasis()
    for k, v in enumerate(basis): coord.add(v, {k: Fraction(1)})
    L = [[Fraction(0)]*len(basis) for _ in basis]
    for c, v in enumerate(basis):
        rem, lab = coord.reduce(apply(v))
        if rem: raise RuntimeError("Leray image is not invariant")
        for r in range(len(basis)): L[r][c] = -lab.get(r, Fraction(0))
    return L

def ptrim(p):
    p = list(p)
    while p and p[-1] == 0: p.pop()
    return p

def padd(p, q):
    return ptrim([(p[i] if i < len(p) else 0) + (q[i] if i < len(q) else 0) for i in range(max(len(p), len(q)))])

def pmul(p, q):
    if not p or not q: return []
    out = [Fraction(0)]*(len(p)+len(q)-1)
    for i, a in enumerate(p):
        for j, b in enumerate(q): out[i+j] += a*b
    return ptrim(out)

def pdivmod(p, q):
    p = ptrim(p); quo = [Fraction(0)]*max(1, len(p)-len(q)+1)
    while p and len(p) >= len(q):
        c = p[-1]/q[-1]; s = len(p)-len(q); quo[s] = c
        p = padd(p, [Fraction(0)]*s + [-c*x for x in q])
    return ptrim(quo), p

def invariant_factors(L):
    """Nonconstant invariant factors of L over Q[t] via Smith form of tI-L."""
    m = len(L)
    X = [[ptrim([-L[i][j], Fraction(1)] if i == j else [-L[i][j]]) for j in range(m)] for i in range(m)]
    diag = []
    for k in range(m):
        while True:
            piv = min(((len(X[i][j]), i, j) for i in range(k, m) for j in range(k, m) if X[i][j]), default=None)
            if piv is None: raise RuntimeError("singular characteristic matrix")
            _, i, j = piv
            X[k], X[i] = X[i], X[k]
            for row in X: row[k], row[j] = row[j], row[k]
            p = X[k][k]; clean = True
            for i in range(k+1, m):
                if X[i][k]:
                    qt, _ = pdivmod(X[i][k], p)
                    X[i] = [padd(X[i][c], pmul([-x for x in qt], X[k][c])) for c in range(m)]
                    clean = clean and not X[i][k]
            for j in range(k+1, m):
                if X[k][j]:
                    qt, _ = pdivmod(X[k][j], p)
                    for r in range(m): X[r][j] = padd(X[r][j], pmul([-x for x in qt], X[r][k]))
                    clean = clean and not X[k][j]
            if not clean: continue
            bad = next((i for i in range(k+1, m) for j in range(k+1, m) if X[i][j] and pdivmod(X[i][j], p)[1]), None)
            if bad is not None:
                X[k] = [padd(X[k][c], X[bad][c]) for c in range(m)]; continue
            diag.append([x/p[-1] for x in p]); break
    out = []
    for p in diag:
        if len(p) > 1:
            if any(x.denominator != 1 for x in p): raise RuntimeError("nonintegral invariant factor")
            out.append([int(x) for x in p])
    for a, b in zip(out, out[1:]):
        if len(a) > len(b) or pdivmod([Fraction(x) for x in b], [Fraction(x) for x in a])[1]:
            raise RuntimeError("invariant factors are not a divisibility chain")
    return out

def conley_morse_graphs(data):
    nx, ny = data["conley_phase_grid"]["nx"], data["conley_phase_grid"]["ny"]
    out = []
    for fr in data.get("conley_frames", []):
        recurrent, edges, terminals = morse_graph(fr, nx*ny)
        mout = [{"morse_id": mid, "min_box_id": M[0], "size": len(M), "attractor": mid in terminals,
                 "conley_index": conley_record(M, fr, nx, ny)} for mid, M in enumerate(recurrent)]
        iout = []
        for a, b in edges:
            I = path_interval(recurrent[a], recurrent[b], fr)
            iout.append({"source": a, "target": b, "size": len(I), "conley_index": conley_record(I, fr, nx, ny)})
        out.append({"conley_frame_id": fr["conley_frame_id"], "parameter_id": fr["parameter_id"], "morse_sets": mout,
                    "morse_edges": edges, "interval_indices": iout})
    return out


# ---------------------------------------------------------------------------
# Generalized persistence diagrams (Moebius inversion of the generalized rank
# over the poset of intervals of a grid window, ordered by inclusion).

def bifiltration_module(data, frames, analyses, edge_rel, nx, ny):
    """Dimensions and cover maps of the prefix-union bifiltration of Section 5."""
    selected=global_continuation_family(data["global_continuation_seed"], analyses, edge_rel, data["parameter_edges"])
    pairs=selected_exit_pairs(selected,frames,analyses,nx,ny)
    na,nb=data["parameter_grid"]["na"],data["parameter_grid"]["nb"]
    pp=[[None]*na for _ in range(nb)]; H=[[None]*na for _ in range(nb)]
    for j in range(nb):
        for i in range(na):
            N=set(); L=set()
            if i: N|=pp[j][i-1][0]; L|=pp[j][i-1][1]
            if j: N|=pp[j-1][i][0]; L|=pp[j-1][i][1]
            p=i+na*j; N|=pairs[p][0]; L|=pairs[p][1]
            pp[j][i]=(N,L); H[j][i]=homology_data(N,L,nx)
    dims={}; xmap={}; ymap={}
    for d in range(3):
        for j in range(nb):
            for i in range(na):
                dims[(d,i,j)]=len(H[j][i][d]["H"])
                if i: xmap[(d,i,j)]=induced_map(H[j][i-1],H[j][i],d)
                if j: ymap[(d,i,j)]=induced_map(H[j-1][i],H[j][i],d)
    return dims,xmap,ymap

def window_interval_poset(w, h):
    """All intervals (nonempty, cover-connected, order-convex) of a w x h grid as bitmasks,
    with the order-convex hull.  Every interval is reached from a singleton by one-point
    extensions, and the covers of an interval in the inclusion order are exactly its
    one-point extensions that are intervals."""
    pts=[(i,j) for j in range(h) for i in range(w)]; idx={p:k for k,p in enumerate(pts)}; n=len(pts)
    down=[0]*n; up=[0]*n
    for k,(i,j) in enumerate(pts):
        for k2,(a,b) in enumerate(pts):
            if a<=i and b<=j: down[k]|=1<<k2
            if a>=i and b>=j: up[k]|=1<<k2
    nbr=[sum(1<<idx[q] for q in ((i+1,j),(i-1,j),(i,j+1),(i,j-1)) if q in idx) for (i,j) in pts]
    def hull(s):
        dn=0; upm=0; x=s
        while x:
            bit=x&-x; k=bit.bit_length()-1; x^=bit; dn|=down[k]; upm|=up[k]
        return dn&upm
    def boundary_points(s):
        out=0; x=s
        while x:
            bit=x&-x; k=bit.bit_length()-1; x^=bit; out|=nbr[k]
        return out&~s
    seen=set(1<<k for k in range(n)); frontier=list(seen)
    while frontier:
        nxt=[]
        for s in frontier:
            cand=boundary_points(s)
            while cand:
                bit=cand&-cand; cand^=bit; t=s|bit
                if t not in seen and hull(t)==t: seen.add(t); nxt.append(t)
        frontier=nxt
    return pts,idx,hull,boundary_points,seen

def generalized_persistence_diagram(window, dims, xmap, ymap, na):
    i0,j0,i1,j1=window["bounds"]; d=window["dimension"]; w,h=i1-i0+1,j1-j0+1
    pts,idx,hull,boundary_points,ints=window_interval_poset(w,h)
    gdims=[dims[(d,i+i0,j+j0)] for i,j in pts]
    def rank(s):
        ks=[k for k in range(len(pts)) if s>>k&1]
        if min(gdims[k] for k in ks)==0: return 0     # lim -> colim factors through every node
        loc={k:t for t,k in enumerate(ks)}; arrows=[]
        for k in ks:
            i,j=pts[k]
            r=idx.get((i+1,j))
            if r is not None and s>>r&1: arrows.append((loc[k],loc[r],xmap[(d,i+i0+1,j+j0)]))
            u=idx.get((i,j+1))
            if u is not None and s>>u&1: arrows.append((loc[k],loc[u],ymap[(d,i+i0,j+j0+1)]))
        objs=[]
        for k in ks:
            o=[None]*3; o[d]={"H":[0]*gdims[k]}; objs.append(o)
        return diagram_limit_colimit_stats(objs,arrows,0,d)[2]
    rk={s:rank(s) for s in ints}
    diagram=[]
    for I in ints:
        # crosscut theorem on the lattice [I, window]: dgm(I) = sum_{A subset cov(I)} (-1)^|A| rk(join A)
        coef={I:1}; cand=boundary_points(I)
        while cand:
            bit=cand&-cand; cand^=bit
            if (I|bit) not in rk: continue
            new=dict(coef)
            for K,v in coef.items():
                J=hull(K|bit); new[J]=new.get(J,0)-v
            coef={K:v for K,v in new.items() if v}
        m=sum(v*rk[J] for J,v in coef.items())
        if m:
            ids=sorted(pts[k][0]+i0+na*(pts[k][1]+j0) for k in range(len(pts)) if I>>k&1)
            diagram.append({"parameter_ids":ids,"multiplicity":m})
    diagram.sort(key=lambda r:r["parameter_ids"])
    return {"window_id":window["window_id"],"bounds":window["bounds"],"dimension":d,"diagram":diagram}

def solve_gpd_only(data):
    nx,ny=data["phase_grid"]["nx"],data["phase_grid"]["ny"]
    frames=data["frames"]; n=nx*ny
    analyses=[analyze_frame(f,nx,ny) for f in frames]
    edge_rel={(p,q):union_relation(frames[p],analyses[p],frames[q],analyses[q],n) for p,q in data["parameter_edges"]}
    dims,xmap,ymap=bifiltration_module(data,frames,analyses,edge_rel,nx,ny)
    na=data["parameter_grid"]["na"]
    return [generalized_persistence_diagram(wd,dims,xmap,ymap,na) for wd in data.get("gpd_windows",[])]

def release_allocator_memory():
    gc.collect()
    try:
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass

def solve(data):
    nx,ny = data["phase_grid"]["nx"],data["phase_grid"]["ny"]
    frames = data["frames"]; n=nx*ny
    analyses=[analyze_frame(f,nx,ny) for f in frames]
    sigtuples=[canonical_signature(a) for a in analyses]
    unique=sorted(set(sigtuples)); sig_id={s:i for i,s in enumerate(unique)}
    signatures=[]
    for sid,s in enumerate(unique):
        labs,edges=s
        signatures.append({"signature_id":sid,"node_annotations":[{"block_betti_F2":list(x[0]),"exit_pair_betti_F2":list(x[1]),"attractor":x[2]} for x in labs],"morse_edges":[list(e) for e in edges]})
    frameout=[]
    for pid,a in enumerate(analyses):
        frameout.append({"parameter_id":pid,"morse_sets":a["nodes"],"morse_edges":a["edges"],"terminal_morse_ids":a["terminals"],"signature_id":sig_id[sigtuples[pid]]})
    # parameter adjacency and continuation events
    edge_rel={}; edge_events=[]
    for p,q in data["parameter_edges"]:
        rel=union_relation(frames[p],analyses[p],frames[q],analyses[q],n)
        edge_rel[(p,q)]=rel
        edge_events.append({"source_parameter_id":p,"target_parameter_id":q,"event_type":classify_event(analyses[p],analyses[q],rel),"continuation_relation":rel})
    # regions: connected components of equal signature on parameter graph
    padj=[[] for _ in frames]
    for p,q in data["parameter_edges"]: padj[p].append(q); padj[q].append(p)
    seen=set(); regions=[]
    for p in range(len(frames)):
        if p in seen: continue
        sid=sig_id[sigtuples[p]]; comp=[]; dq=[p]; seen.add(p)
        while dq:
            x=dq.pop(); comp.append(x)
            for y in padj[x]:
                if y not in seen and sig_id[sigtuples[y]]==sid:
                    seen.add(y); dq.append(y)
        comp.sort(); rid=len(regions)
        regions.append({"region_id":rid,"signature_id":sid,"representative_parameter_id":comp[0],"parameter_ids":comp})
    global_selected=global_continuation_family(data["global_continuation_seed"], analyses, edge_rel, data["parameter_edges"])
    global_pairs=selected_exit_pairs(global_selected,frames,analyses,nx,ny)
    # Run the largest multigraded reduction before the path/surface sweeps.  This
    # avoids retaining allocator arenas from many transient zigzag reductions and
    # keeps peak memory/running time stable in the 4 GiB benchmark container.
    mpersist=multiparameter_persistence(data,frames,analyses,edge_rel,nx,ny,global_selected,global_pairs)
    release_allocator_memory()
    pathout=[path_analysis(pr,frames,analyses,edge_rel,nx,ny) for pr in data["paths"]]
    release_allocator_memory()
    surface=continuation_surface(data,frames,analyses,edge_rel,nx,ny,global_selected,global_pairs)
    return {"phase_grid":[nx,ny],"parameter_grid":[data["parameter_grid"]["na"],data["parameter_grid"]["nb"]],"frames":frameout,"signatures":signatures,"regions":regions,"parameter_edge_events":edge_events,"continuation_barcodes":pathout,"continuation_surface":surface,"multiparameter_persistence":mpersist}

def solve_spatiotemporal_only(data):
    nx,ny=data["phase_grid"]["nx"],data["phase_grid"]["ny"]
    frames=data["frames"]; n=nx*ny
    analyses=[analyze_frame(f,nx,ny) for f in frames]
    edge_rel={(p,q):union_relation(frames[p],analyses[p],frames[q],analyses[q],n) for p,q in data["parameter_edges"]}
    return spatiotemporal_persistence(data,frames,analyses,edge_rel,nx,ny)

def main():
    inp=os.environ.get("ATLAS_INPUT","/app/data/atlas.json")
    outp=os.environ.get("RESULT_PATH","/app/result.json")
    mode=os.environ.get("SOLVE_STAGE","")
    if mode:
        with open(inp) as f:data=json.load(f)
        if mode=="spatiotemporal": ans=solve_spatiotemporal_only(data)
        elif mode=="conley": ans=conley_morse_graphs(data)
        elif mode=="gpd": ans=solve_gpd_only(data)
        else: ans=solve(data)
        with open(outp,"w") as f: json.dump(ans,f,separators=(",",":"))
        return
    paths=[]; procs=[]
    try:
        for stage in ("base","spatiotemporal","conley","gpd"):
            fd,tmp=tempfile.mkstemp(prefix=f"{stage}-",suffix=".json"); os.close(fd); paths.append(tmp)
            env=dict(os.environ); env["SOLVE_STAGE"]=stage; env["ATLAS_INPUT"]=inp; env["RESULT_PATH"]=tmp
            procs.append(subprocess.Popen([sys.executable,os.path.abspath(__file__)],env=env))
        for p in procs:
            if p.wait()!=0: raise RuntimeError("reference stage failed")
        with open(paths[0]) as f: ans=json.load(f)
        with open(paths[1]) as f: ans["spatiotemporal_persistence"]=json.load(f)
        with open(paths[2]) as f: ans["conley_morse_graphs"]=json.load(f)
        with open(paths[3]) as f: ans["multiparameter_persistence"]["generalized_persistence_diagrams_F2"]=json.load(f)
        with open(outp,"w") as f: json.dump(ans,f,separators=(",",":"))
    finally:
        for q in paths:
            try: os.unlink(q)
            except FileNotFoundError: pass

if __name__=="__main__": main()
