from __future__ import annotations
import json, math, stat
from collections import Counter
from fractions import Fraction
from pathlib import Path

HERE=Path(__file__).resolve().parent
ORACLE=json.loads((HERE/'oracle.json').read_text())
HIDDEN=json.loads((HERE/'atlas_hidden.json').read_text())
EVENTS=['continuation','birth','death','split','merge','split-merge','birth-death','rewiring']

class DuplicateKey(ValueError): pass

def no_dupes(pairs):
    d={}
    for k,v in pairs:
        if k in d: raise DuplicateKey(k)
        d[k]=v
    return d

def load_result(path:Path):
    if path.is_symlink(): raise ValueError('result.json must not be a symlink')
    st=path.stat()
    if not stat.S_ISREG(st.st_mode): raise ValueError('result.json must be a regular file')
    return json.loads(path.read_text(),object_pairs_hook=no_dupes,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError('non-finite token')))

def is_int(x): return isinstance(x,int) and not isinstance(x,bool)
def exact_keys(obj,keys,where):
    if not isinstance(obj,dict) or set(obj)!=set(keys): raise ValueError(f'{where} key set mismatch')
def int_list(x,where,strict=False):
    if not isinstance(x,list) or any(not is_int(v) for v in x): raise ValueError(f'{where} must be int[]')
    if strict and any(a>=b for a,b in zip(x,x[1:])): raise ValueError(f'{where} must be strictly increasing')

def pair_list(x,where):
    if not isinstance(x,list): raise ValueError(where)
    last=None
    for e in x:
        if not isinstance(e,list) or len(e)!=2 or any(not is_int(v) for v in e): raise ValueError(where)
        t=tuple(e)
        if last is not None and t<=last: raise ValueError(f'{where} must be lexicographically strictly sorted')
        last=t

def validate_schema(R):
    exact_keys(R,['phase_grid','parameter_grid','frames','signatures','regions','parameter_edge_events','continuation_barcodes','continuation_surface','multiparameter_persistence','spatiotemporal_persistence','conley_morse_graphs'],'result')
    for k in ['phase_grid','parameter_grid']:
        int_list(R[k],f'{k} (a two-integer list)')
        if len(R[k])!=2 or any(v<=0 for v in R[k]): raise ValueError(k)
    nparam=HIDDEN['parameter_grid']['na']*HIDDEN['parameter_grid']['nb']
    if len(R['frames'])!=nparam: raise ValueError('frames length')
    for pid,f in enumerate(R['frames']):
        exact_keys(f,['parameter_id','morse_sets','morse_edges','terminal_morse_ids','signature_id'],f'frames[{pid}]')
        if f['parameter_id']!=pid or not is_int(f['signature_id']): raise ValueError('frame id/signature')
        if not isinstance(f['morse_sets'],list): raise ValueError('morse_sets')
        for mid,m in enumerate(f['morse_sets']):
            exact_keys(m,['morse_id','min_box_id','size','block_betti_F2','exit_pair_betti_F2','attractor'],f'morse[{pid},{mid}]')
            if m['morse_id']!=mid or not is_int(m['min_box_id']) or not is_int(m['size']) or m['size']<=0 or not isinstance(m['attractor'],bool): raise ValueError('morse scalar')
            for q in ['block_betti_F2','exit_pair_betti_F2']:
                int_list(m[q],q)
                if len(m[q])!=3 or any(v<0 for v in m[q]): raise ValueError(q)
        pair_list(f['morse_edges'],'morse_edges')
        int_list(f['terminal_morse_ids'],'terminal_morse_ids',True)
    if not isinstance(R['signatures'],list): raise ValueError('signatures')
    for sid,s in enumerate(R['signatures']):
        exact_keys(s,['signature_id','node_annotations','morse_edges'],f'signatures[{sid}]')
        if s['signature_id']!=sid: raise ValueError('signature ids')
        if not isinstance(s['node_annotations'],list): raise ValueError('node_annotations')
        for a in s['node_annotations']:
            exact_keys(a,['block_betti_F2','exit_pair_betti_F2','attractor'],'annotation')
            for q in ['block_betti_F2','exit_pair_betti_F2']:
                int_list(a[q],q)
                if len(a[q])!=3: raise ValueError(q)
            if not isinstance(a['attractor'],bool): raise ValueError('attractor')
        pair_list(s['morse_edges'],'signature edges')
    if not isinstance(R['regions'],list): raise ValueError('regions')
    covered=[]
    for rid,r in enumerate(R['regions']):
        exact_keys(r,['region_id','signature_id','representative_parameter_id','parameter_ids'],f'regions[{rid}]')
        if r['region_id']!=rid or any(not is_int(r[k]) for k in ['signature_id','representative_parameter_id']): raise ValueError('region scalar')
        int_list(r['parameter_ids'],'parameter_ids',True)
        if not r['parameter_ids'] or r['representative_parameter_id']!=r['parameter_ids'][0]: raise ValueError('region representative')
        covered.extend(r['parameter_ids'])
    if sorted(covered)!=list(range(nparam)) or len(covered)!=len(set(covered)): raise ValueError('regions must partition parameter nodes')
    if len(R['parameter_edge_events'])!=len(HIDDEN['parameter_edges']): raise ValueError('parameter_edge_events length')
    for idx,(ev,pub) in enumerate(zip(R['parameter_edge_events'],HIDDEN['parameter_edges'])):
        exact_keys(ev,['source_parameter_id','target_parameter_id','event_type','continuation_relation'],f'edge event {idx}')
        if [ev['source_parameter_id'],ev['target_parameter_id']]!=pub: raise ValueError('parameter edge order')
        if ev['event_type'] not in EVENTS: raise ValueError('event enum')
        pair_list(ev['continuation_relation'],'continuation_relation')
    if len(R['continuation_barcodes'])!=len(HIDDEN['paths']): raise ValueError('continuation paths length')
    for k,(p,pub) in enumerate(zip(R['continuation_barcodes'],HIDDEN['paths'])):
        exact_keys(p,['path_id','parameter_ids','seed_box_id','selected_morse_ids_by_frame','dimensions'],f'path {k}')
        if p['path_id']!=pub['path_id'] or p['parameter_ids']!=pub['parameter_ids'] or p['seed_box_id']!=pub['seed_box_id']: raise ValueError('path identity')
        if len(p['selected_morse_ids_by_frame'])!=len(p['parameter_ids']): raise ValueError('selected length')
        for s in p['selected_morse_ids_by_frame']: int_list(s,'selected ids',True)
        if len(p['dimensions'])!=3: raise ValueError('path dimensions')
        z=2*len(p['parameter_ids'])-1
        for d,rec in enumerate(p['dimensions']):
            exact_keys(rec,['dimension','node_dimensions_F2','rank_rows_F2','interval_multiplicities_F2'],'zigzag dimension')
            if rec['dimension']!=d: raise ValueError('zigzag dimension id')
            int_list(rec['node_dimensions_F2'],'node_dimensions')
            if len(rec['node_dimensions_F2'])!=z: raise ValueError('node dimensions length')
            if not isinstance(rec['rank_rows_F2'],list) or len(rec['rank_rows_F2'])!=z: raise ValueError('rank rows')
            for a,row in enumerate(rec['rank_rows_F2']):
                int_list(row,'rank row')
                if len(row)!=z-a: raise ValueError('rank row length')
                if row[0]!=rec['node_dimensions_F2'][a]: raise ValueError('singleton rank')
            bars=rec['interval_multiplicities_F2']
            if not isinstance(bars,list): raise ValueError('bars')
            last=None
            for b in bars:
                exact_keys(b,['start','end','multiplicity'],'bar')
                if any(not is_int(b[q]) for q in ['start','end','multiplicity']) or not (0<=b['start']<=b['end']<z) or b['multiplicity']<=0: raise ValueError('bar values')
                key=(b['start'],b['end'])
                if last is not None and key<=last: raise ValueError('bar order')
                last=key
            # Bars must reconstruct every generalized rank.
            for a,row in enumerate(rec['rank_rows_F2']):
                for off,val in enumerate(row):
                    bb=a+off
                    recon=sum(x['multiplicity'] for x in bars if x['start']<=a and bb<=x['end'])
                    if recon!=val: raise ValueError('barcode/rank inconsistency')
    C=R['continuation_surface']; seed=HIDDEN['global_continuation_seed']
    exact_keys(C,['seed_parameter_id','seed_box_id','selected_morse_ids_by_parameter','window_ranks_F2'],'continuation_surface')
    if C['seed_parameter_id']!=seed['parameter_id'] or C['seed_box_id']!=seed['seed_box_id']: raise ValueError('surface seed identity')
    if not isinstance(C['selected_morse_ids_by_parameter'],list) or len(C['selected_morse_ids_by_parameter'])!=nparam: raise ValueError('surface selection length')
    for ids in C['selected_morse_ids_by_parameter']: int_list(ids,'surface selected ids',True)
    if not isinstance(C['window_ranks_F2'],list) or len(C['window_ranks_F2'])!=len(HIDDEN['window_queries']): raise ValueError('surface window length')
    for idx,(wr,pub) in enumerate(zip(C['window_ranks_F2'],HIDDEN['window_queries'])):
        exact_keys(wr,['window_id','bounds','rank_F2'],f'surface window {idx}')
        if wr['window_id']!=pub['window_id'] or wr['bounds']!=pub['bounds']: raise ValueError('surface window identity')
        int_list(wr['bounds'],'surface bounds')
        if len(wr['bounds'])!=4: raise ValueError('surface bounds length')
        int_list(wr['rank_F2'],'surface rank')
        if len(wr['rank_F2'])!=3 or any(v<0 for v in wr['rank_F2']): raise ValueError('surface rank values')
    P=R['multiparameter_persistence']
    exact_keys(P,['parameter_grid','dimensions','generalized_persistence_diagrams_F2'],'multiparameter_persistence')
    int_list(P['parameter_grid'],'multiparameter parameter_grid')
    na,nb=HIDDEN['parameter_grid']['na'],HIDDEN['parameter_grid']['nb']
    if P['parameter_grid']!=[na,nb]: raise ValueError('multiparameter grid identity')
    if not isinstance(P['dimensions'],list) or len(P['dimensions'])!=3: raise ValueError('multiparameter dimensions')
    for d,rec in enumerate(P['dimensions']):
        exact_keys(rec,['dimension','module_dimensions_F2','betti_tables_F2','signed_rectangle_rank_decomposition'],f'multiparameter dimension {d}')
        if rec['dimension']!=d: raise ValueError('multiparameter dimension id')
        int_list(rec['module_dimensions_F2'],'module_dimensions_F2')
        if len(rec['module_dimensions_F2'])!=nparam or any(v<0 for v in rec['module_dimensions_F2']): raise ValueError('module dimensions')
        tabs=rec['betti_tables_F2']
        if not isinstance(tabs,list) or len(tabs)!=3: raise ValueError('betti tables')
        bd=[]
        for h,t in enumerate(tabs):
            exact_keys(t,['homological_degree','nonzero_grades'],f'betti table {d},{h}')
            if t['homological_degree']!=h or not isinstance(t['nonzero_grades'],list): raise ValueError('betti table identity')
            vals={}; last=-1
            for z in t['nonzero_grades']:
                if not isinstance(z,list) or len(z)!=3 or any(not is_int(v) for v in z): raise ValueError('betti grade')
                i,j,m=z
                if not (0<=i<na and 0<=j<nb and m>0): raise ValueError('betti grade values')
                pid=i+na*j
                if pid<=last: raise ValueError('betti grades must be in parameter-id order')
                last=pid; vals[(i,j)]=m
            bd.append(vals)
        # Hilbert-series identity for a bigraded k[x,y]-module:
        # dim M_(i,j) is the cumulative alternating sum of beta_0-beta_1+beta_2.
        for j in range(nb):
            for i in range(na):
                recon=0
                for (a,b),m in bd[0].items():
                    if a<=i and b<=j: recon+=m
                for (a,b),m in bd[1].items():
                    if a<=i and b<=j: recon-=m
                for (a,b),m in bd[2].items():
                    if a<=i and b<=j: recon+=m
                if recon!=rec['module_dimensions_F2'][i+na*j]: raise ValueError('Betti/Hilbert inconsistency')
        rects=rec['signed_rectangle_rank_decomposition']
        if not isinstance(rects,list): raise ValueError('signed rectangle decomposition')
        parsed=[]; last=None
        for q in rects:
            exact_keys(q,['birth','death','multiplicity'],'signed rectangle')
            int_list(q['birth'],'rectangle birth'); int_list(q['death'],'rectangle death')
            if len(q['birth'])!=2 or len(q['death'])!=2 or not is_int(q['multiplicity']) or q['multiplicity']==0: raise ValueError('rectangle values')
            i0,j0=q['birth']; i1,j1=q['death']
            if not (0<=i0<=i1<na and 0<=j0<=j1<nb): raise ValueError('rectangle bounds')
            key=(i0+na*j0,i1+na*j1)
            if last is not None and key<=last: raise ValueError('rectangle order')
            last=key; parsed.append((i0,j0,i1,j1,q['multiplicity']))
        # Every singleton rank equals its module dimension.
        for j in range(nb):
            for i in range(na):
                recon=sum(m for i0,j0,i1,j1,m in parsed if i0<=i<=i1 and j0<=j<=j1)
                if recon!=rec['module_dimensions_F2'][i+na*j]: raise ValueError('rectangle/singleton-rank inconsistency')
    GP=P['generalized_persistence_diagrams_F2']; gpub=HIDDEN.get('gpd_windows',[])
    if not isinstance(GP,list) or len(GP)!=len(gpub): raise ValueError('generalized persistence diagram length')
    for g,pub in zip(GP,gpub):
        exact_keys(g,['window_id','bounds','dimension','diagram'],'generalized persistence diagram')
        if any(g[k]!=pub[k] for k in ['window_id','bounds','dimension']): raise ValueError('generalized persistence diagram identity')
        i0,j0,i1,j1=pub['bounds']; d=pub['dimension']
        window={i+na*j for j in range(j0,j1+1) for i in range(i0,i1+1)}
        if not isinstance(g['diagram'],list): raise ValueError('diagram')
        cover=Counter(); last=None
        for e in g['diagram']:
            exact_keys(e,['parameter_ids','multiplicity'],'diagram entry')
            ids=e['parameter_ids']; int_list(ids,'diagram parameter_ids',True)
            if not ids or any(p not in window for p in ids): raise ValueError('diagram support must lie in the window')
            if not is_int(e['multiplicity']) or e['multiplicity']==0: raise ValueError('diagram multiplicity must be a nonzero integer')
            if last is not None and ids<=last: raise ValueError('diagram entries must be sorted by parameter_ids')
            last=ids
            pts={(p%na,p//na) for p in ids}
            if any((a<=i<=c and b<=j<=dd) and (i,j) not in pts for (a,b) in pts for (c,dd) in pts for i in range(a,c+1) for j in range(b,dd+1)):
                raise ValueError('diagram support must be order-convex')
            st=[next(iter(pts))]; seen={st[0]}
            while st:
                i,j=st.pop()
                for q in ((i+1,j),(i-1,j),(i,j+1),(i,j-1)):
                    if q in pts and q not in seen: seen.add(q); st.append(q)
            if seen!=pts: raise ValueError('diagram support must be connected')
            for p in ids: cover[p]+=e['multiplicity']
        # rank of the singleton interval {p} is dim M_d(p) = sum of dgm over intervals containing p
        md=P['dimensions'][d]['module_dimensions_F2']
        if any(cover[p]!=md[p] for p in window): raise ValueError('generalized persistence diagram does not reproduce singleton ranks')
    ST=R['spatiotemporal_persistence']
    exact_keys(ST,['scale_radii','query_ranks_F2','deformation_cohomology_F2'],'spatiotemporal_persistence')
    int_list(ST['scale_radii'],'scale_radii',True)
    if ST['scale_radii']!=HIDDEN.get('spatiotemporal_scale_radii',[]): raise ValueError('scale radii identity')
    stpub=HIDDEN.get('spatiotemporal_queries',[])
    if not isinstance(ST['query_ranks_F2'],list) or len(ST['query_ranks_F2'])!=len(stpub): raise ValueError('scale-time query length')
    for idx,(q,pub) in enumerate(zip(ST['query_ranks_F2'],stpub)):
        exact_keys(q,['query_id','path_id','scale_bounds','time_bounds','dimensions'],f'scale-time query {idx}')
        if any(q[k]!=pub[k] for k in ['query_id','path_id','scale_bounds','time_bounds']): raise ValueError('scale-time query identity')
        for z,name in [(q['scale_bounds'],'scale bounds'),(q['time_bounds'],'time bounds')]:
            int_list(z,name)
            if len(z)!=2 or z[0]>z[1]: raise ValueError(name)
        if not isinstance(q['dimensions'],list) or len(q['dimensions'])!=3: raise ValueError('scale-time dimensions')
        for d,dr in enumerate(q['dimensions']):
            exact_keys(dr,['dimension','limit_dimension_F2','colimit_dimension_F2','generalized_rank_F2'],f'scale-time dimension {idx},{d}')
            if dr['dimension']!=d: raise ValueError('scale-time dimension id')
            vals=[dr['limit_dimension_F2'],dr['colimit_dimension_F2'],dr['generalized_rank_F2']]
            if any(not is_int(v) or v<0 for v in vals): raise ValueError('scale-time dimension values')
            if dr['generalized_rank_F2']>min(dr['limit_dimension_F2'],dr['colimit_dimension_F2']): raise ValueError('scale-time rank bound')
    defpub=HIDDEN.get('spatiotemporal_deformation_path_ids',[])
    if not isinstance(ST['deformation_cohomology_F2'],list) or len(ST['deformation_cohomology_F2'])!=len(defpub): raise ValueError('deformation path length')
    for idx,(rec,pid) in enumerate(zip(ST['deformation_cohomology_F2'],defpub)):
        exact_keys(rec,['path_id','dimensions'],f'deformation path {idx}')
        if rec['path_id']!=pid: raise ValueError('deformation path identity')
        if not isinstance(rec['dimensions'],list) or len(rec['dimensions'])!=3: raise ValueError('deformation dimensions')
        for d,z in enumerate(rec['dimensions']):
            exact_keys(z,['dimension','c0_dimension','c1_dimension','c2_dimension','delta0_rank_F2','delta1_rank_F2','h0_F2','h1_F2','h2_F2'],f'deformation dimension {idx},{d}')
            if z['dimension']!=d: raise ValueError('deformation dimension id')
            vals=[z[k] for k in ['c0_dimension','c1_dimension','c2_dimension','delta0_rank_F2','delta1_rank_F2','h0_F2','h1_F2','h2_F2']]
            if any(not is_int(v) or v<0 for v in vals): raise ValueError('deformation values')
            c0,c1,c2=z['c0_dimension'],z['c1_dimension'],z['c2_dimension']
            r0,r1=z['delta0_rank_F2'],z['delta1_rank_F2']
            if r0>min(c0,c1) or r1>min(c1,c2) or r0+r1>c1: raise ValueError('deformation rank bounds')
            if z['h0_F2']!=c0-r0 or z['h1_F2']!=c1-r0-r1 or z['h2_F2']!=c2-r1: raise ValueError('deformation cohomology identity')
            if z['h0_F2']-z['h1_F2']+z['h2_F2']!=c0-c1+c2: raise ValueError('deformation Euler identity')
    CG=R['conley_morse_graphs']; cpub=HIDDEN.get('conley_frames',[])
    if not isinstance(CG,list) or len(CG)!=len(cpub): raise ValueError('conley_morse_graphs length')
    def check_index(ci,where):
        if ci is None: return
        if not isinstance(ci,list) or len(ci)!=3: raise ValueError(f'{where}: conley_index must be null or three records')
        for d,rec in enumerate(ci):
            exact_keys(rec,['dimension','leray_dimension_Q','invariant_factors_Q','bowen_franks_Z'],f'{where} index record')
            ld,fs,bf=rec['leray_dimension_Q'],rec['invariant_factors_Q'],rec['bowen_franks_Z']
            if rec['dimension']!=d or not is_int(ld) or ld<0: raise ValueError(f'{where}: index dimensions')
            if not isinstance(fs,list): raise ValueError(f'{where}: invariant factors')
            polys=[]
            for f in fs:
                int_list(f,'invariant factor')
                if len(f)<2 or f[-1]!=1: raise ValueError('invariant factors must be monic and nonconstant')
                polys.append([Fraction(x) for x in f])
            if sum(len(f)-1 for f in fs)!=ld: raise ValueError('invariant factor degrees must sum to leray_dimension_Q')
            for f0,f1 in zip(polys,polys[1:]):
                if len(f0)>len(f1): raise ValueError('invariant factor order')
                r=list(f1)
                while len(r)>=len(f0) and any(r):
                    c=r[-1]; sh=len(r)-len(f0)
                    for k,x in enumerate(f0): r[sh+k]-=c*x
                    r.pop()
                if any(r): raise ValueError('invariant factors must form a divisibility chain')
            int_list(bf,'bowen_franks_Z')
            if any(x<0 or x==1 for x in bf): raise ValueError('bowen_franks_Z entries must be nonnegative and not 1')
            nz=[x for x in bf if x]
            if bf!=nz+[0]*(len(bf)-len(nz)) or any(y%x for x,y in zip(nz,nz[1:])): raise ValueError('bowen_franks_Z must be a divisibility chain with zeros last')
            # the free rank of coker(I-f_d) is the multiplicity of t-1 among the invariant factors
            ones=sum(1 for f in polys if sum(f)==0)
            if bf.count(0)!=ones: raise ValueError('bowen_franks_Z free rank must equal the number of invariant factors vanishing at t=1')
    for g,pub in zip(CG,cpub):
        exact_keys(g,['conley_frame_id','parameter_id','morse_sets','morse_edges','interval_indices'],'conley graph')
        if g['conley_frame_id']!=pub['conley_frame_id'] or g['parameter_id']!=pub['parameter_id']: raise ValueError('conley frame identity')
        if not isinstance(g['morse_sets'],list): raise ValueError('conley morse_sets')
        last=-1
        for mid,m in enumerate(g['morse_sets']):
            exact_keys(m,['morse_id','min_box_id','size','attractor','conley_index'],'conley morse set')
            if m['morse_id']!=mid or not is_int(m['min_box_id']) or m['min_box_id']<=last or not is_int(m['size']) or m['size']<=0 or not isinstance(m['attractor'],bool): raise ValueError('conley morse scalar')
            last=m['min_box_id']
            check_index(m['conley_index'],f'morse set {mid}')
        pair_list(g['morse_edges'],'conley morse_edges')
        n=len(g['morse_sets']); src=set()
        for a_,b_ in g['morse_edges']:
            if not (0<=a_<n and 0<=b_<n) or a_==b_: raise ValueError('conley morse edge ids')
            src.add(a_)
        if any(m['attractor']!=(m['morse_id'] not in src) for m in g['morse_sets']): raise ValueError('attractors must be the Morse sets without outgoing Hasse edges')
        iv=g['interval_indices']
        if not isinstance(iv,list) or len(iv)!=len(g['morse_edges']): raise ValueError('interval_indices must align with morse_edges')
        for rec,(a_,b_) in zip(iv,g['morse_edges']):
            exact_keys(rec,['source','target','size','conley_index'],'interval index')
            if [rec['source'],rec['target']]!=[a_,b_]: raise ValueError('interval_indices order/identity')
            if not is_int(rec['size']) or rec['size']<g['morse_sets'][a_]['size']+g['morse_sets'][b_]['size']: raise ValueError('interval size must count at least both Morse sets')
            check_index(rec['conley_index'],f'interval {a_}->{b_}')

def validate(path:Path):
    try:
        R=load_result(path)
        validate_schema(R)
        if R!=ORACLE: return False,'result does not match sealed reference'
        return True,'ok'
    except Exception as e:
        return False,f'{type(e).__name__}: {e}'
